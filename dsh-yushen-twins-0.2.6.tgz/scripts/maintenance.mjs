// Copyright (c) 2026 从零开始 · 鱼神双子星 · AGPL-3.0-or-later（保留本行）
// 每日维护：备份 / 归档 / 索引 / 审计 / 清理，**全部在这个独立进程里做**。
//
// 为什么要有它（2026-11-03 00:0x，老板亲口）：「这种东西为什么要放在宿主里面去做，
// 不应该做个脚本之类的放到本地去，宿主只需要发个命令」。实况：00:02:56–00:05:39
// 宿主的心跳断了 164 秒、界面冻住，因为 backupTick 在宿主进程里同步跑
// `fs.cpSync` 拷 3 万文件 + 一串 `spawnSync`——事件循环被堵死，网页看着像掉线。
//
// 现在：宿主只 spawn 一次这个脚本（不等待、不读输出），所有同步重活都在这里。
// 宿主下一轮读 `runtime/maintenance-last.json`，把 lines 说出来。
//
// 用法：
//   node scripts/maintenance.mjs                 # 该跑的都跑（同一个小时里重复跑会走护栏）
//   node scripts/maintenance.mjs --plan          # 只看这一轮会跑什么，不动任何东西
//   node scripts/maintenance.mjs --only=offsite  # 只跑某几步（逗号分隔）
//   node scripts/maintenance.mjs --home=<目录>   # 用别的家目录（测试用）
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const flag = (name) => argv.find((a) => a === `--${name}` || a.startsWith(`--${name}=`));
const planOnly = Boolean(flag('plan'));
const onlyArg = flag('only');
const only = onlyArg ? new Set(String(onlyArg.split('=')[1] || '').split(',').map((s) => s.trim()).filter(Boolean)) : null;
const homeArg = flag('home');
if (homeArg) process.env.DSH_HOME = String(homeArg.split('=')[1] || '');

// 库在 import 时读 DSH_HOME，所以必须在设完环境之后再动态加载。
const { offsiteDir, offsiteSecondDir } = await import('../lib/paths.js');
const { runOffsiteBackup, runFullBackup, fullRoots } = await import('../lib/offsite.js');
const { fingerprint } = await import('../lib/fingerprint.js');
const { archiveSessions } = await import('../lib/session-archive.js');
const { buildDailyRecords } = await import('../lib/records.js');
const { buildKeyPoints } = await import('../lib/key-points.js');
const { checkTempCache } = await import('../lib/temp-cache.js');
const { verifyBackup, writeBackupReport, localDate } = await import('../lib/backup-verify.js');
const { noteIncident } = await import('../lib/incidents.js');
const { observe: observeLineage } = await import('../lib/content-lineage.js');
const { pruneBackups } = await import('../lib/prune.js');
const { archiveOld } = await import('../lib/archive.js');
const { rotateLogs } = await import('../lib/rotate.js');
const { isMobile } = await import('../lib/platform.js');
const { today: localToday } = await import('../lib/clock.js');
const { atFileOf, readRows, pickFreshOwnerMentions, ownerMentionLine, writeOwnerMentions } = await import('../lib/bili-inbox.js');

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
const DATA = path.join(HOME, 'dayu');
const RUNTIME = path.join(DATA, 'runtime');
const OUT = path.join(RUNTIME, 'maintenance-last.json');
const LOG = path.join(RUNTIME, 'maintenance.log');

const started = Date.now();
const lines = [];
const steps = [];
const ownerMentions = [];
const say = (text) => { if (text) { lines.push(String(text)); } };

function readState(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}
function lastAt(file) {
  return Date.parse(readState(file).lastAt || readState(file).at || '') || 0;
}
function writeState(file, value) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(value) + '\n', 'utf8');
  } catch { /* 状态写不下不影响已经做完的活 */ }
}
/** 同一天只跑一次的那套日期护栏（用本机日期，不用 UTC）。 */
function dueToday(markFile) {
  const today = localDate();
  return { due: String(readState(markFile).date || '') !== today, today };
}
function runScript(script, args = [], timeout = 120000) {
  const r = spawnSync(process.execPath, [path.join(ROOT, 'scripts', script), ...args], {
    encoding: 'utf8', timeout, cwd: ROOT,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: process.env.ELECTRON_RUN_AS_NODE || '1' },
  });
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') };
}
const lastLine = (text) => String(text || '').trim().split('\n').pop() || '';
const firstLine = (text) => String(text || '').trim().split('\n')[0] || '';

// 2026-11-03：磁盘上已经有一份比 state 更新的 FULL，就认领它（写完 manifest 才算完成）。
// 为什么：runFullBackup 不写状态，手动/子代理跑完以后这一份永远不被系统看见，24 小时内不会再排。
function adoptNewestFull(stateFile) {
  try {
    const root = path.join(offsiteDir(), 'FULL');
    const dirs = fs.readdirSync(root, { withFileTypes: true })
      .filter((e) => e.isDirectory() && /^\d{4}-\d{2}-\d{2}_\d{6}$/.test(e.name))
      .map((e) => e.name)
      .sort();
    const newest = dirs[dirs.length - 1];
    if (!newest) return false;
    const dir = path.join(root, newest);
    const manifestFile = path.join(dir, 'manifest.json');
    const atMs = fs.statSync(manifestFile).mtimeMs; // 没写完的目录没有 manifest，直接抛错跳过
    const prev = readState(stateFile);
    if (atMs <= (Date.parse(prev.lastAt || '') || 0)) return false;
    let files = 0;
    try { files = Number(JSON.parse(fs.readFileSync(manifestFile, 'utf8')).totalFiles) || 0; } catch { /* 读不到就记 0 */ }
    writeState(stateFile, { ...prev, lastAt: new Date(atMs).toISOString(), dir, files, adopted: true });
    say(`全盘备份：认领磁盘上已有的一份（${dir}，${files} 个文件）`);
    return true;
  } catch { return false; }
}

function want(step) {
  if (only) return only.has(step);
  return true;
}

const STEPS = {
  // 每小时一次离线快照（55 分钟一档，和 1 小时 tick 错开）。
  offsite() {
    if (isMobile()) return 'skip';
    if (Date.now() - lastAt(path.join(DATA, 'offsite.json')) < 55 * 60 * 1000) return 'not-due';
    const out = runOffsiteBackup({ target: offsiteDir(), keep: 14 });
    if (out.ok) {
      writeState(path.join(DATA, 'offsite.json'), { lastAt: new Date().toISOString(), dir: out.dir, files: out.manifest?.totalFiles || 0 });
      say(`离线快照：${out.dir}（${out.manifest?.totalFiles || 0} 个文件，清掉 ${out.pruned?.length || 0} 份旧的）`);
      return 'done';
    }
    say(`离线快照跳过：${out.reason || '目标不可用'}`);
    return 'failed';
  },
  // 一天一次全盘；先比指纹，一点没变就只推时间戳。
  full() {
    const stateFile = path.join(DATA, 'full-backup.json');
    // 2026-11-03（全量备份验收时发现）：runFullBackup 只写目标目录和 manifest，**不写这个状态文件**；
    // 状态只有这里会写。于是手动/子代理跑过一份全量以后，宿主仍以为"24 小时内不用再备"，
    // 那份新备份永远不被系统看见。这里先认领磁盘上比 state 更新的一份，再谈该不该跑。
    const adopted = adoptNewestFull(stateFile);
    if (adopted) return 'adopted';
    if (Date.now() - lastAt(stateFile) <= 24 * 3600 * 1000) return 'not-due';
    const prev = readState(stateFile);
    let fp = '';
    try { fp = fingerprint(fullRoots()); } catch { /* 算不了就照常备 */ }
    if (fp && prev.fingerprint === fp) {
      writeState(stateFile, { ...prev, lastAt: new Date().toISOString() });
      say('全盘备份跳过：一点没变');
      return 'skipped-same';
    }
    const full = runFullBackup({ keep: 3 });
    if (full.ok) {
      writeState(stateFile, { lastAt: new Date().toISOString(), dir: full.dir, files: full.manifest?.totalFiles || 0, fingerprint: fp });
      say(`全盘备份：${full.dir}（${full.manifest?.totalFiles || 0} 个文件）`);
      return 'done';
    }
    say(`全盘备份跳过：${full.reason || '目标不可用'}`);
    return 'failed';
  },
  // 第二块盘（防磁盘坏），一天一次。
  second() {
    if (Date.now() - lastAt(path.join(DATA, 'offsite-second.json')) <= 24 * 3600 * 1000) return 'not-due';
    const dir = offsiteSecondDir();
    if (!dir) return 'skip';
    const out = runOffsiteBackup({ target: dir, keep: 3 });
    if (out.ok) {
      writeState(path.join(DATA, 'offsite-second.json'), { lastAt: new Date().toISOString(), dir: out.dir, files: out.manifest?.totalFiles || 0 });
      say(`第二盘备份：${out.dir}（${out.manifest?.totalFiles || 0} 个文件）`);
      return 'done';
    }
    say(`第二盘备份跳过：${out.reason || '目标不可用'}`);
    return 'failed';
  },
  // 会话归档 + 各本索引 + 自审计（都不调模型）。
  archive() {
    const ar = archiveSessions();
    if (ar.written) say(`会话归档：新写 ${ar.written} 个（${ar.messages} 条消息）`);
    const hc = runScript('check-archive-health.mjs', ['--json'], 120000);
    if (hc.status === 1) {
      let why = '有问题（读不出详情）';
      try { why = (JSON.parse(hc.stdout || '{}').problems || []).join('；') || why; } catch { /* 用兜底文案 */ }
      say(`归档健康：${why}`);
    }
    const rec = buildDailyRecords();
    if (rec.written) say(`完整记录：新写 ${rec.written} 份（${rec.messages} 段）`);
    try { const kp = buildKeyPoints(); if (kp.days) say(`关键节点：${kp.days} 天 / ${kp.rows} 条`); } catch { /* 不影响别的 */ }
    const idx = runScript('build-live-index.mjs', [], 60000);
    say(lastLine(idx.stdout));
    for (const [label, script] of [['总书目', 'build-catalog.mjs'], ['记忆大纲', 'build-memory-outline.mjs']]) {
      const r = runScript(script, [], 240000);
      const first = firstLine(r.stdout);
      if (first) say(`${label}：${first}`);
    }
    const debt = runScript('promise-check.mjs', [], 60000);
    const dl = firstLine(debt.stdout);
    if (dl && !dl.includes('干净')) say(dl);
    runScript('check-context.mjs', [], 15000);
    const aud = runScript('audit-daily.mjs', [], 120000);
    say(lastLine(aud.stdout));
    // 临时缓存：每天看一次，超过 7 天没处理的提醒一句。
    const mark = path.join(RUNTIME, 'temp-cache-check.json');
    const today = localToday();
    if (String(readState(mark).date || '') !== today) {
      const tc = checkTempCache();
      writeState(mark, { date: today, stale: tc.stale.length });
      if (tc.stale.length) say(`临时缓存：${tc.stale.length} 个放了超过 7 天，该归位或进待删`);
    }
    return 'done';
  },
  // 媒体索引 + 倒排索引（增量）。
  indexes() {
    const media = runScript('index-media.mjs', [], 120000);
    say(lastLine(media.stdout));
    const rx = runScript('reindex.mjs', [], 120000);
    if (rx.status === 0) say(lastLine(rx.stdout) ? `倒排索引：${lastLine(rx.stdout)}` : '');
    else say(`倒排索引没跑成：${lastLine(rx.stderr) || `退出码 ${rx.status}`}`);
    return 'done';
  },
  // B站 @我 / 回复我（只读，不回复）。
  bili() {
    let file = atFileOf(HOME);
    const before = readRows(file).length;
    for (const mode of ['at', 'replies']) {
      const r = runScript('bili-inbox.mjs', ['--mode', mode], 120000);
      let out = {};
      try { out = JSON.parse(lastLine(r.stdout)) } catch { out = {} }
      if (mode === 'at' && out.file) file = String(out.file);
      if (r.status !== 0 || out.ok === false) say(`B站收件（${mode}）没跑成：${out.reason || out.error || lastLine(r.stderr) || `退出码 ${r.status}`}`);
      else if (out.written) say(`B站收件（${mode}）：新写 ${out.written} 条`);
    }
    const mine = pickFreshOwnerMentions(readRows(file), before);
    if (mine.length) {
      say(ownerMentionLine(mine));
      const w = writeOwnerMentions(HOME, mine);
      ownerMentions.push(...mine);
      say(`B站：主人 @ 的记录已更新（最近 ${w.total} 条）→ ${w.file}`);
    }
    return 'done';
  },
  // 冷档接原文：一天一次，三个角色各跑一遍。
  cold() {
    const mark = path.join(RUNTIME, 'cold-link.json');
    const { due, today } = dueToday(mark);
    if (!due) return 'not-due';
    const report = {};
    for (const role of ['dayu', 'xiaoyu', 'dragon']) {
      const r = runScript('link-cold-archive.mjs', ['--role', role], 120000);
      const line = lastLine(r.stdout);
      if (r.status === 0 && line) { report[role] = line; say(line); }
      else report[role] = `跳过：${lastLine(r.stderr) || ('退出码 ' + r.status)}`;
    }
    writeState(mark, { date: today, at: new Date().toISOString(), roles: report });
    return 'done';
  },
  // 备份验证：五层一次查完，落一份报告。
  verify() {
    const mark = path.join(RUNTIME, 'backup-verify.json');
    const { due } = dueToday(mark);
    if (!due) return 'not-due';
    const rep = verifyBackup();
    const out = writeBackupReport(rep);
    writeState(mark, { date: rep.date, at: new Date().toISOString(), green: rep.green, yellow: rep.yellow, red: rep.red, file: out.file });
    say(`备份验证：${rep.summary}，报告 ${out.file}`);
    if (rep.red > 0) say(`备份验证：${rep.red} 项红 —— ${rep.reds.join('；')}`);
    return 'done';
  },
  // 内容谱系：这一版的字节以前来过就是倒退（只报不拦）。
  lineage() {
    const mark = path.join(RUNTIME, 'lineage.json');
    const { due, today } = dueToday(mark);
    if (!due) return 'not-due';
    const r = observeLineage({});
    writeState(mark, { date: today, at: new Date().toISOString(), checked: r.checked, changed: r.changed.length, regressions: r.regressions.length });
    if (r.regressions.length) say(`内容谱系：${r.regressions.length} 处倒退 —— ${r.regressions.map((g) => `${g.file}（回到 ${String(g.backTo).slice(0, 10)}）`).join('；')}`);
    else say(`内容谱系：${r.checked} 个关键文件，没有倒退（新记 ${r.changed.length} 版）`);
    return 'done';
  },
  // 2026-11-03（老板：以后还会卡死吗）：给 10 分钟那层配一条看门狗——它有自己的定时器，
  // 但没人盯着「该跑没跑」。过点 20 分钟以上就喊一声，别让它静悄悄停两小时。
  protect() {
    const dir = path.join(DATA, 'protection')
    const st = readState(path.join(dir, 'status.json'))
    const cfg = readState(path.join(dir, 'config.json'))
    if (cfg.enabled === false) return 'disabled'
    const interval = Number(cfg.intervalMs) || 1800000
    const label = Math.round(interval / 60000) + ' 分钟备份'
    if (st.error) say(`${label}上次失败：${st.error}`)
    const next = Date.parse(st.nextRun || '') || 0
    if (!next) return 'no-schedule'
    const lateMin = Math.round((Date.now() - next) / 60000)
    if (lateMin > Math.max(20, Math.round((interval * 2) / 60000))) {
      say(`${label}停了：下次该 ${new Date(next).toLocaleString()}，已经晚了 ${lateMin} 分钟`)
      // 2026-11-03（照微）：光 say() 等于只在日志里喊一声——11-03 上午这层静默停了 3 小时，
      // 一整天没人翻日志就没人发现（是我手动跑 verify-backup 才撞见）。红了要能叫醒人。
      // 文本用固定串、不带分钟数：同一面墙只留一张单，第 3 次自动升级成 high。
      try {
        noteIncident({
          sessionId: 'maintenance',
          title: '10 分钟备份层停摆',
          source: 'maintenance/protect',
          text: '10 分钟备份停摆：nextRun 已过期 20 分钟以上',
        })
      } catch { /* 开单失败别把日检搞挂 */ }
    }
    return 'done'
  },
  // 备份清理（按保留规则）。
  prune() {
    const pr = pruneBackups({ apply: true });
    if (pr.removed) say(`备份清理：删 ${pr.removed} 份，腾 ${(pr.freed / 1024 / 1024 / 1024).toFixed(2)} GB`);
    return 'done';
  },
  // 旧单归档 + 账本轮转：一天一次（内容不丢，只有压缩和改名）。
  housekeeping() {
    const mark = path.join(RUNTIME, 'housekeeping.json');
    const { due, today } = dueToday(mark);
    if (!due) return 'not-due';
    const a = archiveOld();
    const r = rotateLogs();
    writeState(mark, { date: today, at: new Date().toISOString(), archived: a, rotated: r });
    if (a.incidents || a.jobs) say(`旧单归档：事故 ${a.incidents} 张、派活 ${a.jobs} 条 → 旧条目转 JSONL，近期留着`);
    const moved = (r.archived || []).length + (r.rotated || []).length;
    if (moved) say(`账本轮转：压 ${(r.archived || []).length} 个事件文件、改名留档 ${(r.rotated || []).length} 个（内容不删）`);
    return 'done';
  },
};

if (planOnly) {
  const out = [];
  for (const name of Object.keys(STEPS)) {
    if (!want(name)) continue;
    out.push({ step: name, noted: 'plan（只看不算）' });
  }
  console.log(JSON.stringify({ plan: out, home: HOME, at: new Date().toISOString() }, null, 2));
  process.exit(0);
}

for (const [name, run] of Object.entries(STEPS)) {
  if (!want(name)) continue;
  const at = Date.now();
  let result = 'done';
  try { result = (await run()) || 'done'; }
  catch (error) { result = 'failed'; say(`维护步骤「${name}」失败：${error?.message || error}`); }
  steps.push({ step: name, result, ms: Date.now() - at });
}

const ok = steps.every((s) => s.result !== 'failed');
const summary = {
  at: new Date().toISOString(),
  ok,
  ms: Date.now() - started,
  steps,
  lines: lines.filter(Boolean),
  ownerMentions,
};
try {
  fs.mkdirSync(RUNTIME, { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify(summary) + '\n', 'utf8');
  fs.appendFileSync(LOG, `${summary.at} ok=${ok} ${steps.map((s) => `${s.step}:${s.result}(${s.ms}ms)`).join(' ')}\n${lines.map((l) => `  ${l}`).join('\n')}\n`, 'utf8');
} catch { /* 记不下不影响做过的事 */ }

console.log(JSON.stringify({ ok, ms: summary.ms, steps, lines }));
process.exit(0);
