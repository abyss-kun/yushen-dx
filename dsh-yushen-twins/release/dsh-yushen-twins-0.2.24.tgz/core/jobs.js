// Copyright (c) 2026 从零开始 · 鱼神双子星 · AGPL-3.0-or-later（保留本行）
/* 标签
 * id: core-jobs
 * kind: module
 * summary: 派活单存储与取证（宿主无关）：只读写 dispatch.json、做审计与路径校验，不投消息、不碰 ctx。
 * tags: 派活单, 取证, 路径校验, 审计, 核心
 * created: 2026-11-11 00:45:00
 * changed: 2026-11-11 00:50:00
 * author: 大鱼·主代理（说明第二批）
 * authority: 老板（2026-11-11：说明要有格式）
 * audience: core/dispatch、宿主适配器、文件编辑类工具（复用 safePath）、维护者
 * owner: 框架；**允许根/安全路径**是安全边界，改要老板点头
 * defaults: 单条 result 最多 4000 字；读文件上限 120KB；扫描最多 400 文件/2MB
 * off: 没有开关；不想派单就别建单（删了等于派活单不存在）
 * mutable: 可改；safeRoots/safePath 只许收窄放宽要理由（放宽=能删到外面去）
 * usage: readAll/writeAll/audit/newId/clip/safeRoots/safePath/noteReply；写前 ensureDir
 * why: 单子曾经散在宿主里、路径校验各写一套；一次越界删文件就够呛
 * result: 一处存储 + 一处路径校验（Windows 大小写不敏感）+ 审计流水
 */
// 改｜2026-11-03 16:52｜大鱼·子会话（文件编辑）｜授权：老板｜core/jobs.js:56-75｜把三个允许根抽成 safeRoots() 供文件编辑复用；safePath 的比较在 Windows 上改为大小写不敏感｜为什么：新编辑器不能另写一套根；也不能因为盘符小写就误拦｜验证：node --check core/jobs.js；node scripts/test-dispatch-reply.mjs 过；node scripts/test-file-edit.mjs 12/0（含大小写用例）｜可改：可改
// core · 派活单（宿主无关）
// 只做存储与取证：不碰 ctx、不投消息；投递由宿主适配器负责。

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { execFile } from 'node:child_process'
import { recordFishState } from '../lib/state-adapter.js'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const FILE = path.join(DATA, 'dispatch.json')
const AUDIT = path.join(DATA, 'audit.jsonl')
const WORKSPACE = process.env.DSH_WORKSPACE || (fs.existsSync('D:\\DSH\\大小鱼') ? 'D:\\DSH\\大小鱼' : process.cwd())
const MAX_RESULT = 4000
const MAX_READ = 120 * 1024
const MAX_SCAN_FILES = 400
const MAX_SCAN_BYTES = 2 * 1024 * 1024

export function ensureDir() { fs.mkdirSync(DATA, { recursive: true }) }

export function readAll() {
  try {
    let text = fs.readFileSync(FILE, 'utf8')
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1)
    const raw = JSON.parse(text)
    return Array.isArray(raw) ? raw : []
  } catch { return [] }
}

export function writeAll(list) {
  ensureDir()
  const tmp = FILE + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(list.slice(0, 500), null, 2), 'utf8')
  fs.renameSync(tmp, FILE)
}

export function audit(row) {
  try {
    ensureDir()
    fs.appendFileSync(AUDIT, JSON.stringify({ at: new Date().toISOString(), ...row }) + '\n', 'utf8')
  } catch { /* 审计写不了不影响干活 */ }
}

export function newId() {
  return `job-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`
}

export function clip(text, max = MAX_RESULT) {
  const s = String(text || '')
  return s.length > max ? `${s.slice(0, max)}\n…（截断，共 ${s.length} 字）` : s
}

/** 允许读写的三个根（safePath 与文件编辑共用，别处不许另开一套）。 */
export function safeRoots() {
  return [path.resolve(WORKSPACE), path.resolve(HOME), path.resolve('D:\\deepseekTools')]
}

export function safePath(input) {
  const raw = String(input || '').trim()
  if (!raw) throw new Error('path 不能为空')
  const full = path.resolve(raw)
  // Windows 路径不区分大小写：d:\dsh 和 D:\DSH 是同一个地方，别在这里把人拦回去。
  const norm = (p) => (process.platform === 'win32' ? p.toLowerCase() : p)
  const bases = safeRoots().map(norm)
  const probe = norm(full)
  if (!bases.some((base) => probe === base || probe.startsWith(base + path.sep))) {
    throw new Error(`只能看工作区、.dsh 和 D:\\deepseekTools 下的文件：${full}`)
  }
  return full
}

/**
 * 收话：某条会话回了一句，挂到它的单子上。
 *
 * 2026-11-01 修（小鱼发现、老板点头）：原来是把「该会话第一张还在跑的单一律接住」，
 * 一句话的派活丢进常驻会话后，会话正在做的别的事收尾时那段话就被当成"这单的回复"——
 * 大鱼第一次返回的是「对你现实里的日子……」跟题无关，小鱼据此判"没收到"。
 *
 * 现在：
 *   1. 回话里带单号（`job-xxxx`）→ 精确挂那一单，`resultMatch = 'id'`；
 *   2. 不带单号 → 挂**最新**那张（按 createdAt），并标 `resultMatch = 'heuristic'`，
 *      让人知道"这条可能不是针对这一单的"；
 *   3. 已经按单号挂过结果的，后面再来的模糊回话不覆盖它（只加 replyCount）。
 */
export function noteReply(sessionId, text) {
  if (!sessionId || !text) return null
  const list = readAll()
  const body = String(text)
  const open = list.filter((t) => t.sessionId === sessionId && ['dispatched', 'returned', 'redispatched'].includes(t.status))
  if (!open.length) return null
  const newest = (a, b) => String(b.createdAt || b.dispatchedAt || '').localeCompare(String(a.createdAt || a.dispatchedAt || ''))
  const byId = open.filter((t) => body.includes(String(t.id))).sort(newest)
  const pick = byId[0] || [...open].sort(newest)[0]
  const match = byId.includes(pick) ? 'id' : 'heuristic'

  // 已经精确挂过结果的单，不许被后来的模糊回话盖掉
  if (pick.resultMatch === 'id' && match === 'heuristic') {
    pick.replyCount = Number(pick.replyCount || 0) + 1
    pick.lastReplyAt = new Date().toISOString()
    writeAll(list)
    audit({ kind: 'reply-ignored', id: pick.id, sessionId, chars: body.length, why: '已有按单号挂的结果，模糊回话不覆盖' })
    return pick
  }

  pick.result = clip(body)
  pick.resultMatch = match
  pick.status = 'returned'
  pick.returnedAt = new Date().toISOString()
  pick.lastReplyAt = pick.returnedAt
  pick.replyCount = Number(pick.replyCount || 0) + 1
  const hit = pick
  if (!hit) return null
  writeAll(list)
  try {
    recordFishState(hit.role || 'dayu', { expression: '思考', lastReason: hit.id })
  } catch { /* 状态记录不阻断收话 */ }
  audit({ kind: 'reply', id: hit.id, sessionId, chars: body.length, match })
  return hit
}

/** 取证：file / check / grep。纯本地，宿主无关。 */
export async function verifyEvidence(args = {}) {
  const kind = String(args?.kind ?? '')
  if (kind === 'file') {
    const full = safePath(args?.path)
    const st = fs.statSync(full)
    if (!st.isFile()) throw new Error('不是一个文件')
    const buf = fs.readFileSync(full)
    const lines = Math.max(1, Math.min(400, Number(args?.maxLines) || 60))
    const text = buf.slice(0, MAX_READ).toString('utf8')
    const head = text.split(/\r?\n/).slice(0, lines).join('\n')
    const sha = crypto.createHash('sha256').update(buf).digest('hex')
    audit({ kind: 'verify', evidence: 'file', path: full })
    return { ok: true, path: full, size: st.size, sha256: sha, lines, head }
  }
  if (kind === 'check') {
    const full = safePath(args?.path)
    if (!fs.existsSync(full)) throw new Error('文件不存在')
    const result = await new Promise((resolve) => {
      execFile(process.execPath, ['--check', full], { timeout: 15000, windowsHide: true }, (error, stdout, stderr) => {
        resolve({ ok: !error, code: error?.code ?? 0, out: String(stdout || '').slice(0, 2000), err: String(stderr || '').slice(0, 2000) })
      })
    })
    audit({ kind: 'verify', evidence: 'check', path: full, ok: result.ok })
    return { ok: true, path: full, syntax: result }
  }
  if (kind === 'grep') {
    const pattern = String(args?.pattern ?? '').trim()
    if (!pattern) throw new Error('pattern 不能为空')
    let re
    try { re = new RegExp(pattern, 'i') } catch { throw new Error('正则不合法') }
    const hits = []
    let scanned = 0
    const walk = (dir, depth) => {
      if (hits.length >= 40 || scanned >= MAX_SCAN_FILES || depth > 4) return
      let entries = []
      try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return }
      for (const entry of entries) {
        if (hits.length >= 40 || scanned >= MAX_SCAN_FILES) break
        if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.tmp') continue
        const full = path.join(dir, entry.name)
        if (entry.isDirectory()) { walk(full, depth + 1); continue }
        if (!/\.(js|mjs|cjs|json|md|txt|yml|yaml|css|html)$/i.test(entry.name)) continue
        scanned += 1
        try {
          const st = fs.statSync(full)
          if (st.size > MAX_SCAN_BYTES) continue
          const lines = fs.readFileSync(full, 'utf8').split(/\r?\n/)
          for (let i = 0; i < lines.length; i += 1) {
            if (re.test(lines[i])) {
              hits.push({ file: full, line: i + 1, text: lines[i].slice(0, 200) })
              if (hits.length >= 40) break
            }
          }
        } catch { /* 单文件失败跳过 */ }
      }
    }
    walk(WORKSPACE, 0)
    audit({ kind: 'verify', evidence: 'grep', pattern, hits: hits.length })
    return { ok: true, pattern, hits }
  }
  throw new Error('kind 只能是 file / grep / check')
}
