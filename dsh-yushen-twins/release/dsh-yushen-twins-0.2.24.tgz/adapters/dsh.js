// Copyright (c) 2026 从零开始 · 鱼神双子星 · AGPL-3.0-or-later（保留本行）
// DSH 适配器：把宿主能力映射成 core 的六能力契约。
// 只做接线，不写业务；core 里不许 import 这个文件。

import { attach } from '../core/host.js'
import { read as coreRead, write as coreWrite } from '../core/store.js'
import { promptRpc, createSessionRpc, selectModelRpc, listSessionsRpc, dshBaseUrl } from '../lib/dsh-rpc.js'
import { observeSessionEvent } from '../lib/session-governance.js'

export function createDshAdapter(ctx, { log } = {}) {
  const tools = (() => { try { return ctx.get?.('tools') ?? ctx.tools } catch { return undefined } })()
  const agents = (() => { try { return ctx.get?.('agents') ?? ctx.agents } catch { return undefined } })()

  return {
    name: 'dsh',
    /** 往某条会话投一句话：先走内存句柄，够不着再走 HTTP。 */
    async send(sessionId, text) {
      // 改｜2026-11-05 16:10｜大鱼·本机会话｜授权：老板（"让 dsh 适应你"）｜adapters/dsh.js:18-22｜
      // 为什么：宿主的 agents.get() 返回的是 **Agent 本身**（dsh-agent/lib/index.js:596 `get(id){ return store.get(id)?.agent }`），
      //   不是 { agent }。原写法 handle.agent.followup 对活会话恒为假，于是永远掉到 HTTP；手机没有 HTTP → 派活结构性不通。
      //   两种形状都认：handle.agent ?? handle。agents.create() 给的才是 { agent }。
      // 验证：node --check；重启后 dayu_dispatch 往活会话投递应返回 via:'agent'（不再报"够不到 HTTP"）。
      // 可改：可改；不要退回只看 handle.agent。
      const got = agents?.get?.(sessionId)
      const agent = got?.agent ?? got
      if (agent?.followup) {
        await agent.followup({ content: [{ type: 'text', text: String(text) }], source: { kind: 'user' } })
        return { ok: true, via: 'agent' }
      }
      if (dshBaseUrl()) {
        observeSessionEvent({ sessionId, eventType: 'prompt-sent', stage: 'in-progress', summary: '鱼神通过宿主 RPC 投递消息' })
        await promptRpc({ sessionId, text: String(text) })
        return { ok: true, via: 'rpc' }
      }
      throw new Error(`找不到会话 ${sessionId}，也够不到 HTTP`)
    },
    registerTool(tool) {
      if (!tools?.register) throw new Error('宿主没有 tools 服务')
      tools.register(tool)
    },
    /** 列会话：先读宿主快照，读不到再走 HTTP。 */
    async listSessions() {
      try {
        const sessions = ctx.get?.('sessions') ?? ctx.sessions
        const snap = sessions?.list?.getSnapshot?.()
        if (snap?.items) {
          return snap.items.map((it) => ({
            id: String(it.sessionId || ''),
            title: String(it.projections?.values?.title || ''),
            running: Boolean(it.running),
          }))
        }
      } catch { /* 退到 HTTP */ }
      try { return await listSessionsRpc() } catch { return [] }
    },
    /** 建会话：优先 HTTP RPC（宿主的 agents.create 不认模型参数）。 */
    async createSession({ cwd } = {}) {
      if (dshBaseUrl()) {
        const id = await createSessionRpc({ cwd })
        await selectModelRpc({ sessionId: id })
        return { id, via: 'rpc' }
      }
      if (!agents?.create) throw new Error('既不知道 DSH 地址，宿主也没给 agents 服务')
      const handle = await agents.create({ meta: { cwd }, agentOptions: { provider: 'deepseek-account', model: 'deepseek-flash', reasoningEffort: 'high' } })
      const id = handle?.sessionId || handle?.id
      if (!id) throw new Error('agents.create 没给会话 id')
      return { id, via: 'agent' }
    },
    onEvent(fn) {
      if (!ctx.on) return
      ctx.on('session/event', (session, event) => { try { fn({ session, event }) } catch { /* 忽略 */ } })
    },
    read(rel) { return coreRead(rel, '') },
    write(rel, text) { coreWrite(rel, text) },
    serve(route, handler) {
      ctx.effect?.(() => ctx.webServer.register({ kind: 'prefix', path: route, handler }))
    },
    auth() { return true },
    log: log || (() => {}),
  }
}

/** 接上 DSH；失败不挡启动。 */
export function attachDsh(ctx, opts) {
  try {
    const adapter = createDshAdapter(ctx, opts)
    attach(adapter)
    return adapter
  } catch { return null }
}
