// 三问审计：最近碰了 lib/dayu 的改动，有没有答三问。
//
//   node scripts/tq-audit.mjs [条数]
//
// 只查账本（worklog），不查代码；没有 tq 的就是"改了但没过三问"。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const FILE = path.join(HOME, 'dayu', 'worklog.jsonl')
const limit = Math.max(1, Number(process.argv[2] || 40))

let rows = []
try {
  rows = fs.readFileSync(FILE, 'utf8').trim().split(/\r?\n/).filter(Boolean).slice(-limit)
    .map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
} catch { rows = [] }

const touchesHer = (r) => (r.files || []).some((f) => /(^|[\\/])(lib|dayu|xiaoyu)[\\/]/.test(f) || /\blib\//.test(f))
const hers = rows.filter(touchesHer)
const missing = hers.filter((r) => !String(r.tq || '').includes('①') || !String(r.tq || '').includes('②') || !String(r.tq || '').includes('③'))

console.log(JSON.stringify({
  ok: missing.length === 0,
  scanned: rows.length,
  herChanges: hers.length,
  missingTq: missing.length,
  items: missing.map((r) => ({ at: r.at, what: r.what, files: (r.files || []).slice(0, 3) })),
}, null, 2))
process.exit(missing.length === 0 ? 0 : 2)
