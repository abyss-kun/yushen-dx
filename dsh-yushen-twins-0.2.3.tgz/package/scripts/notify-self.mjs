// 给某一位写一条「变更告知」——动了她东西的人用它留话。
//
//   node scripts/notify-self.mjs --role dayu --what "记忆注入从 3400 字改成只带最近几条" --why "她每轮要读太多" --by 员工
//   node scripts/notify-self.mjs --role dayu --list
//   node scripts/notify-self.mjs --role dayu --mark
import { notifySelf, listNotices, unreadNotices, markNoticesRead } from '../lib/notices.js'

const argv = process.argv.slice(2)
const get = (k, d = '') => {
  const i = argv.indexOf(`--${k}`)
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : d
}
const has = (k) => argv.includes(`--${k}`)

const role = get('role', 'dayu')
try {
  if (has('list')) {
    const items = listNotices(role, { limit: Number(get('limit', 20)) })
    console.log(`${role} 的变更告知：未读 ${unreadNotices(role)} 条，共 ${items.length} 条（最近在前）`)
    for (const n of items) console.log(`  [${n.read ? '已读' : '未读'}] ${n.at.slice(5, 16).replace('T', ' ')}  ${n.what}${n.why ? `（为什么：${n.why}）` : ''}`)
  } else if (has('mark')) {
    console.log(JSON.stringify(markNoticesRead(role)))
  } else {
    const what = get('what')
    if (!what) {
      console.log('用法：--role dayu --what "改了什么" [--why "为什么"] [--by 谁] | --list | --mark')
      process.exit(1)
    }
    const r = notifySelf(role, { what, why: get('why'), by: get('by', '员工'), reversible: !has('irreversible') })
    console.log(`记下了：${r.id}（${role} 现有 ${r.count} 条）`)
  }
} catch (e) {
  console.error(`出错：${e?.message || e}`)
  process.exit(1)
}
