// 鱼神双子星 · 晋升系统自测
// 覆盖：不足拒绝 / 达标只给 pending / 主人显式批准后才逐级开放能力 / 角色隔离 /
//       非法角色 / 禁止自己批准 / 最高阶不再晋升 / 快照不改 persona / XP 不会自动变权限。
// 全部在临时 DSH_HOME 里跑，host 无关、不调模型；只碰 dayu 数据目录，跑完清理。
//
// 运行：C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe dsh-yushen-twins/scripts/test-promotion.mjs

import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const BASE = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-promotion-'))
const HOME = path.join(BASE, 'home')
fs.mkdirSync(HOME, { recursive: true })
process.env.DSH_HOME = HOME

// growth / authz 在模块加载时锁 DSH_HOME，必须先设环境再 import。
const {
  PROMOTION_CAPS,
  PROMOTION_RULES,
  approvePromotion,
  capsForLevel,
  evaluatePromotion,
  getPromotion,
  listPromotions,
  promotionFile,
  requestPromotion,
} = await import('../lib/promotion.js')
const { adjust, status: growthStatus } = await import('../lib/growth.js')
const { recordExperience } = await import('../lib/task-experience.js')
const { CAPS } = await import('../lib/authz.js')

const DANGEROUS = ['exec.run', 'self.patch', 'host.restart', 'owner.write']

let passed = 0
let failed = 0
const failures = []

async function check(name, fn) {
  try {
    await fn()
    passed += 1
    console.log(`  ok   ${name}`)
  } catch (err) {
    failed += 1
    failures.push({ name, err })
    console.log(`  FAIL ${name}`)
    console.log(`       ${err && err.message ? err.message : err}`)
  }
}

function resetData() {
  fs.rmSync(path.join(HOME, 'dayu'), { recursive: true, force: true })
}

function seedGrowth(role, xp) {
  adjust({ xp, role })
}

// 任务只写 dispatch.json：字段与 core/jobs.js 的账单一致。
function seedTasks(role, specs) {
  const rows = specs.map((spec, index) => {
    const attempts = Number(spec.attempts || 1)
    return {
      id: `task-${role}-${index + 1}`,
      sessionId: `sess-${role}-${index + 1}`,
      employee: '测试会话',
      brief: `任务 ${index + 1}`,
      role,
      attempts,
      maxAttempts: 3,
      status: spec.status,
      evidence: spec.evidence === false ? [] : [{ attempt: attempts, ok: true, kind: 'file', at: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
    }
  })
  fs.mkdirSync(path.join(HOME, 'dayu'), { recursive: true })
  fs.writeFileSync(path.join(HOME, 'dayu', 'dispatch.json'), `${JSON.stringify(rows, null, 2)}\n`, 'utf8')
}

function seedExperience(role, verified, failedCount = 0) {
  for (let i = 0; i < verified; i += 1) {
    recordExperience(role, {
      taskId: `exp-ok-${role}-${i}`,
      brief: `已验证经验 ${i}`,
      outcome: 'success',
      verified: true,
      evidence: '测试通过',
      tags: ['promotion-test'],
    })
  }
  for (let i = 0; i < failedCount; i += 1) {
    recordExperience(role, {
      taskId: `exp-fail-${role}-${i}`,
      brief: `失败经验 ${i}`,
      outcome: 'failed',
      tags: ['promotion-test'],
    })
  }
}

function seedReady(role, xp = 0) {
  resetData()
  seedGrowth(role, xp)
  seedTasks(role, [
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'aborted' },
  ])
  seedExperience(role, 2)
}

function charterCaps() {
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(HOME, 'dayu', 'charter.json'), 'utf8'))
    const list = raw?.authority?.l2
    return Array.isArray(list) ? list.slice().sort() : null
  } catch {
    return null
  }
}

function sorted(list) {
  return list.slice().sort()
}

// ---------------- 不足拒绝 ----------------

await check('不足：新角色未达标，reasons 说明缺什么，申请被拒且不落盘', () => {
  resetData()
  const ev = evaluatePromotion('xiaoyu')
  assert.equal(ev.ok, true)
  assert.equal(ev.readiness, false)
  assert.equal(ev.current.level, 0)
  assert.equal(ev.next.level, 1)
  assert.equal(ev.metrics.tasks, 0)
  assert.ok(ev.reasons.some((line) => line.includes('任务总数')))
  assert.ok(ev.reasons.some((line) => line.includes('已验证经验')))

  assert.throws(() => requestPromotion('xiaoyu', { selfAssessment: '我很努力' }), /还不满足晋升条件/)
  assert.equal(fs.existsSync(path.join(HOME, 'dayu', 'promotions')), false)
})

await check('不足：完成率 / 证据率 / 在途单 / 已验证经验分别能单独拦下', () => {
  // 完成率不足：3 单成 2，完成率 66.7%
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [{ status: 'done' }, { status: 'done' }, { status: 'aborted' }])
  seedExperience('xiaoyu', 2)
  const lowDone = evaluatePromotion('xiaoyu')
  assert.equal(lowDone.readiness, false)
  assert.ok(lowDone.reasons.some((line) => line.includes('完成率')))

  // 证据率不足：3 单全成，只有 2 单有本轮证据
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [{ status: 'done' }, { status: 'done' }, { status: 'done', evidence: false }])
  seedExperience('xiaoyu', 2)
  const lowEvidence = evaluatePromotion('xiaoyu')
  assert.equal(lowEvidence.readiness, false)
  assert.ok(lowEvidence.reasons.some((line) => line.includes('证据率')))

  // 有在途单
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [{ status: 'done' }, { status: 'done' }, { status: 'done' }, { status: 'done' }, { status: 'dispatched' }])
  seedExperience('xiaoyu', 2)
  const busy = evaluatePromotion('xiaoyu')
  assert.equal(busy.readiness, false)
  assert.ok(busy.reasons.some((line) => line.includes('进行中')))

  // 已验证经验不足：只有 1 条成功 + 1 条失败
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [{ status: 'done' }, { status: 'done' }, { status: 'done' }])
  seedExperience('xiaoyu', 1, 1)
  const lowExp = evaluatePromotion('xiaoyu')
  assert.equal(lowExp.readiness, false)
  assert.ok(lowExp.reasons.some((line) => line.includes('已验证经验')))
})

await check('不足：已是最高阶时没有下一阶可晋升', () => {
  resetData()
  seedGrowth('dayu', 1000) // Lv4 归一
  seedTasks('dayu', [{ status: 'done' }, { status: 'done' }, { status: 'done' }])
  seedExperience('dayu', 2)
  const ev = evaluatePromotion('dayu')
  assert.equal(ev.current.level, 4)
  assert.equal(ev.next, null)
  assert.equal(ev.readiness, false)
  assert.ok(ev.reasons.some((line) => line.includes('最高阶')))
})

// ---------------- 达标 → 只 pending ----------------

await check('达标：只生成 pending 申请，不自动批准、不发能力', () => {
  seedReady('xiaoyu', 0)
  const ev = evaluatePromotion('xiaoyu')
  assert.equal(ev.readiness, true)
  assert.equal(ev.metrics.tasks, 5)
  assert.equal(ev.metrics.done, 4)
  assert.equal(ev.metrics.completionRate, 0.8)
  assert.equal(ev.metrics.evidenceRate, 1)
  assert.equal(ev.metrics.verifiedExperience, 2)

  const res = requestPromotion('xiaoyu', { selfAssessment: '我很努力，请批准' })
  assert.equal(res.ok, true)
  assert.equal(res.approved, false)
  assert.equal(res.promotion.status, 'pending')
  assert.equal(res.promotion.approvedAt, null)
  assert.deepEqual(res.promotion.grantedCaps, [])
  assert.equal(res.promotion.selfAssessment, '我很努力，请批准')
  assert.match(res.promotion.selfAssessmentNote, /不构成授权/)
  assert.match(res.note, /不构成任何授权/)

  // 申请本身不升阶、不给能力、不写 charter
  assert.equal(growthStatus('xiaoyu').level, 0)
  assert.equal(charterCaps(), null)

  const file = promotionFile('xiaoyu')
  assert.ok(fs.existsSync(file))
  assert.equal(listPromotions().length, 1)
  assert.equal(getPromotion('xiaoyu').id, res.promotion.id)
  assert.equal(getPromotion(res.promotion.id).role, 'xiaoyu')
})

// ---------------- 禁止自己批准 ----------------

await check('禁止自己批准：缺主人标记 / 批准人是自己都拒绝，申请保持 pending', () => {
  seedReady('xiaoyu', 0)
  const { promotion } = requestPromotion('xiaoyu', { selfAssessment: '我自己批自己' })

  assert.throws(() => approvePromotion(promotion.id), /必须由主人显式批准/)
  assert.throws(() => approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'xiaoyu' }), /不能自己批准/)
  assert.throws(() => approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'dayu' }), /不能自己批准/)
  assert.throws(() => approvePromotion(promotion.id, { ownerApproved: true }), /缺少批准人/)

  assert.equal(getPromotion(promotion.id).status, 'pending')
  assert.equal(growthStatus('xiaoyu').level, 0)
  assert.equal(charterCaps(), null, '没批准就不能开任何能力')
})

// ---------------- 批准后逐级开放 ----------------

await check('批准 Lv1：只开 model.switch，不全开；阶位落实但不碰人格', () => {
  seedReady('xiaoyu', 0)
  const { promotion } = requestPromotion('xiaoyu')

  const ok = approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'owner', note: '干得不错' })
  assert.equal(ok.ok, true)
  assert.equal(ok.promotion.status, 'approved')
  assert.equal(ok.promotion.approvedBy, 'owner')
  assert.equal(typeof ok.promotion.approvedAt, 'string')
  assert.deepEqual(ok.grantedCaps, capsForLevel(1))
  assert.deepEqual(ok.grantedCaps, ['model.switch'])
  assert.equal(ok.level, 1)
  assert.equal(growthStatus('xiaoyu').level, 1)

  assert.deepEqual(charterCaps(), ['model.switch'])
  for (const cap of DANGEROUS) assert.equal(charterCaps().includes(cap), false, `不能开 ${cap}`)

  assert.throws(
    () => approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'owner' }),
    /不是 pending/,
    '同一条申请不能批两次',
  )
})

await check('逐级：Lv2 累计到 3 个能力，仍不全开；Lv3 才加 pool/rotate', () => {
  seedReady('xiaoyu', 0)
  const first = requestPromotion('xiaoyu')
  approvePromotion(first.promotion.id, { ownerApproved: true, approvedBy: 'owner' })

  // 同一批任务仍达标，可以继续申请下一阶
  const second = requestPromotion('xiaoyu')
  assert.equal(second.promotion.target.level, 2)
  const ok2 = approvePromotion(second.promotion.id, { ownerApproved: true, approvedBy: 'owner' })
  assert.deepEqual(ok2.grantedCaps, capsForLevel(2))
  assert.deepEqual(ok2.grantedCaps, ['model.switch', 'session.cleanup', 'incident.resolve'])
  assert.deepEqual(charterCaps(), sorted(capsForLevel(2)))
  assert.equal(growthStatus('xiaoyu').level, 2)

  const third = requestPromotion('xiaoyu')
  assert.equal(third.promotion.target.level, 3)
  const ok3 = approvePromotion(third.promotion.id, { ownerApproved: true, approvedBy: 'owner' })
  assert.deepEqual(ok3.grantedCaps, capsForLevel(3))
  assert.ok(ok3.grantedCaps.includes('pool.ensure'))
  assert.ok(ok3.grantedCaps.includes('session.rotate'))
  assert.equal(ok3.grantedCaps.includes('growth.adjust'), false, 'Lv3 不该提前给 Lv4 的能力')
  assert.deepEqual(charterCaps(), sorted(capsForLevel(3)))
  assert.equal(growthStatus('xiaoyu').level, 3)
})

await check('高阶 Lv4 也不全开：仍不给 exec.run / self.patch / host.restart / owner.write', () => {
  seedReady('dayu', 400) // 大鱼常驻下限三阶
  const ev = evaluatePromotion('dayu')
  assert.equal(ev.current.level, 3)
  assert.equal(ev.next.level, 4)
  assert.equal(ev.readiness, true)

  const { promotion } = requestPromotion('dayu')
  const ok = approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'owner' })
  assert.equal(ok.level, 4)
  assert.deepEqual(ok.grantedCaps, capsForLevel(4))
  assert.equal(ok.grantedCaps.length, 6)
  assert.equal(ok.grantedCaps.length < CAPS.length, true, '晋升不能把能力表全开')

  const caps = charterCaps()
  assert.deepEqual(caps, sorted(capsForLevel(4)))
  for (const cap of DANGEROUS) assert.equal(caps.includes(cap), false)
})

// ---------------- 角色隔离 ----------------

await check('角色隔离：申请、评估、成长各按角色，互不串', () => {
  resetData()
  seedGrowth('dayu', 400)
  seedTasks('dayu', [])
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'aborted' },
  ])
  seedExperience('xiaoyu', 2)

  const dayuEval = evaluatePromotion('dayu')
  const xiaoyuEval = evaluatePromotion('xiaoyu')
  assert.equal(dayuEval.readiness, false, 'dayu 没有任务，不能借 xiaoyu 的')
  assert.equal(xiaoyuEval.readiness, true)

  assert.throws(() => requestPromotion('dayu'), /还不满足晋升条件/)
  const xiaoyuReq = requestPromotion('xiaoyu')
  assert.equal(listPromotions().length, 1)
  assert.equal(getPromotion('dayu'), null)
  assert.equal(getPromotion(xiaoyuReq.promotion.id).role, 'xiaoyu')
  assert.equal(fs.existsSync(promotionFile('dayu')), false)

  approvePromotion(xiaoyuReq.promotion.id, { ownerApproved: true, approvedBy: 'owner' })
  assert.equal(growthStatus('xiaoyu').level, 1)
  assert.equal(growthStatus('dayu').level, 3, 'dayu 的阶位不能被 xiaoyu 的批准带动')
})

// ---------------- 非法角色 / 查询 ----------------

await check('非法角色：评估 / 申请 / 路径全部拒绝；空家目录 list/get 安全', () => {
  resetData()
  const bad = ['../evil', 'DAYU', 'dayu ', ' admin', '', null, undefined, 123, ['dayu']]
  for (const role of bad) {
    assert.throws(() => evaluatePromotion(role), /未知角色/)
    assert.throws(() => requestPromotion(role), /未知角色/)
    assert.throws(() => promotionFile(role), /未知角色/)
  }
  assert.deepEqual(listPromotions(), [])
  assert.equal(getPromotion('dayu'), null)
  assert.equal(getPromotion('promo-nope'), null)
  assert.equal(getPromotion(''), null)
  assert.throws(() => approvePromotion('', { ownerApproved: true, approvedBy: 'owner' }), /缺少晋升申请 id/)
})

// ---------------- 快照：不改人格 ----------------

await check('快照：评估/申请/批准都不改 persona 与 state 文件', () => {
  seedReady('xiaoyu', 0)
  const stateDir = path.join(HOME, 'dayu', 'state')
  fs.mkdirSync(stateDir, { recursive: true })
  fs.writeFileSync(path.join(stateDir, 'dayu.json'), '{"persona":{"name":"大鱼","core":"管家"},"mood":77}\n', 'utf8')
  fs.writeFileSync(path.join(stateDir, 'xiaoyu.json'), '{"persona":{"name":"小肥鱼","core":"妹妹"},"mood":55}\n', 'utf8')
  const before = ['dayu.json', 'xiaoyu.json'].map((name) => fs.readFileSync(path.join(stateDir, name), 'utf8'))

  evaluatePromotion('xiaoyu')
  const { promotion } = requestPromotion('xiaoyu', { selfAssessment: '申请说明' })
  approvePromotion(promotion.id, { ownerApproved: true, approvedBy: 'owner' })

  const after = ['dayu.json', 'xiaoyu.json'].map((name) => fs.readFileSync(path.join(stateDir, name), 'utf8'))
  assert.deepEqual(after, before, '晋升系统不能改人格或心情状态')
})

// ---------------- XP ≠ 权限 ----------------

await check('XP 不会自动变权限：只调 XP 不产生申请、不写白名单', () => {
  resetData()
  adjust({ xp: 1000, role: 'dayu' })
  assert.equal(growthStatus('dayu').level, 4)

  assert.deepEqual(listPromotions(), [])
  assert.equal(charterCaps(), null, 'XP 再高也不能自动开能力')
  const ev = evaluatePromotion('dayu')
  assert.equal(ev.readiness, false, '没有任务证据，光是 XP 高不能晋升')
  assert.throws(() => requestPromotion('dayu'))
  assert.equal(charterCaps(), null)
})

// ---------------- 阈值常量 ----------------

await check('阈值常量：导出且边界生效（完成率/证据率 0.8 为合格线）', () => {
  assert.deepEqual({ ...PROMOTION_RULES }, {
    minTasks: 3,
    minCompletionRate: 0.8,
    minEvidenceRate: 0.8,
    minVerifiedExperience: 2,
    requireNoActive: true,
  })
  assert.deepEqual(capsForLevel(1), ['model.switch'])
  assert.deepEqual(capsForLevel(2), ['model.switch', 'session.cleanup', 'incident.resolve'])
  assert.equal(capsForLevel(3).length, 5)
  assert.equal(capsForLevel(4).length, 6)

  // 恰好 0.8：4 成 / 5 单 → 达标
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'done' },
    { status: 'aborted' },
  ])
  seedExperience('xiaoyu', 2)
  const edge = evaluatePromotion('xiaoyu')
  assert.equal(edge.metrics.completionRate, 0.8)
  assert.equal(edge.metrics.evidenceRate, 1)
  assert.equal(edge.readiness, true)

  // 2/3 完成率 = 0.667 → 不达标
  resetData()
  seedGrowth('xiaoyu', 0)
  seedTasks('xiaoyu', [{ status: 'done' }, { status: 'done' }, { status: 'aborted' }])
  seedExperience('xiaoyu', 2)
  const below = evaluatePromotion('xiaoyu')
  assert.equal(below.metrics.completionRate < 0.8, true)
  assert.equal(below.readiness, false)
})

// ---------------- 收尾 ----------------

fs.rmSync(BASE, { recursive: true, force: true })

console.log('')
console.log(`结果：通过 ${passed}，失败 ${failed}`)
if (failed) {
  console.log('失败明细：')
  for (const item of failures) console.log(` - ${item.name}: ${item.err && item.err.message ? item.err.message : item.err}`)
  process.exitCode = 1
} else {
  console.log('promotion：全部断言通过')
  process.exitCode = 0
}
