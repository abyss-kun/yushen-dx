// 打包发行：干净目录 → 自检 → zip + tgz + 校验和 + 发布说明。
// 运行：node scripts/build-release.mjs

import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const PKG = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'))
const version = PKG.version || '0.0.0'
const DIST = path.join(ROOT, 'dist', 'dsh-yushen-twins')
const OUT = path.join(ROOT, 'release')
const node = process.execPath

console.log('1. 打干净目录')
// 2026-10-30：打包前先给「上一个能跑的版本」留快照（只留最近 3 份）。
// 出问题用 `node scripts/rollback.mjs --last` 退回去，只退代码、不动数据。
const SNAPS = path.join(ROOT, '.snapshots')
try {
  if (fs.existsSync(DIST)) {
    const prevVersion = (() => { try { return JSON.parse(fs.readFileSync(path.join(DIST, 'package.json'), 'utf8')).version || 'unknown' } catch { return 'unknown' } })()
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    const dir = path.join(SNAPS, `${prevVersion}-${stamp}`)
    fs.mkdirSync(dir, { recursive: true })
    fs.cpSync(DIST, path.join(dir, 'dsh-yushen-twins'), { recursive: true })
    fs.writeFileSync(path.join(dir, 'SNAPSHOT.json'), JSON.stringify({ version: prevVersion, at: new Date().toISOString() }, null, 2) + '\n', 'utf8')
    const all = fs.readdirSync(SNAPS).filter((n) => fs.statSync(path.join(SNAPS, n)).isDirectory()).sort()
    for (const old of all.slice(0, Math.max(0, all.length - 3))) fs.rmSync(path.join(SNAPS, old), { recursive: true, force: true })
    console.log(`   快照：${prevVersion}`)
  }
} catch (error) { console.log('   快照没做成（不影响打包）：' + String(error?.message || error)) }

execFileSync(node, [path.join(ROOT, 'scripts', 'pack-release.mjs')], { stdio: 'inherit' })

console.log('2. 出厂自检')
execFileSync(node, [path.join(ROOT, 'scripts', 'verify-package.mjs'), DIST], { stdio: 'inherit' })

console.log('3. 压缩')
fs.mkdirSync(OUT, { recursive: true })
const base = `dsh-yushen-twins-${version}`
const zip = path.join(OUT, `${base}.zip`)
const tgz = path.join(OUT, `${base}.tgz`)
for (const f of [zip, tgz]) { try { fs.rmSync(f, { force: true }) } catch { /* 没有 */ } }

execFileSync('powershell.exe', ['-NoProfile', '-Command',
  `Compress-Archive -Path '${path.join(DIST, '*')}' -DestinationPath '${zip}' -Force`], { stdio: 'inherit' })
execFileSync('tar.exe', ['-czf', tgz, '-C', DIST, '.'], { stdio: 'inherit' })

const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')
const size = (f) => (fs.statSync(f).size / 1024 / 1024).toFixed(2)
const rows = [zip, tgz].map((f) => `| ${path.basename(f)} | ${size(f)} MB | \`${sha(f).slice(0, 16)}\` |`)

const note = [
  `# 发行包 ${version}`,
  '',
  `- 生成：${new Date().toISOString()}`,
  `- 目录：\`${DIST}\``,
  '',
  '| 文件 | 大小 | sha256（前16） |',
  '|---|---|---|',
  ...rows,
  '',
  '## 装法',
  '',
  '1. 解压到任意目录（或 `dsh plugin add <tgz>`，按宿主支持的方式）；',
  '2. 在 DSH 的插件清单里指向解压目录（`package.json` 的 link 依赖）；',
  '3. 重启 DSH，侧边栏出现「鱼神」。',
  '',
  '## 第一次打开',
  '',
  '- 走「就职」：填称呼、话量、禁忌；',
  '- 数据留在 `~/.dsh/dayu`（要带走的用搬家包）；',
  '- 自带内核 + 白纸，不带作者的魂与记忆。',
  '',
  '## 出厂自检',
  '',
  '`node scripts/verify-package.mjs`（包内）；运行期 `smoke/live-check` 需要宿主。',
  '',
].join('\n')
fs.writeFileSync(path.join(OUT, `发布说明-${version}.md`), note, 'utf8')
console.log(`4. 完成：${OUT}`)
for (const f of [zip, tgz]) console.log(`   ${path.basename(f)}  ${size(f)} MB`)
