import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
const base = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-coordination-'))
process.env.DSH_HOME = path.join(base, 'home')
process.env.DSH_WORKSPACE = path.join(base, 'workspace')
fs.mkdirSync(process.env.DSH_WORKSPACE, {recursive:true})
const { classifyTaskOverlap, findTaskConflicts } = await import('../lib/task-coordination.js')
const { dispatch, verdict, reviewWaitingTask } = await import('../core/dispatch.js')
try {
  const first = {brief:'修复共享记忆召回逻辑',expect:'creative-memory.js相关测试通过',status:'dispatched',id:'job-old'}
  assert.equal(classifyTaskOverlap({brief:'修复共享记忆召回逻辑',expect:'creative-memory.js相关测试通过'}, first).kind, 'duplicate')
  assert.equal(classifyTaskOverlap({brief:'在共享记忆召回逻辑增加日志',expect:'creative-memory.js相关测试通过'}, first).kind, 'conflict')
  assert.equal(classifyTaskOverlap({brief:'检查共享记忆召回逻辑的QQ入口',expect:'creative-memory.js相关测试通过'}, first).kind, 'conflict')
  assert.equal(classifyTaskOverlap({brief:'调整 dashboard 图表颜色',expect:'截图无溢出'}, first).kind, 'independent')
  assert.equal(findTaskConflicts({brief:'查看当前任务',expect:''}, [first]).length, 0)

  const homeData = path.join(process.env.DSH_HOME, 'dayu')
  fs.mkdirSync(homeData, {recursive:true})
  fs.writeFileSync(path.join(homeData,'dispatch.json'), JSON.stringify([first]))
  const duplicateHost = {cwd:process.env.DSH_WORKSPACE, async listSessions(){throw new Error('duplicate must not allocate')}, async send(){throw new Error('duplicate must not send')}, async createSession(){throw new Error('duplicate must not create')}}
  const dup = await dispatch(duplicateHost,{brief:first.brief,expect:first.expect})
  assert.equal(dup.deduped,true)
  assert.equal(dup.id,'job-old')
  assert.equal(JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8')).length,1)

  let touched = false
  const conflictHost = {cwd:process.env.DSH_WORKSPACE, async listSessions(){touched=true;return[]}, async send(){touched=true}, async createSession(){touched=true;return{id:'new'}}}
  const wait = await dispatch(conflictHost,{brief:'检查共享记忆召回逻辑的QQ入口',expect:'creative-memory.js相关测试通过'})
  assert.equal(wait.waiting,true)
  assert.deepEqual(wait.dependsOn,['job-old'])
  assert.equal(touched,false)
  assert.equal(JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8')).length,2)
  await assert.rejects(() => reviewWaitingTask({id:wait.id,action:'skip',evidence:''}), /实际证据/)

  const messages = []
  const evidenceHost = {cwd:process.env.DSH_WORKSPACE, async send(id,text){messages.push({id,text})}}
  const oldList = JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8'))
  oldList.find((row) => row.id === 'job-old').status = 'done'
  fs.writeFileSync(path.join(homeData,'dispatch.json'), JSON.stringify(oldList))
  await verdict(evidenceHost,{id:'job-old',verdict:'pass',note:'file hash + test output'})
  assert.equal(messages.length,1)
  assert.match(messages[0].text,/等待单/)
  assert.match(messages[0].text,/实际检查/)
  const ready = JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8')).find((row) => row.id === wait.id)
  assert.equal(ready.status,'ready-for-review')
  const skipped = await reviewWaitingTask({id:wait.id,action:'skip',evidence:'前置单结果文件 SHA256=abc；测试命令退出码 0；目标范围完全一致'})
  assert.equal(skipped.task.status,'skipped')
  assert.match(skipped.task.result,/复用前置任务/)

  const beforeSecond = JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8'))
  beforeSecond.find((row) => row.id === 'job-old').status = 'dispatched'
  fs.writeFileSync(path.join(homeData,'dispatch.json'), JSON.stringify(beforeSecond))
  const secondWait = await dispatch(conflictHost,{brief:'检查共享记忆召回逻辑的QQ入口',expect:'creative-memory.js相关测试通过'})
  assert.equal(secondWait.waiting,true)
  const list2 = JSON.parse(fs.readFileSync(path.join(homeData,'dispatch.json'),'utf8'))
  list2.find((row) => row.id === 'job-old').status = 'done'
  fs.writeFileSync(path.join(homeData,'dispatch.json'), JSON.stringify(list2))
  await verdict(evidenceHost,{id:'job-old',verdict:'pass',note:'same evidence'})
  const ready2 = await reviewWaitingTask({id:secondWait.id,action:'continue',evidence:'检查前置文件清单与测试输出，确认仅剩QQ入口'})
  assert.equal(ready2.task.status,'ready')
  const resumed = await dispatch(conflictHost,{brief:secondWait.brief,expect:secondWait.expect,reviewedId:secondWait.id})
  assert.equal(resumed.id,secondWait.id)
  assert.equal(resumed.reusedWaiting,true)
  assert.equal(resumed.status,'dispatched')
  console.log('PASS duplicate reuse, conflict parking, evidence-gated review, safe skip, reviewed resume, independent tasks remain dispatchable')
} finally {
  assert.ok(path.basename(base).startsWith('yushen-coordination-'))
  fs.rmSync(base,{recursive:true,force:true})
}
