// 生成模块地图附录：lib 里每个文件是干什么的、多长、被谁引用。
// 只读代码，不改任何东西。跑法：node scripts/map.mjs
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const LIB = path.join(ROOT, 'lib')
const OUT = path.join(ROOT, 'docs', '模块地图-附录.md')

// 分组：靠文件名关键词，主文档里只写组名和一两个代表
const GROUPS = [
  ['地基（路径/运行时/权限）', /^(paths|runtime|state|plug|auth|authz|owner-guard|security|schema|adapter|rpc|dsh-rpc|exec|env)/],
  ['身份与点化', /^(characters|awakening|identity|soul|bottom-line|migrate|plug|profile|residence)/],
  ['记忆与回忆', /^(memory|mind|journal|capture|recap|transcript|threads|knowledge|task-experience|creative-memory|shared-memory|notes)/],
  ['意志（议程/拒绝/越线/心情）', /^(agenda|invoke|freetime|claim|refuse|objection|veto|cross|self|mood|feel|bottom|tendency|wait)/],
  ['说话与通道', /^(inbox|outbox|translator|analyze|brief|channel|group|decide-body|fish-guard|recap)/],
  ['干活与治理', /^(jobs|employees|employee|handbook|solutions|incident|patch|repair|recovery|policy|promotion|selfcheck)/],
  ['账与钱', /^(cost|budget|ledger|spend|pricing|usage)/],
  ['备份与交付', /^(backup|versioned|pack|uninstall|release|artifact|software)/],
  ['界面与形象', /^(nest|pet|scene|visual|avatar|halo|style|font|render)/],
  ['其他', /.*/],
]

const readText = (p) => fs.readFileSync(p, 'utf8')
const lineCount = (s) => s.split(/\r?\n/).length

// fan-in：全仓扫 import
const allFiles = []
const walk = (d) => {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name)
    if (e.isDirectory()) { if (!/node_modules|dist|archive|\.state|\.git/.test(p)) walk(p) } else if (/\.(js|mjs)$/.test(e.name)) allFiles.push(p)
  }
}
walk(ROOT)
const fanin = new Map()
for (const p of allFiles) {
  // 2026-10-30：原来只统计路径里带 lib/ 的 import，同目录 import（./soul.js）全漏了。
  // 现在按 basename 统计所有相对 import。
  for (const m of readText(p).matchAll(/from\s+['"]([^'"]+)['"]/g)) {
    const spec = m[1]
    if (!spec.startsWith('.')) continue
    const b = path.basename(spec)
    fanin.set(b, (fanin.get(b) || 0) + 1)
  }
}

const rows = fs.readdirSync(LIB).filter((f) => f.endsWith('.js') && !f.includes('.bak')).map((f) => {
  const src = readText(path.join(LIB, f))
  const head = (src.split(/\r?\n/).find((l) => l.trim().startsWith('//') && !l.includes('Copyright')) || '')
    .replace(/^\s*\/\/\s*/, '').trim()
  return { f, lines: lineCount(src), head: head.slice(0, 60), fanin: fanin.get(f) || 0 }
})

const used = new Set()
const sections = []
for (const [title, re] of GROUPS) {
  const inGroup = rows.filter((r) => !used.has(r.f) && re.test(r.f))
  for (const r of inGroup) used.add(r.f)
  if (!inGroup.length) continue
  inGroup.sort((a, b) => b.fanin - a.fanin || b.lines - a.lines)
  const body = inGroup.map((r) => `| \`${r.f}\` | ${r.lines} | ${r.fanin}× | ${r.head || '（无头注释）'} |`).join('\n')
  sections.push(`## ${title}（${inGroup.length} 个）\n\n| 文件 | 行 | 被引用 | 一句话 |\n|---|---:|---:|---|\n${body}\n`)
}

const doc = `# 模块地图 · 附录（自动生成）

> 由 \`scripts/map.mjs\` 从代码生成，不要手改。
> 「被引用」= 全仓有多少个文件 import 它——数字大的，动之前先想清楚。

共 ${rows.length} 个模块，${rows.reduce((s, r) => s + r.lines, 0)} 行。

${sections.join('\n')}`

fs.mkdirSync(path.dirname(OUT), { recursive: true })
fs.writeFileSync(OUT, doc, 'utf8')
console.log(`写出 ${OUT}（${rows.length} 个模块）`)
