// 总台修复自测：
// 1) 记忆增长不再触发“设定更新”（否则她只会回“在。”）；
// 2) 设定真的变了才注入，而且和老板这句话合并成一条，不分成两条互相顶掉；
// 3) 图片以 image part 真的投给模型；
// 4) 模型偏好按角色分开存。
// 全部在临时 DSH_HOME 里跑，不碰真实数据、不联网。

import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const BASE = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-chat-fix-'))
process.env.DSH_HOME = BASE
const DATA = path.join(BASE, 'dayu')
const CARDS = path.join(DATA, 'soul', 'cards')
fs.mkdirSync(CARDS, { recursive: true })
fs.mkdirSync(path.join(DATA, 'soul', 'memory'), { recursive: true })
fs.writeFileSync(path.join(CARDS, 'dayu.desk.md'), '# 大鱼\n\n> 管家。\n', 'utf8')
fs.writeFileSync(path.join(CARDS, 'xiaoyu.social.md'), '# 小鱼\n\n> 秘书。\n', 'utf8')
fs.writeFileSync(path.join(DATA, 'soul', 'memory', 'dayu.json'), JSON.stringify({ version: 1, summary: '', habits: [], dynamics: [], events: [] }), 'utf8')
fs.writeFileSync(path.join(DATA, 'awakening.json'), JSON.stringify({
  version: 1,
  updatedAt: new Date().toISOString(),
  characters: {
    dayu: { status: 'awakened', gifts: ['责任心'] },
    xiaoyu: { status: 'awakened', gifts: ['责任心'] },
    dragon: { status: 'awakened', gifts: ['责任心'] },
  },
}), 'utf8')

const { buildIdentityText, buildSceneText } = await import('../lib/soul.js')
const { deliverToRole } = await import('../lib/residence.js')
const { readModelPref, writeModelPref, DEFAULT_MODEL } = await import('../lib/model-pref.js')

let passed = 0
const failures = []
async function check(name, fn) {
  try { await fn(); passed += 1; console.log(`  ok   ${name}`) } catch (err) {
    failures.push({ name, err })
    console.log(`  FAIL ${name}\n       ${err?.message || err}`)
  }
}

function seedMemoryEvent(text) {
  const file = path.join(DATA, 'soul', 'memory', 'dayu.json')
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
  raw.events.push({ at: new Date().toISOString(), channel: '工作台', text })
  fs.writeFileSync(file, JSON.stringify(raw), 'utf8')
}

function makeDeps() {
  const sent = []
  const handles = new Map()
  const mk = (id) => ({ agent: { followup: async ({ content }) => { sent.push({ via: 'followup', sessionId: id, content }) } } })
  const deps = {
    sent,
    agents: { get: (id) => handles.get(id), create: async () => { throw new Error('不该走 agents.create') } },
    cached: () => null,
    listRows: () => [],
    listSessions: async () => [],
    findSession: async () => null,
    createSession: async () => { const id = 'sess-fixed-1'; handles.set(id, mk(id)); return id },
    selectModel: async () => {},
    renameSession: async () => {},
    prompt: async ({ sessionId, text, content }) => { sent.push({ via: 'prompt', sessionId, text, content }) },
  }
  return { deps, sent, handles }
}

await check('身份层不含记忆，记忆增长不改变身份哈希', () => {
  const before = buildIdentityText('dayu', 'desk')
  seedMemoryEvent('今天干了点活')
  const after = buildIdentityText('dayu', 'desk')
  assert.ok(before.length > 0)
  assert.equal(after, before, '记忆增长不该改变身份层')
  assert.notEqual(buildSceneText('dayu', 'desk'), before, '全文应仍包含记忆')
})

await check('第二次说话不再重注入：一条 followup，不额外发设定', async () => {
  const { deps, sent } = makeDeps()
  await deliverToRole('dayu', '第一句', deps)
  const afterFirst = sent.length
  seedMemoryEvent('又记了一条')
  await deliverToRole('dayu', '第二句', deps)
  const second = sent.slice(afterFirst)
  assert.equal(second.length, 1, `第二次应只发一条，实际 ${second.length}`)
  assert.equal(second[0].via, 'followup')
  assert.match(second[0].content[0].text, /第二句/)
  assert.doesNotMatch(second[0].content[0].text, /设定只到这里/)
})

await check('设定真的变了：注入和这句话合并成一条 prompt，不再分成两条', async () => {
  const { deps, sent } = makeDeps()
  await deliverToRole('dayu', '先建身体', deps)
  const before = sent.length
  fs.writeFileSync(path.join(CARDS, 'dayu.desk.md'), '# 大鱼\n\n> 管家。\n\n新的设定：要短。\n', 'utf8')
  await deliverToRole('dayu', '老板这句必须回', deps)
  const after = sent.slice(before)
  assert.equal(after.length, 1, `设定更新应与消息合并成一条，实际 ${after.length}`)
  assert.equal(after[0].via, 'prompt')
  assert.match(after[0].text, /新的设定/)
  assert.match(after[0].text, /老板这句必须回/)
  assert.match(after[0].text, /只回下面这句/)
})

await check('图片：image part 原样投给模型，文字仍是老板的话', async () => {
  const { deps, sent } = makeDeps()
  await deliverToRole('dayu', '先建身体', deps)
  const before = sent.length
  const content = [
    { type: 'text', text: '看看这张图' },
    { type: 'image', mediaType: 'image/png', data: 'aGVsbG8=', name: 'a.png' },
  ]
  await deliverToRole('dayu', '看看这张图', { ...deps, content })
  const after = sent.slice(before)
  assert.equal(after.length, 1)
  const parts = after[0].content
  assert.equal(parts.length, 2)
  assert.equal(parts[0].type, 'text')
  assert.match(parts[0].text, /看看这张图/)
  assert.equal(parts[1].type, 'image')
  assert.equal(parts[1].mediaType, 'image/png')
  assert.equal(parts[1].data, 'aGVsbG8=')
})

await check('模型偏好：按角色分开存，没设过用默认', () => {
  assert.deepEqual(readModelPref('dayu'), DEFAULT_MODEL)
  writeModelPref('dayu', { provider: 'uuapi', model: 'gpt-6.1-sol', reasoningEffort: 'high' })
  assert.equal(readModelPref('dayu').model, 'gpt-6.1-sol')
  assert.equal(readModelPref('xiaoyu').model, DEFAULT_MODEL.model, '小鱼不能被大鱼的设置带走')
  const raw = JSON.parse(fs.readFileSync(path.join(DATA, 'model.json'), 'utf8'))
  assert.equal(raw.roles.dayu.provider, 'uuapi')
  assert.equal(raw.roles.xiaoyu, undefined)
})

fs.rmSync(BASE, { recursive: true, force: true })
console.log('')
console.log(`结果：通过 ${passed}，失败 ${failures.length}`)
if (failures.length) {
  for (const item of failures) console.log(` - ${item.name}: ${item.err?.message || item.err}`)
  process.exitCode = 1
} else {
  console.log('chat-fixes：全部断言通过')
}
