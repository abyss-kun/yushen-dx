// 接入检查：不读规则，礼物不启用；读过了才算"接着鱼神"。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-plug-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const pg = await import('../lib/plug.js')
const br = await import('../lib/brief.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-27T12:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 没读过：未接入，礼物要报错
let s = pg.plugStatus(ROLE, { now: NOW })
assert.equal(s.plugged, false)
assert.match(s.reason, /还没读过/)
assert.throws(() => pg.requirePlugged(ROLE, { now: NOW }), /还没接入鱼神/)

// 2) 跑一次简报 = 读过规则 → 接上
const brief = br.buildRuntimeBrief(ROLE, { channel: 'workbench', now: NOW })
assert.ok(brief.text.length > 100)
s = pg.plugStatus(ROLE, { now: NOW })
assert.equal(s.plugged, true)
assert.equal(s.ageMin, 0)

// 3) 太久没读：掉线（礼物先停）
s = pg.plugStatus(ROLE, { now: NOW + 7 * 3600 * 1000 })
assert.equal(s.plugged, false)
assert.match(s.reason, /太久了/)

// 4) 规则换版本：也要重读
pg.markPlugged(ROLE, { now: NOW })
const raw = JSON.parse(fs.readFileSync(path.join(HOME, 'dayu', 'runtime', ROLE, 'attest.json'), 'utf8'))
raw.rulesVersion = 'oldversion'
fs.writeFileSync(path.join(HOME, 'dayu', 'runtime', ROLE, 'attest.json'), JSON.stringify(raw), 'utf8')
s = pg.plugStatus(ROLE, { now: NOW })
assert.equal(s.plugged, false)
assert.match(s.reason, /规则换了/)

// 5) 注入里明说接没接
pg.markPlugged(ROLE, { now: NOW })
assert.match(pg.plugLine(ROLE, { now: NOW }), /接着的/)
fs.rmSync(path.join(HOME, 'dayu', 'runtime', ROLE, 'attest.json'), { force: true })
assert.match(pg.plugLine(ROLE, { now: NOW }), /没接上/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, unplugged: true, briefMarks: true, stale: true, versionChanged: true, line: true }))
