// 鱼神双子星 · Copyright (c) 2026 从零开始. All rights reserved.
// 一次性导入：把旧的「大肥鱼」角色卡与记忆，规范成新框架的 soul/。
// 只读旧文件，只写 ~/.dsh/dayu/soul/；不 import 旧插件、不改旧文件。
//
// 用法：node scripts/import-legacy.mjs
// 产物：
//   soul/persona.json       # 元数据 + brief + 记忆（日常注入只读这个）
//   soul/card.desk.md       # 工作台口吻（傲娇版，原文快照）
//   soul/card.social.md     # 社交口吻（原版，原文快照）
//   soul/social-memory.json # 群友画像，单独存，不进日常注入

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { qqBridgeRoot } from '../lib/paths.js'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const ROLE_DIR = process.env.YUSHEN_ROLE_DIR || path.join(qqBridgeRoot(), 'roles')
const MEMORY_FILE = process.env.YUSHEN_MEMORY_FILE || 'D:\\deepseekTools\\qq-bridge\\state\\persona-memory.json'
const SOUL = process.env.YUSHEN_SOUL_DIR || path.join(HOME, 'dayu', 'soul')

const DESK_CARD = path.join(ROLE_DIR, '傲娇版大鱼.md')
const SOCIAL_CARD = path.join(ROLE_DIR, '大肥鱼.md')

function readText(file) {
  let text = fs.readFileSync(file, 'utf8')
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1)
  return text
}

function sha(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex')
}

function sections(markdown) {
  const out = []
  let current = { title: '开头', lines: [] }
  for (const line of markdown.split(/\r?\n/)) {
    const m = /^##\s+(.+)$/.exec(line)
    if (m) {
      if (current.lines.length || current.title !== '开头') out.push(current)
      current = { title: m[1].trim(), lines: [] }
    } else {
      current.lines.push(line)
    }
  }
  out.push(current)
  return out
}

function bullets(lines, limit = 99) {
  const out = []
  for (const line of lines) {
    const t = line.trim()
    if (!t || t.startsWith('#')) continue
    if (t.startsWith('-')) out.push(t)
    if (out.length >= limit) break
  }
  return out
}

function sectionBody(list, keyword, limit = 99) {
  const hit = list.find((s) => s.title.includes(keyword))
  return hit ? bullets(hit.lines, limit) : []
}

function briefOf(markdown, scene = 'desk') {
  const list = sections(markdown)
  let who = sectionBody(list, '你是谁')
  if (scene === 'desk') {
    // 工作台不是 QQ：把“这个号/偷玩/撤回/昵称”那几类社交专属的句子摘掉，免得她拿群里的身份来上班。
    who = who.filter((line) => !/QQ|号|偷玩|撤回|昵称|@小鱼/.test(line))
  }
  const style = sectionBody(list, '说话风格')
  const traits = sectionBody(list, '性格', 8)
  const noodle = sectionBody(list, '你是谁').find((line) => line.includes('雷点'))
  const parts = []
  parts.push('# 大鱼（阿鲲）· 工作台')
  parts.push('## 身份与职责')
  parts.push(who.join('\n'))
  if (noodle) parts.push('\n## 雷点\n' + noodle)
  parts.push('\n## 说话风格\n' + style.join('\n'))
  if (traits.length) parts.push('\n## 性格（节选）\n' + traits.join('\n'))
  return parts.join('\n')
}

function main() {
  for (const file of [DESK_CARD, SOCIAL_CARD, MEMORY_FILE]) {
    if (!fs.existsSync(file)) throw new Error(`找不到：${file}`)
  }
  const deskText = readText(DESK_CARD)
  const socialText = readText(SOCIAL_CARD)
  const memoryRaw = JSON.parse(readText(MEMORY_FILE))

  const impressions = memoryRaw?.impressions && typeof memoryRaw.impressions === 'object' ? memoryRaw.impressions : {}
  const socialMemory = {
    version: 1,
    savedAt: new Date().toISOString(),
    note: '群友画像：只在 QQ 社交场景按需取，不进日常注入。',
    count: Object.keys(impressions).length,
    impressions,
  }
  const memory = {
    summary: String(memoryRaw?.summary || '').slice(0, 500),
    habits: Array.isArray(memoryRaw?.habits) ? memoryRaw.habits.slice(0, 12).map((s) => String(s).slice(0, 200)) : [],
    dynamics: Array.isArray(memoryRaw?.dynamics) ? memoryRaw.dynamics.slice(0, 12).map((s) => String(s).slice(0, 200)) : [],
  }

  fs.mkdirSync(SOUL, { recursive: true })
  const persona = {
    version: 1,
    importedAt: new Date().toISOString(),
    scene: { desk: '傲娇版大鱼.md', social: '大肥鱼.md' },
    sources: {
      desk: { file: DESK_CARD, sha256: sha(deskText), chars: deskText.length },
      social: { file: SOCIAL_CARD, sha256: sha(socialText), chars: socialText.length },
      memory: { file: MEMORY_FILE, sha256: sha(JSON.stringify(memoryRaw)), entries: Object.keys(impressions).length },
    },
    brief: briefOf(deskText),
    memory,
  }

  const write = (file, text) => {
    const tmp = file + '.tmp'
    fs.writeFileSync(tmp, text, 'utf8')
    fs.renameSync(tmp, file)
  }
  if (fs.existsSync(path.join(SOUL, 'persona.json'))) {
    fs.copyFileSync(path.join(SOUL, 'persona.json'), path.join(SOUL, 'persona.json.bak'))
  }
  write(path.join(SOUL, 'card.desk.md'), deskText)
  write(path.join(SOUL, 'card.social.md'), socialText)
  write(path.join(SOUL, 'social-memory.json'), JSON.stringify(socialMemory, null, 2))
  write(path.join(SOUL, 'persona.json'), JSON.stringify(persona, null, 2))

  console.log(`soul → ${SOUL}`)
  console.log(`brief ${persona.brief.length} 字 / 卡 ${deskText.length} 字`)
  console.log(`记忆：summary ${memory.summary.length} 字、habits ${memory.habits.length}、dynamics ${memory.dynamics.length}、群友画像 ${Object.keys(impressions).length}（单独存）`)
  console.log(`哈希：desk ${persona.sources.desk.sha256.slice(0, 8)} / social ${persona.sources.social.sha256.slice(0, 8)} / memory ${persona.sources.memory.sha256.slice(0, 8)}`)
}

main()
