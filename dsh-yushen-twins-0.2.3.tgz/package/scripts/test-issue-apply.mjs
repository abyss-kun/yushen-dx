// 签发生效：她签给某岗位的那本，真的进那个岗位的切片；过期回落。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-issue2-'))
process.env.DSH_HOME = HOME
// 手册文件用真实仓库那份
process.env.YUSHEN_HANDBOOK = path.join(path.dirname(new URL(import.meta.url).pathname.replace(/^\//, '')), '..', '..', '员工手册.md')

const rt = await import('../lib/runtime.js')
const pg = await import('../lib/plug.js')
const is = await import('../lib/issue.js')
const hb = await import('../lib/handbook.js')

const NOW = Date.parse('2026-10-27T20:00:00+08:00')
rt.ensureRuntime('dayu')
rt.ensureRuntime('worker')
pg.markPlugged('dayu', { now: NOW })

// 1) 没签发：worker 默认没有"查重与复用"（除非任务命中）
const before = hb.handbookSlice('worker', { now: NOW }).text || ''
assert.equal(/查重与复用/.test(before), false, '默认不该带复用章')

// 2) 大鱼签给 worker：复用章生效
const row = is.issueHandbook('dayu', { to: 'worker', task: '修 bug', topics: ['reuse'], expiresAt: NOW + 86400000, now: NOW })
const after = hb.handbookSlice('worker', { now: NOW })
assert.match(JSON.stringify(after.issued || {}), /dayu/)
assert.match(after.text || '', /复用|查重/, '签发后应该带复用章')

// 3) 过期：回落，不再带
const later = NOW + 2 * 86400000
const expired = hb.handbookSlice('worker', { now: later })
assert.equal(/查重与复用/.test(expired.text || ''), false, '过期应回落')
assert.equal(expired.issued, null)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, defaultClean: true, issuedApplies: true, expiryFallsBack: true }))
