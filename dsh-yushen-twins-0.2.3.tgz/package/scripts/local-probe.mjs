// 本地翻译的改进版试跑：一条一条翻，说话人由程序填（不让模型猜），只要 gist + 语气。
//
//   node scripts/local-probe.mjs --batch 3
import { readInbox } from '../lib/inbox.js'
import { chatLocal, localHealth } from '../lib/translator.js'

const argv = process.argv.slice(2)
const arg = (n, d) => { const i = argv.indexOf(`--${n}`); return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : d }
const batch = Math.max(1, Math.min(8, Number(arg('batch', '3')) || 3))

const SYS = [
  '你在帮一个读者看懂群里的一句话。',
  '只输出两行，不要别的：',
  '第一行：这句话在说什么（不超过 20 字，不要加"他说"）',
  '第二行：语气（从这几个里选一个：闲聊/问事/玩笑/抱怨/冲人/表情）',
].join('\n')

async function one(row) {
  const t0 = Date.now()
  try {
    const text = await chatLocal([
      { role: 'system', content: SYS },
      { role: 'user', content: `说话人：${row.name || row.userId}\n内容：${String(row.text || '').slice(0, 160)}` },
    ], { maxTokens: 70, temperature: 0.1, timeoutMs: 180000 })
    const lines = String(text).split(/\r?\n/)
      .map((s) => s.trim().replace(/^第一行[:：]\s*/, '').replace(/^第二行[:：]\s*/, ''))
      .filter(Boolean)
    return { ok: true, gist: lines[0] || '', tone: lines[1] || '', ms: Date.now() - t0 }
  } catch (e) {
    return { ok: false, error: String(e?.message || e), ms: Date.now() - t0 }
  }
}

const rows = readInbox({ limit: batch }).rows.filter((r) => r.text && !r.isSelf)
if (!(await localHealth())) { console.log(JSON.stringify({ ok: false, reason: '本地服务没起' })); process.exit(0) }
const out = []
for (const row of rows) out.push({ who: row.name || row.userId, text: String(row.text).slice(0, 60), ...(await one(row)) })
console.log(JSON.stringify({ ok: out.every((x) => x.ok), count: out.length, items: out }, null, 2))
