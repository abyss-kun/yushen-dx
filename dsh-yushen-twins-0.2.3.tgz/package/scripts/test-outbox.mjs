// 递话：有出处才发；没出处直接拒（不替她说话）。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-outbox-'))
process.env.DSH_HOME = HOME
process.env.YUSHEN_BRIDGE_URL = 'http://127.0.0.1:9' // 死端口，用 mock fetch
const rt = await import('../lib/runtime.js')
const ob = await import('../lib/outbox.js')

const ROLE = 'dayu'
rt.ensureRuntime(ROLE)

// 1) token 文件会自动生成，且只有本地一份
const token = ob.ensureToken()
assert.match(token, /^[0-9a-f]{48}$/)
assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'bridge-token.json')))
assert.equal(ob.ensureToken(), token, '重复调用不换 token')

// 2) 没有决定 id：不许发（这就是"替她说话"的后门）
await assert.rejects(ob.sendAs(ROLE, { key: 'group:1', text: '嗯', decisionId: '' }), /决定 id/)
// 3) 会话不对：不许发
await assert.rejects(ob.sendAs(ROLE, { key: 'xxx', text: '嗯', decisionId: 'd1' }), /会话不对/)
// 4) 太长：不许发
await assert.rejects(ob.sendAs(ROLE, { key: 'group:1', text: '一'.repeat(301), decisionId: 'd1' }), /太长/)

// 5.5) 自动回复模板：不许替它发（铁律二）
await assert.rejects(ob.sendAs(ROLE, { key: 'group:1', text: '你好，我现在有事不在，一会再和你联系。', decisionId: 'd5' }), /自动回复模板/)

// 5) 正常：带 token、决定 id、via 都送到桥
let seen = null
globalThis.fetch = async (url, opts) => {
  seen = { url, headers: opts.headers }
  return { ok: true, status: 200, json: async () => ({ ok: true, key: 'group:1', via: 'local', decisionId: 'd1' }) }
}
const ok = await ob.sendAs(ROLE, { key: 'group:1', text: '嗯，行', decisionId: 'd1', via: 'local' })
assert.equal(ok.ok, true)
assert.match(String(seen.url), /\/api\/dayu\/send\?/)
assert.match(String(seen.url), /decisionId=d1/)
assert.match(String(seen.url), /via=local/)
assert.equal(seen.headers['x-yushen-token'], token)

// 6) 桥拒绝（401）：要如实失败，不算发出去
globalThis.fetch = async () => ({ ok: false, status: 401, json: async () => ({ ok: false, error: 'unauthorized' }) })
const denied = await ob.sendAs(ROLE, { key: 'group:1', text: '嗯', decisionId: 'd2' })
assert.equal(denied.ok, false)
assert.equal(denied.status, 401)

// 7) 发图：同样要出处；URL 上带 image
let imgSeen = null
globalThis.fetch = async (url, opts) => {
  imgSeen = { url: String(url), headers: opts.headers }
  return { ok: true, status: 200, json: async () => ({ ok: true }) }
}
const img = await ob.shareImage(ROLE, { key: 'group:1', file: 'D:\\x\\a.png', text: '你看', decisionId: 'd3' })
assert.equal(img.ok, true)
assert.match(imgSeen.url, /image=/)
await assert.rejects(ob.shareImage(ROLE, { key: 'group:1', file: '', decisionId: 'd4' }), /没有图/)
await assert.rejects(ob.shareImage(ROLE, { key: 'group:1', file: 'D:\\x\\a.png' }), /决定 id/)

// 8) 每次递话都留痕（成功失败都记）
const rows = ob.outboxToday(ROLE)
assert.equal(rows.length, 3)
assert.equal(rows[0].ok, true)
assert.equal(rows[1].ok, false)
assert.match(rows[1].error, /unauthorized/)
assert.match(rows[2].text, /\[图\]/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, token: true, needsDecisionId: true, guards: true, posts: true, logs: true }))
