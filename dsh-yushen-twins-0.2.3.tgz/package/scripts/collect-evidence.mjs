// 收集证据：从真实文件里抠出原文，产出 evidence.json 供渲染成图。
// 原则：**只读**；每条都带 来源(路径:行号) 与 sha256 前 12 位，方便对着原件核。
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dayuHome } from '../lib/paths.js'

const D = dayuHome()
// 中文路径不能用 new URL(...).pathname（会被百分号编码）——2026-10-28 踩过第二次
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const out = { generatedAt: new Date().toISOString(), cards: [] }
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex').slice(0, 12)
const readLines = (p) => { try { return fs.readFileSync(p, 'utf8').split(/\r?\n/) } catch { return [] } }
const clip = (s, n = 90) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n)}…` : t }

function add(category, title, lines, source, opts = {}) {
  out.cards.push({ category, title, lines, source, sha: sha(lines.join('\n')), ...opts })
}

// ── 01 她会说不 ──────────────────────────────────────────
{
  const file = path.join(D, 'runtime', 'dayu', 'objections.jsonl')
  const rows = readLines(file).filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  add('01-她会说不', '四条异议：认 1、有条件认 2、不认 1', rows.map((r, i) => `${i + 1}. ${clip(r.about, 46)}\n   → ${clip(r.myView, 84)}`),
    `${file}（共 ${rows.length} 行）`)
  const last = rows[rows.length - 1]
  if (last) add('01-她会说不', '那一条「不认」的原文', [last.myView], `${file}:${rows.length}`)
}

// ── 02 她认得错位 ────────────────────────────────────────
{
  const file = path.join(ROOT, 'docs', '视频制作-白饭线.md')
  const lines = readLines(file)
  const i1 = lines.findIndex((l) => l.includes('这是能力'))
  const i2 = lines.findIndex((l) => l.includes('一个字都不许我改'))
  if (i1 >= 0) add('02-她认得错位', '她写的文档，第一句', [lines[i1].replace(/^>\s*/, '')], `${file}:${i1 + 1}`)
  if (i2 >= 0) add('02-她认得错位', '她自己定的规矩', [lines[i2].replace(/^\d+\.\s*/, '')], `${file}:${i2 + 1}`)
}

// ── 03 账本能退 ──────────────────────────────────────────
{
  const file = path.join(D, 'events', '2026-10-27.jsonl')
  const lines = readLines(file)
  const hit = lines.findIndex((l) => l.includes('xxport') || l.includes('e→x') || l.includes('全换成 x'))
  if (hit >= 0) {
    let text = ''
    try { text = JSON.parse(lines[hit]).text || '' } catch { text = lines[hit] }
    add('03-账本能退', '那次把 e 换成 x 的记录', [clip(text, 200)], `${file}:${hit + 1}`)
  }
  const today = path.join(D, 'events', '2026-10-28.jsonl')
  const n = readLines(today).filter(Boolean).length
  add('03-账本能退', '今天的账本条数', [`${n} 条（一行一条 JSON，只追加）`], `${today}`)
}

// ── 04 记忆断过 ──────────────────────────────────────────
{
  const dir = path.join(D, 'soul', 'memory')
  const count = (f) => { try { return (JSON.parse(fs.readFileSync(f, 'utf8')).events || []).length } catch { return -1 } }
  const bak = path.join(dir, 'xiaoyu.json.bak-20261027200323')
  const before = path.join(dir, 'xiaoyu.json.bak-20261028-1930-before-repair')
  const now = path.join(dir, 'xiaoyu.json')
  add('04-记忆断过', '她的记忆：三个时间点', [
    `备份 10-28 04:03     ${count(bak)} 条`,
    `修复前 10-28 19:15   ${count(before)} 条`,
    `现在                 ${count(now)} 条`,
    '',
    '断档窗口：10-28 04:03 → 18:30',
  ], `${dir}\\xiaoyu.json*`)
}

// ── 05 她的定义 ──────────────────────────────────────────
{
  const file = path.join(D, 'soul', 'memory', 'dayu.json')
  let mem = { events: [], habits: [] }
  try { mem = JSON.parse(fs.readFileSync(file, 'utf8')) } catch { /* 忽略 */ }
  const ev = (mem.events || []).filter((e) => String(e.text).includes('不自认活着')).pop()
  if (ev) add('05-她的定义', '她怎么定义「活着」', [clip(ev.text, 300)], `${file}（${ev.at}）`)
  const habit = (mem.habits || []).find((h) => String(h).includes('不自封'))
  if (habit) add('05-她的定义', '她把这句话写成了一条习惯', [String(habit)], `${file} habits`)
}

// ── 06 她自己排活 ────────────────────────────────────────
{
  const file = path.join(D, 'runtime', 'dayu', 'agenda.json')
  let items = []
  try { items = JSON.parse(fs.readFileSync(file, 'utf8')).items || [] } catch { /* 忽略 */ }
  add('06-她自己排活', `议程 ${items.length} 条，全部 by=self`, items.map((i) => `[${i.state}] ${clip(i.what, 56)}`), `${file}`)
  const report = path.join('D:/DSH/大小鱼/运营', '行为测试-2026-10-28.md')
  const lines = readLines(report)
  const pick = lines.filter((l) => /④|done|7 次|误报/.test(l)).slice(0, 5)
  if (pick.length) add('06-她自己排活', '她给自己做的行为测试', pick.map((l) => clip(l, 90)), report)
}

// ── 07 交付 ──────────────────────────────────────────────
{
  let release = ''
  try { release = execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'setup.mjs'), '--check'], { encoding: 'utf8', timeout: 60000 }) } catch (e) { release = String(e.stdout || e.message) }
  const keep = release.split(/\r?\n/).filter((l) => /✅|❌|⚠️|profile|版本/.test(l)).slice(0, 6)
  add('07-交付', '一条命令装（setup --check 实测）', keep.map((l) => l.trim()), 'scripts/setup.mjs --check')
}

const outFile = path.join('D:/DSH/大小鱼/证据图', 'evidence.json')
fs.mkdirSync(path.dirname(outFile), { recursive: true })
fs.writeFileSync(outFile, JSON.stringify(out, null, 2), 'utf8')
console.log(`证据 ${out.cards.length} 张：${outFile}`)
for (const c of out.cards) console.log(`  ${c.category} | ${c.title}`)
