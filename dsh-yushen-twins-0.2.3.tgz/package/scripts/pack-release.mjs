// 出厂打包：只装“纯净的、完整的”那一份。
// 纯净 = 不带作者数据（魂/记忆/主人偏好/账本/交接/档案室/令牌/用户图）。
// 完整 = 代码 + 内核默认形象 + 公开文档（手册/设定/世界观/框架）。
// 用法：node scripts/pack-release.mjs [输出目录]

import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { workspace } from '../lib/paths.js'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const WS = workspace()
const OUT = path.resolve(process.argv[2] || path.join(ROOT, 'dist', 'dsh-yushen-twins'))

const INCLUDE = [
  'index.js', 'client.js', 'cordis.patch.yml', 'package.json',
  'README.md', 'LICENSE', 'NOTICE', 'COMMERCIAL.md', 'THIRD_PARTY.md', 'CHANGELOG.md',
  'dayu', 'xiaoyu', 'lib', 'core', 'adapters', 'kernel', 'blank', 'assets',
  'docs/工作保全与经验沉淀.md', 'docs/鱼神总定位与任务记忆.md', 'docs/事实与进度协调层.md', 'docs/主动学习与好奇心.md', 'docs/continuity-acceptance.md', 'docs/真实来源接入方案.md', 'scripts/test-versioned-backup.mjs', 'scripts/test-backup-service.mjs', 'scripts/test-recovery-policy.mjs', 'scripts/test-software-artifacts.mjs', 'scripts/test-repair-state.mjs', 'scripts/test-repair-lifecycle.mjs', 'scripts/test-repair-helper-install.mjs', 'scripts/test-repair-helper-upgrade.mjs', 'scripts/test-fact-ledger.mjs', 'scripts/test-session-governance.mjs', 'scripts/test-mind-store.mjs', 'scripts/test-mind-observation.mjs', 'scripts/test-continuity-delivery.mjs', 'scripts/test-mind-tools.mjs', 'scripts/test-bili-observation.mjs', 'repair-helper', 'lib/repair-state.js', 'lib/repair-lifecycle.js', 'lib/repair-helper-install.js', 'lib/software-protection.js', 'lib/fact-ledger.js', 'lib/session-governance.js', 'lib/mind-store.js', 'lib/bili-observation.js', 'scripts/protection.mjs', 'scripts/software-artifacts.mjs',
  'assets/repair-helper/YushenRepair.exe', 'assets/repair-helper/SHA256SUMS.txt', 'scripts/check-protection.mjs', 'scripts/intake-scan.mjs', 'scripts/dup-audit.mjs',
  'scripts/core-demo.mjs', 'scripts/dual-report.mjs', 'scripts/test-three-role-store.mjs', 'scripts/smoke.mjs', 'scripts/live-check.mjs', 'scripts/regression.mjs', 'scripts/verify-settings.mjs', 'scripts/baseline.mjs', 'scripts/gen-usage.mjs', 'scripts/note-work.mjs',
  'docs/吸收与升级.md', 'docs/实时报活.md', 'docs/三人常驻与本体.md', 'docs/故障档案.md',
  'scripts/wheel-check.mjs', 'scripts/session-search.mjs', 'scripts/session-open.mjs', 'scripts/note.mjs', 'scripts/character.mjs', 'scripts/bili-soul-sync.mjs', 'scripts/verify-roles-live.mjs',
  'scripts/test-memory.mjs', 'scripts/test-now.mjs', 'scripts/test-characters.mjs', 'scripts/test-bili-sync.mjs',
  'scripts/awakening.mjs', 'scripts/test-awakening.mjs', 'scripts/prove-living.mjs', 'docs/点化与收回.md',
  'scripts/capture.mjs', 'scripts/test-capture.mjs', 'docs/即时记录与备份.md',
  'scripts/thought.mjs', 'scripts/test-thoughts.mjs',
  'scripts/test-freetime.mjs', 'docs/自由活动.md', 'docs/点化灵智.md', 'docs/阶位.md', 'scripts/test-rank.mjs',
  'scripts/test-awareness.mjs', 'docs/软件知情.md',
  'scripts/privacy-check.mjs', 'scripts/test-redact.mjs', 'docs/隐私与保命.md', 'scripts/look.mjs',
  'scripts/test-privacy.mjs',
  'scripts/backup-e.mjs', 'scripts/test-offsite.mjs', 'docs/备份到E盘.md',
  'scripts/test-encoding.mjs', 'scripts/say.mjs', 'scripts/test-body.mjs',
  'scripts/where.mjs', 'docs/规则地图.md', 'scripts/find.mjs', 'scripts/test-find.mjs',
  'scripts/inbox-mirror.mjs', 'scripts/test-inbox.mjs', 'scripts/weights.mjs', 'scripts/test-runtime.mjs',
  'docs/点化-运行时契约.md', 'docs/点化-更多.md', 'docs/入主鱼神-判断权归位.md', 'docs/连续自我-路线.md', 'docs/连续自我-人与她的对比.md',
]

// 公开文档：从作品目录拷进包里；作者私人的不拷。
const DOCS = [
  ['员工手册.md', 'docs/员工手册.md'],
  ['基线清单.md', 'docs/基线清单.md'],
  ['交接手册.md', 'docs/交接手册.md'],
  ['职责清单.md', 'docs/职责清单.md'],
  ['世界观设定.md', 'docs/世界观设定.md'],
  ['世界观-文化篇.md', 'docs/世界观-文化篇.md'],
  ['设定集-角色-大鱼.md', 'docs/角色-大鱼.md'],
  ['设定集-角色-小鱼.md', 'docs/角色-小鱼.md'],
  ['大小鱼-框架定义.md', 'docs/框架定义.md'],
]

// 绝对不能进包的（出现即失败）。
const FORBIDDEN = [
  /(^|[\\/])soul([\\/]|$)/, /(^|[\\/])events([\\/]|$)/, /(^|[\\/])handoff([\\/]|$)/,
  /(^|[\\/])archive([\\/]|$)/, /(^|[\\/])\.private([\\/]|$)/,
  /owner\.md$/, /dispatch\.json$/, /incidents\.json$/, /api-token$/, /native-session\.json$/,
  /\.bak/, /\.credentials/, /角色卡/, /修复档案/,
]

const copied = []
const hashes = []

function walk(rel) {
  if (/\.bak/.test(rel) || /(^|[\\/])node_modules([\\/]|$)/.test(rel)) return
  if (rel.replaceAll('\\', '/').startsWith('assets/repair-helper/') && !['assets/repair-helper/YushenRepair.exe','assets/repair-helper/SHA256SUMS.txt'].includes(rel.replaceAll('\\', '/'))) return
  const src = path.join(ROOT, rel)
  if (!fs.existsSync(src)) return
  const st = fs.statSync(src)
  if (st.isDirectory()) {
    for (const name of fs.readdirSync(src)) walk(path.join(rel, name))
    return
  }
  const target = path.join(OUT, rel)
  fs.mkdirSync(path.dirname(target), { recursive: true })
  fs.copyFileSync(src, target)
  const buf = fs.readFileSync(src)
  hashes.push({ rel, bytes: buf.length, sha: crypto.createHash('sha256').update(buf).digest('hex').slice(0, 12) })
  copied.push(rel)
}

function fail(msg) { console.error('✗', msg); process.exit(1) }

fs.rmSync(OUT, { recursive: true, force: true })
fs.mkdirSync(OUT, { recursive: true })
for (const rel of INCLUDE) walk(rel)

for (const [from, to] of DOCS) {
  const src = path.join(WS, from)
  if (!fs.existsSync(src)) continue
  const target = path.join(OUT, to)
  fs.mkdirSync(path.dirname(target), { recursive: true })
  fs.copyFileSync(src, target)
  const buf = fs.readFileSync(src)
  hashes.push({ rel: to, bytes: buf.length, sha: crypto.createHash('sha256').update(buf).digest('hex').slice(0, 12) })
  copied.push(to)
}

// 纯净检查
for (const rel of copied) {
  const norm = rel.replace(/\\/g, '/')
  for (const rule of FORBIDDEN) if (rule.test('/' + norm)) fail(`禁品进包：${rel}`)
}

const total = hashes.reduce((n, h) => n + h.bytes, 0)
fs.writeFileSync(path.join(OUT, 'MANIFEST.json'), JSON.stringify({ at: new Date().toISOString(), files: hashes, totalBytes: total }, null, 2), 'utf8')

console.log(`出厂包：${OUT}`)
console.log(`文件 ${hashes.length} 个，共 ${(total / 1024).toFixed(1)} KB`)
console.log('文档：' + DOCS.map((d) => d[1]).join('、'))
console.log('不含：魂 / 记忆 / 主人偏好 / 账本 / 派活 / 事故 / 交接 / 档案室 / 令牌 / 用户图 / 修复档案')
