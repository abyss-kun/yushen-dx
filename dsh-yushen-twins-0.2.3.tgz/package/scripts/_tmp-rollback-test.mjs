// 自测失败路径：补丁写坏 → smoke 红 → 必须回滚，且新文件要被删掉。

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-rollback-'))
process.env.DSH_HOME = HOME
const { createPatch, applyPatch } = await import(pathToFileURL(path.join(ROOT, 'lib/patch.js')).href)

const rel = 'BROKEN-ROLLBACK.js'
const target = path.join(ROOT, rel)
const patch = createPatch({
  title: '自测：坏补丁回滚',
  files: [{ path: rel, content: 'this is not javascript {{{\n' }],
})
console.log('1 草案:', patch.id)
const result = await applyPatch(patch.id)
const left = fs.existsSync(target)
console.log('2 结果:', result.ok, result.meta?.status)
console.log('3 坏文件还在吗:', left, '(必须是 false)')
try { fs.unlinkSync(target) } catch { /* 已删 */ }
fs.rmSync(HOME, { recursive: true, force: true })
const pass = !result.ok && result.meta?.status === 'rolled-back' && left === false
console.log(pass ? 'PASS 失败路径已回滚' : 'FAIL 回滚不干净')
process.exit(pass ? 0 : 1)
