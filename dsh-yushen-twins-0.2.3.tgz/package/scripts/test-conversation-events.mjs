import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
const home=fs.mkdtempSync(path.join(os.tmpdir(),'conversation-events-'))
process.env.DSH_HOME=home
try {
  const {appendConversationEvent:append,listConversationEvents:list}=await import('../lib/conversation-events.js')
  const scope={role:'dayu',channel:'qq',conversationId:'private:123'}
  const event={...scope,direction:'incoming',messageId:'a',text:'私密原文\n带换行'}
  assert.equal(append(event).semantics,'not-analyzed')
  assert.equal(append(event).duplicate,true)
  assert.equal(list(scope).length,1)
  assert.equal(list(scope)[0].text,event.text)
  assert.equal(list({...scope,role:'xiaoyu'}).length,0)
  assert.equal(list({...scope,conversationId:'group:123'}).length,0)
  assert.equal(list({...scope,channel:'bili'}).length,0)
  append({...event,direction:'outgoing',text:'已发出的回复'})
  assert.equal(list(scope).length,2)
  assert.throws(()=>append({...event,text:'被替换'}),/冲突/)
  assert.throws(()=>append({...event,role:'../dayu'}))
  assert.throws(()=>append({...event,messageId:''}))
  assert.throws(()=>list(scope,{limit:0}))
  assert.equal(list(scope,{limit:1})[0].direction,'outgoing')
  console.log('PASS 对话原文留存、去重冲突、角色通道会话隔离、未分析状态')
} finally {assert.ok(path.basename(home).startsWith('conversation-events-'));fs.rmSync(home,{recursive:true,force:true})}
