import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
const home = fs.mkdtempSync(path.join(os.tmpdir(), 'brain-archive-'))
process.env.DSH_HOME = home
try {
  const { archiveSource, readArchive } = await import('../lib/brain-archive.js')
  const file = path.join(home, 'source.md')
  const bytes = Buffer.from('人格原文\r\n完整记忆，不截断。\n')
  fs.writeFileSync(file, bytes)
  const record = archiveSource('dayu', file, { kind: 'persona' })
  assert.deepEqual(readArchive('dayu', record.sha256).content, bytes)
  assert.equal(archiveSource('dayu', file).duplicate, true)
  assert.deepEqual(fs.readFileSync(file), bytes)
  assert.throws(() => readArchive('xiaoyu', record.sha256))
  assert.throws(() => archiveSource('../dayu', file))
  assert.throws(() => readArchive('dayu', '../source'))
  const saved = JSON.parse(fs.readFileSync(record.path, 'utf8'))
  saved.base64 = Buffer.from('tamper').toString('base64')
  fs.writeFileSync(record.path, JSON.stringify(saved))
  assert.throws(() => readArchive('dayu', record.sha256), /完整性/)
  console.log('PASS 无损原文、角色隔离、幂等、源文件不变、哈希校验')
} finally { assert.ok(path.basename(home).startsWith('brain-archive-')); fs.rmSync(home,{recursive:true,force:true}) }
