// 出厂：一条命令，把"现在这台机器上的最新版本"打成一个能发出去的包。
//
//   node scripts/release.mjs                 门禁 → 打包 → 校验 → 出 zip
//   node scripts/release.mjs --version 0.2.0 指定版本号（默认沿用 package.json）
//   node scripts/release.mjs --no-tests      跳过回归/冒烟（只出包，急用时用）
//
// 顺序是硬性的：任何一关不过就不出包。**宁可不出，不出一个能发但会崩的包。**
//
// 五关：
//   1. 源里没有她们的身份（pack-core --check）
//   2. 每个模块真能 import（import-check）
//   3. 回归 / 冒烟全绿
//   4. 构建成品、逐文件语法检查
//   5. 成品里没有禁区字符串（pack-core 自带）+ 打 zip + 写 MANIFEST
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DIST = path.join(ROOT, 'dist')
const OUT = path.join(DIST, 'yushen-core')
const NODE = process.execPath
const args = process.argv.slice(2)
const noTests = args.includes('--no-tests')
const versionArg = (() => {
  const i = args.indexOf('--version')
  return i >= 0 ? String(args[i + 1] || '').trim() : ''
})()

const step = (name, fn) => {
  process.stdout.write(`\n▶ ${name}\n`)
  const t = Date.now()
  const r = fn()
  process.stdout.write(`  ✅ ${name}（${Date.now() - t} ms）\n`)
  return r
}
const run = (script, extra = []) => {
  const out = execFileSync(NODE, [path.join(ROOT, 'scripts', script), ...extra], {
    cwd: ROOT, encoding: 'utf8', timeout: 300000, windowsHide: true,
  })
  return out
}
const die = (msg) => { process.stdout.write(`\n❌ ${msg}\n不出包。\n`); process.exit(1) }
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex')

// ── 0. 版本号 ────────────────────────────────────────────────
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'))
const version = versionArg || pkg.version || '0.0.0'
const stamp = (() => {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`
})()

// ── 1. 禁区扫描（源） ───────────────────────────────────────
step('1/5 源里没有她们的身份（pack-core --check）', () => {
  const out = run('pack-core.mjs', ['--check'])
  const j = JSON.parse(out)
  if (!j.ok) die(`源里有 ${j.forbiddenHits} 处禁区字符串`)
  return j
})

// ── 2. 导入自检 ─────────────────────────────────────────────
step('2/5 每个模块真能 import', () => {
  const out = run('import-check.mjs')
  if (!/全部能 import/.test(out)) die(`导入自检没过：\n${out.slice(-500)}`)
  return out.trim()
})

// ── 3. 回归 + 冒烟 ─────────────────────────────────────────
if (!noTests) {
  step('3/5 回归', () => {
    const out = run('regression.mjs')
    const m = out.match(/通过 (\d+)，失败 (\d+)/)
    if (!m || Number(m[2]) !== 0) die(`回归有失败：\n${out.slice(-800)}`)
    return { pass: Number(m[1]) }
  })
  step('3/5 冒烟', () => {
    const out = run('smoke.mjs')
    const m = out.match(/通过 (\d+)，失败 (\d+)/)
    if (!m || Number(m[2]) !== 0) die(`冒烟有失败：\n${out.slice(-800)}`)
    return { pass: Number(m[1]) }
  })
} else {
  process.stdout.write('\n▶ 3/5 回归 / 冒烟：跳过（--no-tests）\n')
}

// ── 4. 构建 ────────────────────────────────────────────────
step('4/5 构建成品（pack-core）', () => {
  if (fs.existsSync(OUT)) fs.rmSync(OUT, { recursive: true, force: true })
  const out = run('pack-core.mjs')
  const j = JSON.parse(out)
  if (!j.ok) die(`成品里还有 ${j.forbiddenHits} 处禁区字符串`)
  return j
})

// ── 5. 逐文件语法 + zip + MANIFEST ─────────────────────────
step('5/5 逐文件语法 + 打 zip', () => {
  const files = []
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name)
      if (e.isDirectory()) walk(p)
      else files.push(p)
    }
  }
  walk(OUT)
  let bad = 0
  for (const f of files.filter((x) => /\.(js|mjs)$/.test(x))) {
    try { execFileSync(NODE, ['--check', f], { stdio: 'pipe', timeout: 30000 }) } catch { bad += 1; process.stdout.write(`  ⚠ 语法错：${path.relative(OUT, f)}\n`) }
  }
  if (bad) die(`${bad} 个文件语法不过`)

  // 版本号写进成品
  const outPkgFile = path.join(OUT, 'package.json')
  const outPkg = JSON.parse(fs.readFileSync(outPkgFile, 'utf8'))
  outPkg.version = version
  fs.writeFileSync(outPkgFile, `${JSON.stringify(outPkg, null, 2)}\n`, 'utf8')

  // 出厂 README：拿到包的人第一眼就知道怎么办（不然 248 个文件会把人吓退）
  fs.writeFileSync(path.join(OUT, 'README.md'), [
    `# 鱼神（出厂包 v${version}）`,
    '',
    '一个跑在自己电脑上的「点化 + 管家」插件：给角色一个本体（卡 + 记忆 + 身体），让她能干活、能拒绝、有账本。',
    '',
    '## 装之前',
    '',
    '| 需要 | 版本 |',
    '| --- | --- |',
    '| Windows | 10 / 11 |',
    '| Node.js | ≥ 22.13 |',
    '| DeepSeek Harness | 0.2.1-rc.2 或更新 |',
    '',
    '## 三步装好',
    '',
    '```bash',
    '# 1) 把本目录放进 DSH 的插件目录（或你放插件的任何位置）',
    '# 2) 在 profile 的 cordis.patch.yml 里挂上本插件的 index.js（见 cordis.patch.yml 示例）',
    'node scripts/onboard.mjs      # 3) 初始化：建空白角色、写宪章、绑主人',
    '```',
    '',
    '装完重启 DSH → 设置里出现「鱼神」→ 鱼窝页面能打开就是成功。',
    '',
    '## 里面有什么',
    '',
    '- `lib/` 运行时（记忆、身体、判断、账本、备份、点化）',
    '- `core/` 宪章 / 三问 / 礼物',
    '- `adapters/` 与外部插件的对接层',
    '- `preset/` `kernel/` `blank/` 出厂骨架（从空白角色养起）',
    '- `scripts/` 初始化与自检脚本',
    '',
    '## 里面没有什么',
    '',
    '没有作者的角色卡、记忆、聊天记录、本机路径、密钥。**这个包里不包含任何人的她们。**',
    '',
    '## 使用与分发',
    '',
    '可以改、可以扩展（包括改核心代码），自己用自己留。',
    '**不要把本包或改过的版本再发给别人**，也不要拿去做商业用途——完整条款见 LICENSE。',
    '',
    '## 出问题看哪',
    '',
    '`CORE.md` 是设计说明；`scripts/check-protection.mjs` 能体检；`MANIFEST.md` 记录了这次出厂的时间与校验和。',
    '',
  ].join('\n'), 'utf8')

  // MANIFEST 要在打 zip 之前写，否则包里没有它
  const totalBytes = files.reduce((n, f) => n + fs.statSync(f).size, 0)
  fs.writeFileSync(path.join(OUT, 'MANIFEST.md'), [
    `# 鱼神 · 出厂包 v${version}`,
    '',
    `- 打包时间：${new Date().toLocaleString('zh-CN')}`,
    `- 版本：${version}`,
    `- 包内文件：${files.length} 个，${(totalBytes / 1024 / 1024).toFixed(2)} MB`,
    `- 要求：Node ≥ 22.13、DeepSeek Harness 0.2.1-rc.2 或更新`,
    `- 这个包的校验和见同目录上一级 RELEASE.md`,
    '',
  ].join('\n'), 'utf8')

  // zip
  const zipName = `yushen-core-v${version}-${stamp}.zip`
  const zipPath = path.join(DIST, zipName)
  if (fs.existsSync(zipPath)) fs.rmSync(zipPath, { force: true })
  execFileSync('powershell', ['-NoProfile', '-Command',
    `Compress-Archive -Path '${OUT}\\*' -DestinationPath '${zipPath}' -Force`], { stdio: 'pipe', timeout: 300000 })
  const buf = fs.readFileSync(zipPath)

  // MANIFEST
  const manifest = [
    `# 鱼神 · 出厂包 v${version}`,
    '',
    `- 打包时间：${new Date().toLocaleString('zh-CN')}`,
    `- 版本：${version}`,
    `- 源：本机最新工作副本`,
    `- 文件：${files.length} 个，${(totalBytes / 1024 / 1024).toFixed(2)} MB`,
    `- zip：${zipName}（${(buf.length / 1024 / 1024).toFixed(2)} MB，sha256 ${sha256(buf).slice(0, 16)}…）`,
    `- 要求：Node ≥ 22.13、DeepSeek Harness 0.2.1-rc.2 或更新`,
    `- 这台机器上：node ${process.version}、${os.type()} ${os.release()}`,
    '',
    '## 包里有什么',
    '点化运行时（lib）、宪章/三问/礼物（core）、适配器（adapters）、出厂骨架（kernel/blank/preset）、鱼窝基本型（client.js）、安装脚本。',
    '',
    '## 包里没有什么',
    '她们的卡、记忆、故事、称呼、入口，作者数据，本机路径，密钥。',
    '',
  ].join('\n')
  fs.writeFileSync(path.join(DIST, 'RELEASE.md'), manifest, 'utf8')

  return { zipPath, zipName, files: files.length, totalMB: Number((totalBytes / 1024 / 1024).toFixed(2)), sha: sha256(buf).slice(0, 16) }
})

// ── 汇总 ───────────────────────────────────────────────────
const zip = { zipPath: '', zipName: '', files: 0, totalMB: 0, sha: '' }
for (const f of fs.readdirSync(DIST)) if (f.startsWith('yushen-core-v') && f.endsWith('.zip')) { zip.zipName = f; zip.zipPath = path.join(DIST, f) }
if (zip.zipPath) {
  const buf = fs.readFileSync(zip.zipPath)
  zip.sha = sha256(buf).slice(0, 16)
  zip.totalMB = Number((buf.length / 1024 / 1024).toFixed(2))
}
process.stdout.write(`\n${JSON.stringify({ ok: true, version, zip: zip.zipName, path: zip.zipPath, zipMB: zip.totalMB, sha: zip.sha, at: new Date().toISOString() }, null, 2)}\n`)
process.stdout.write(`\n出厂完成：${zip.zipPath}\n`)
