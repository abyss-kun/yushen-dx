// 联想 / 等待 / 纠错：三样现在就能做的"更像人"。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-growth-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const rc = await import('../lib/recollect.js')
const wt = await import('../lib/waiting.js')
const co = await import('../lib/corrections.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-27T10:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 联想：同一类事能想起来；不相关的不硬凑
const entries = [
  { at: '2026-10-20T10:00:00Z', text: '群里有人问 DeepSeek 的配置怎么改', channel: 'qq' },
  { at: '2026-10-21T10:00:00Z', text: '老板说今天天气不错', channel: 'workbench' },
  { at: '2026-10-22T10:00:00Z', text: '配置文件的路径在 ~/.dsh/config.json', channel: 'workbench' },
]
const hit = rc.associate({ query: '配置怎么改', entries, now: NOW })
assert.ok(hit.some((x) => x.text.includes('配置')), '该想起来的没想起来')
assert.ok(hit.length <= 5)

// 2) 等待：到点标出来；不催
const w = wt.addWaiting(ROLE, { what: '等他回我方案', until: NOW - 3600000, who: '老板', now: NOW - 7200000 })
const list = wt.listWaiting(ROLE, { now: NOW })
assert.equal(list.length, 1)
assert.equal(list[0].due, true)
assert.match(wt.waitingLine(ROLE, { now: NOW }), /到点了/)
wt.finishWaiting(ROLE, w.id)
assert.equal(wt.listWaiting(ROLE, { now: NOW }).length, 0)

// 3) 纠错：记住"上次这样不对"，进注入
assert.throws(() => co.noteCorrection(ROLE, {}), /纠正你什么/)
co.noteCorrection(ROLE, { what: '回消息太像客服', was: '收到您的消息', should: '直接说事', now: NOW })
assert.match(co.correctionLine(ROLE), /回消息太像客服/)
assert.match(co.correctionLine(ROLE), /直接说事/)

// 4) 没记录时注入是空的（不硬编）
assert.equal(co.correctionLine('dragon'), '')
assert.equal(wt.waitingLine('dragon'), '')

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, associate: true, waiting: true, due: true, corrections: true, empty: true }))
