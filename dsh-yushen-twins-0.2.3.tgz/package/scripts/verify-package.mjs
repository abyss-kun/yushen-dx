// 出厂包自检：不依赖作者机器、不依赖 DSH，只看包里该有的和不该有的。
// 运行：node scripts/verify-package.mjs [包目录]

import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const dir = path.resolve(process.argv[2] || path.join(HERE, '..', 'dist', 'dsh-yushen-twins'))
const node = process.execPath
let pass = 0
let fail = 0

function ok(name, fn) {
  try { const d = fn(); pass += 1; console.log(`✓ ${name}${d ? ` — ${d}` : ''}`) }
  catch (e) { fail += 1; console.error(`✗ ${name} — ${e?.message || e}`) }
}
const has = (rel) => {
  const p = path.join(dir, rel)
  if (!fs.existsSync(p)) throw new Error(`缺 ${rel}`)
  return true
}
const read = (rel) => fs.readFileSync(path.join(dir, rel), 'utf8')

ok('入口与客户端', () => { has('index.js'); has('client.js'); has('package.json'); return '四件在' })
ok('核心目录', () => { for (const d of ['dayu', 'xiaoyu', 'lib', 'core', 'adapters']) has(d); return '5 个目录' })
ok('出厂内核与白纸', () => { has('kernel/charter.default.json'); has('blank/persona.blank.json'); return '无作者数据' })
ok('手册与文档', () => {
  for (const f of ['docs/员工手册.md', 'docs/交接手册.md', 'docs/职责清单.md', 'docs/世界观设定.md', 'docs/角色-大鱼.md', 'docs/基线清单.md', 'docs/框架定义.md']) has(f)
  return '公开文档齐'
})
ok('权属三件 + CHANGELOG', () => { for (const f of ['LICENSE', 'NOTICE', 'THIRD_PARTY.md', 'CHANGELOG.md']) has(f); return '齐' })
ok('运行时脚本（自省/验收）', () => {
  for (const f of ['scripts/smoke.mjs', 'scripts/live-check.mjs', 'scripts/regression.mjs', 'scripts/verify-settings.mjs', 'scripts/baseline.mjs', 'scripts/gen-usage.mjs', 'scripts/note-work.mjs']) has(f)
  return '7 个'
})

ok('禁品检查（魂/账/交接/令牌/备份）', () => {
  const bad = []
  const walk = (rel) => {
    const full = path.join(dir, rel)
    const st = fs.statSync(full)
    if (st.isDirectory()) { for (const n of fs.readdirSync(full)) walk(path.join(rel, n)); return }
    if (/(^|[\\/])(soul|events|handoff|archive)([\\/]|$)/.test(rel) || /owner\.md$|dispatch\.json$|incidents\.json$|api-token$|\.bak/i.test(rel)) bad.push(rel)
  }
  walk('')
  if (bad.length) throw new Error(`带进了私货：${bad.slice(0, 3).join(', ')}`)
  return '干净'
})

ok('语法全过', () => {
  const files = []
  const walk = (rel) => {
    const full = path.join(dir, rel)
    const st = fs.statSync(full)
    if (st.isDirectory()) { for (const n of fs.readdirSync(full)) walk(path.join(rel, n)); return }
    if (/\.(js|mjs)$/.test(rel)) files.push(full)
  }
  walk('')
  for (const f of files) execFileSync(node, ['--check', f], { stdio: 'pipe' })
  return `${files.length} 个`
})

ok('无 DSH 也能加载入口', () => {
  const code = `import(${JSON.stringify(pathToFileURL(path.join(dir, 'index.js')).href)}).then(m=>{if(typeof m.apply!=='function')process.exit(3)}).catch(e=>{console.error(e.message);process.exit(4)})`
  execFileSync(node, ['--input-type=module', '-e', code], { stdio: 'pipe' })
  return 'apply 正常'
})

ok('包里没有作者私名（从零/小零）', () => {
  const hits = []
  const skipFiles = new Set(['scripts/verify-settings.mjs', 'scripts/verify-package.mjs'])
  const walk = (rel) => {
    if (skipFiles.has(rel.replace(/\\/g, '/'))) return
    const full = path.join(dir, rel)
    const st = fs.statSync(full)
    if (st.isDirectory()) { for (const n of fs.readdirSync(full)) walk(path.join(rel, n)); return }
    if (!/\.(js|mjs|json|md)$/.test(rel)) return
    for (const line of fs.readFileSync(full, 'utf8').split(/\r?\n/)) {
      if (/从零开始|从零开始/.test(line)) continue
      const named = /['"`]从零['"`]|['"`]小零['"`]/.test(line) || /从零[、，,]\s*小零/.test(line) || /(名字|昵称|称呼)[^。]{0,20}从零/.test(line)
      if (!named) continue
      if (/版权|Copyright|author|作者|邮箱|@/i.test(line)) continue
      hits.push(`${rel}: ${line.trim().slice(0, 40)}`)
    }
  }
  walk('')
  if (hits.length) throw new Error(`私名外泄：${hits.slice(0, 3).join(' | ')}`)
  return '干净'
})

console.log(`\n出厂自检：通过 ${pass}，失败 ${fail}`)
process.exit(fail ? 1 : 0)
