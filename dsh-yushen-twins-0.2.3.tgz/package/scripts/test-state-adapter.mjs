// 鱼神双子星 · state-adapter 自测
// 覆盖：外部心情只读（env / DSH_HOME/dayu / BILI_STATE_DIR / 默认 DSH_HOME/bili-duty）、
//       策略逐字对齐 B 站 moodPolicy、历史只取同一本、reason/note 保留与截断、
//       角色隔离、日记 owner/private、路径拒绝、观察式心情落盘不动人格、观察去重、
//       大鱼默认不继承小鱼心情（需显式映射）。
// 全程用临时 DSH_HOME，跑完清掉；不碰真实 ~/.dsh、不碰任何外部插件数据。
//
// 运行：C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe dsh-yushen-twins/scripts/test-state-adapter.mjs

import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import {
  DIARY_BOOKS,
  MAX_DIARY_TEXT,
  MAX_EXTERNAL_NOTE,
  MAX_EXTERNAL_REASON,
  ROLES,
  appendFishDiary,
  applyMoodSnapshot,
  diaryFile,
  moodPolicy,
  readExternalMood,
  readFishState,
  recordFishState,
  stateFile,
} from '../lib/state-adapter.js'

const BASE = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-state-adapter-'))
const ENV_KEYS = ['DSH_HOME', 'YUSHEN_MOOD_FILE', 'BILI_STATE_DIR']

let passed = 0
let failed = 0
const failures = []

function check(name, fn) {
  try {
    fn()
    passed += 1
    console.log(`  ok   ${name}`)
  } catch (err) {
    failed += 1
    failures.push({ name, err })
    console.log(`  FAIL ${name}`)
    console.log(`       ${err && err.message ? err.message : err}`)
  }
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true })
}

function writeText(file, text) {
  ensureDir(path.dirname(file))
  fs.writeFileSync(file, text, 'utf8')
}

function writeJson(file, data) {
  writeText(file, `${JSON.stringify(data, null, 2)}\n`)
}

function writeJsonl(file, rows) {
  writeText(file, rows.map((row) => JSON.stringify(row)).join('\n') + '\n')
}

function labelDir(label) {
  return path.join(BASE, label)
}

// 每个用例一个独立临时 DSH_HOME；顺手清掉 YUSHEN_MOOD_FILE / BILI_STATE_DIR，避免环境串味。
function scenario(label, env, fn) {
  const home = labelDir(label)
  ensureDir(home)
  const saved = {}
  for (const key of ENV_KEYS) {
    saved[key] = process.env[key]
    const value = key === 'DSH_HOME' ? home : env[key]
    if (value === undefined || value === null) delete process.env[key]
    else process.env[key] = String(value)
  }
  try {
    return fn(home)
  } finally {
    for (const key of ENV_KEYS) {
      if (saved[key] === undefined) delete process.env[key]
      else process.env[key] = saved[key]
    }
  }
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')
}

function snapshotTree(dirs) {
  const out = {}
  const walk = (dir) => {
    let names
    try {
      names = fs.readdirSync(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const item of names) {
      const file = path.join(dir, item.name)
      if (item.isDirectory()) walk(file)
      else out[path.relative(BASE, file).replace(/\\/g, '/')] = `${sha256(file)}|${fs.statSync(file).mtimeMs}`
    }
  }
  for (const dir of dirs) walk(dir)
  return out
}

function readDiaryRows(file) {
  const text = fs.readFileSync(file, 'utf8').trim()
  if (!text) return []
  return text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line))
}

// ---------------- 外部心情读取 ----------------

check('外部心情：YUSHEN_MOOD_FILE 优先，历史只取 env 同一本', () => {
  const label = 'env-priority'
  const envDir = path.join(labelDir(label), 'ext')
  const envFile = path.join(envDir, 'mood.json')
  scenario(label, { YUSHEN_MOOD_FILE: envFile }, (home) => {
    writeJson(path.join(home, 'dayu', 'mood.json'), { mood: 40 })
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [{ mood: 40, at: '2026-10-22T00:00:00.000Z' }])
    writeJson(envFile, { value: 82, at: '2026-10-23T10:00:00.000Z' })
    writeJsonl(path.join(envDir, 'mood-history.jsonl'), [
      { value: 70, reason: 'duty', note: '刷完一轮', at: '2026-10-23T09:00:00.000Z' },
      { value: 82, reason: 'rewrite', note: '看完视频开心', at: '2026-10-23T10:00:00.000Z' },
    ])

    const r = readExternalMood({ role: 'xiaoyu' })
    assert.equal(r.ok, true)
    assert.equal(r.source, 'env:YUSHEN_MOOD_FILE')
    assert.equal(r.book, 'env')
    assert.equal(r.role, 'xiaoyu')
    assert.equal(r.value, 82)
    assert.equal(r.at, '2026-10-23T10:00:00.000Z')
    assert.equal(r.policy.level, 'high')
    assert.equal(r.history.length, 2)
    assert.deepEqual(r.history.map((row) => row.value), [70, 82])
    assert.ok(r.history.every((row) => row.source === 'env:mood-history.jsonl'))
    assert.equal(r.reason, 'rewrite')
    assert.equal(r.note, '看完视频开心')
    assert.ok(Array.isArray(r.limitations) && r.limitations.length > 0)
  })
})

check('外部心情：DSH_HOME/dayu/mood.json 可读，reason/note 取自同本历史', () => {
  scenario('dsh-mood', {}, (home) => {
    writeJson(path.join(home, 'dayu', 'mood.json'), { value: 55, updatedAt: '2026-10-23T09:00:00+08:00' })
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [
      { value: 60, reason: 'rest', note: '歇了一会儿', at: '2026-10-23T00:30:00.000Z' },
      { value: 55, reason: 'duty', note: '刷完有点累', at: '2026-10-23T01:00:00.000Z' },
    ])

    const r = readExternalMood({ role: 'xiaoyu' })
    assert.equal(r.ok, true)
    assert.equal(r.source, 'dsh:dayu/mood.json')
    assert.equal(r.value, 55)
    assert.equal(r.at, '2026-10-23T01:00:00.000Z')
    assert.equal(r.policy.level, 'stable')
    assert.equal(r.policy.picks, 4)
    assert.equal(r.reason, 'duty')
    assert.equal(r.note, '刷完有点累')
    assert.deepEqual(r.history.map((row) => row.source), ['dsh:dayu/mood-history.jsonl', 'dsh:dayu/mood-history.jsonl'])
  })
})

check('外部心情：没有 mood.json 时用同本 mood-history 的最后一条', () => {
  scenario('dsh-history', {}, (home) => {
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [
      { mood: 30, at: '2026-10-23T00:00:00.000Z' },
      { mood: 45, at: '2026-10-23T01:00:00.000Z' },
      { mood: 61, at: '2026-10-23T02:00:00.000Z' },
    ])

    const r = readExternalMood()
    assert.equal(r.ok, true)
    assert.equal(r.source, 'dsh:dayu/mood-history.jsonl')
    assert.equal(r.value, 61)
    assert.equal(r.at, '2026-10-23T02:00:00.000Z')
    assert.equal(r.history.length, 3)
    assert.deepEqual(r.history.map((row) => row.value), [30, 45, 61])
  })
})

check('外部心情：BILI_STATE_DIR 显式指定时优先用它', () => {
  const label = 'bili-env'
  const biliDir = path.join(labelDir(label), 'bili')
  scenario(label, { BILI_STATE_DIR: biliDir }, (home) => {
    assert.equal(home, labelDir(label))
    writeJson(path.join(biliDir, 'mood.json'), { mood: 47 })
    writeJsonl(path.join(biliDir, 'mood-history.jsonl'), [
      { mood: 20, at: '2026-10-23T00:00:00.000Z' },
      { mood: 25, at: '2026-10-23T01:00:00.000Z' },
    ])

    const r = readExternalMood({ role: 'xiaoyu' })
    assert.equal(r.ok, true)
    assert.equal(r.source, 'bili:BILI_STATE_DIR/mood.json')
    assert.equal(r.book, 'bili')
    assert.equal(r.value, 47)
    assert.equal(r.policy.level, 'tired')
    assert.equal(r.policy.skipChance, 0.35)
    assert.equal(r.policy.picks, 3)
    assert.deepEqual(r.history.map((row) => row.value), [20, 25])
    assert.ok(r.history.every((row) => row.source.startsWith('bili:BILI_STATE_DIR/')))
  })
})

check('外部心情：未设 BILI_STATE_DIR 时探测默认家目录 DSH_HOME/bili-duty', () => {
  scenario('bili-default-home', {}, (home) => {
    writeJson(path.join(home, 'bili-duty', 'mood.json'), { value: 52 })
    writeJsonl(path.join(home, 'bili-duty', 'mood-history.jsonl'), [
      { value: 48, reason: 'duty', note: '刷完', at: '2026-10-23T00:00:00.000Z' },
      { value: 52, reason: 'rest', note: '缓过来一点', at: '2026-10-23T01:00:00.000Z' },
    ])

    const r = readExternalMood()
    assert.equal(r.ok, true)
    assert.equal(r.source, 'bili:DSH_HOME/bili-duty/mood.json')
    assert.equal(r.book, 'bili')
    assert.equal(r.value, 52)
    assert.equal(r.policy.level, 'stable')
    assert.equal(r.reason, 'rest')
    assert.equal(r.note, '缓过来一点')
    assert.deepEqual(r.history.map((row) => row.source), [
      'bili:DSH_HOME/bili-duty/mood-history.jsonl',
      'bili:DSH_HOME/bili-duty/mood-history.jsonl',
    ])
  })
})

check('外部心情：三处都没有时 ok=false 且说明探测范围', () => {
  scenario('missing', {}, (home) => {
    const r = readExternalMood({ role: 'xiaoyu' })
    assert.equal(r.ok, false)
    assert.equal(r.source, null)
    assert.equal(r.value, null)
    assert.equal(r.at, null)
    assert.equal(r.policy, null)
    assert.deepEqual(r.history, [])
    assert.ok(r.limitations.some((line) => line.includes('没找到可用的外部心情数据')))
    assert.ok(r.probed.includes('dsh:dayu/mood.json'))
    assert.ok(r.probed.includes('bili:DSH_HOME/bili-duty/mood.json'))
    // 只读：探测失败不能顺手在 DSH_HOME 里造目录/文件
    assert.equal(fs.existsSync(path.join(home, 'dayu')), false)
    assert.equal(fs.existsSync(path.join(home, 'bili-duty')), false)
  })
})

check('外部心情：env 指向不存在的文件时回退本地并留痕', () => {
  const label = 'env-missing'
  const envFile = path.join(labelDir(label), 'ext', 'nope.json')
  scenario(label, { YUSHEN_MOOD_FILE: envFile }, (home) => {
    writeJson(path.join(home, 'dayu', 'mood.json'), { mood: 66 })

    const r = readExternalMood()
    assert.equal(r.ok, true)
    assert.equal(r.source, 'dsh:dayu/mood.json')
    assert.equal(r.value, 66)
    assert.ok(r.limitations.some((line) => line.includes('YUSHEN_MOOD_FILE')))
  })
})

check('外部心情：历史不混本（两本 history 同时存在也只取命中那本）', () => {
  const label = 'history-no-mix'
  const biliDir = path.join(labelDir(label), 'bili')
  scenario(label, { BILI_STATE_DIR: biliDir }, (home) => {
    writeJson(path.join(home, 'dayu', 'mood.json'), { mood: 66 })
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [
      { value: 65, reason: 'a', at: '2026-10-23T00:00:00.000Z' },
      { value: 66, reason: 'b', at: '2026-10-23T01:00:00.000Z' },
    ])
    writeJsonl(path.join(biliDir, 'mood-history.jsonl'), [
      { value: 10, reason: 'x', at: '2026-10-23T02:00:00.000Z' },
      { value: 20, reason: 'y', at: '2026-10-23T03:00:00.000Z' },
    ])

    const r = readExternalMood()
    assert.equal(r.ok, true)
    assert.equal(r.source, 'dsh:dayu/mood.json')
    assert.deepEqual(r.history.map((row) => row.value), [65, 66])
    assert.ok(r.history.every((row) => row.source === 'dsh:dayu/mood-history.jsonl'))
  })
})

check('外部心情：当前值来自 history 时，历史仍只取那一本', () => {
  const label = 'history-no-mix-2'
  const biliDir = path.join(labelDir(label), 'bili')
  scenario(label, { BILI_STATE_DIR: biliDir }, (home) => {
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [
      { value: 41, reason: 'duty', note: '刷完', at: '2026-10-23T00:00:00.000Z' },
    ])
    writeJsonl(path.join(biliDir, 'mood-history.jsonl'), [{ value: 11, at: '2026-10-23T01:00:00.000Z' }])

    const r = readExternalMood()
    assert.equal(r.ok, true)
    assert.equal(r.source, 'dsh:dayu/mood-history.jsonl')
    assert.equal(r.value, 41)
    assert.equal(r.reason, 'duty')
    assert.deepEqual(r.history.map((row) => row.value), [41])
    assert.deepEqual(r.history.map((row) => row.source), ['dsh:dayu/mood-history.jsonl'])
  })
})

check('外部心情：reason/note 保留且截断', () => {
  const label = 'reason-note'
  const biliDir = path.join(labelDir(label), 'bili')
  scenario(label, { BILI_STATE_DIR: biliDir }, () => {
    writeJson(path.join(biliDir, 'mood.json'), { value: 50 })
    writeJsonl(path.join(biliDir, 'mood-history.jsonl'), [
      { value: 50, reason: 'r'.repeat(500), note: 'n'.repeat(500), at: '2026-10-23T00:00:00.000Z' },
    ])

    const r = readExternalMood()
    assert.equal(r.reason.length, MAX_EXTERNAL_REASON)
    assert.equal(r.note.length, MAX_EXTERNAL_NOTE)
    assert.deepEqual(r.history[0].source, 'bili:BILI_STATE_DIR/mood-history.jsonl')
  })
})

check('外部心情：只读，不改外部文件也不新建', () => {
  const label = 'readonly'
  const biliDir = path.join(labelDir(label), 'bili')
  scenario(label, { BILI_STATE_DIR: biliDir }, (home) => {
    writeJson(path.join(biliDir, 'mood.json'), { mood: 64 })
    writeJsonl(path.join(biliDir, 'mood-history.jsonl'), [
      { mood: 64, reason: 'duty', note: '刷完', at: '2026-10-23T01:00:00.000Z' },
    ])
    writeJson(path.join(home, 'dayu', 'mood.json'), { mood: 58 })

    const before = snapshotTree([biliDir, path.join(home, 'dayu')])
    const first = readExternalMood({ role: 'xiaoyu' })
    readExternalMood({ role: 'dayu' })
    const after = snapshotTree([biliDir, path.join(home, 'dayu')])

    assert.equal(first.ok, true)
    assert.deepEqual(after, before)
  })
})

check('外部心情：大鱼默认不继承小鱼（未显式映射时 ok=false）', () => {
  scenario('dayu-gate', {}, (home) => {
    writeJson(path.join(home, 'dayu', 'mood.json'), { mood: 88 })
    writeJsonl(path.join(home, 'dayu', 'mood-history.jsonl'), [
      { mood: 88, reason: 'duty', at: '2026-10-23T00:00:00.000Z' },
    ])

    const r = readExternalMood({ role: 'dayu' })
    assert.equal(r.ok, false)
    assert.equal(r.source, null)
    assert.equal(r.value, null)
    assert.equal(r.policy, null)
    assert.deepEqual(r.history, [])
    assert.deepEqual(r.probed, [])
    assert.ok(r.limitations.some((line) => line.includes('属于小鱼')))
  })
})

check('外部心情：大鱼在显式 BILI_STATE_DIR / YUSHEN_MOOD_FILE 下可读', () => {
  const labelA = 'dayu-authorized-bili'
  const biliDir = path.join(labelDir(labelA), 'bili')
  scenario(labelA, { BILI_STATE_DIR: biliDir }, () => {
    writeJson(path.join(biliDir, 'mood.json'), { value: 90 })
    const r = readExternalMood({ role: 'dayu' })
    assert.equal(r.ok, true)
    assert.equal(r.role, 'dayu')
    assert.equal(r.source, 'bili:BILI_STATE_DIR/mood.json')
    assert.equal(r.value, 90)
  })

  const labelB = 'dayu-authorized-env'
  const envFile = path.join(labelDir(labelB), 'ext', 'mood.json')
  scenario(labelB, { YUSHEN_MOOD_FILE: envFile }, () => {
    writeJson(envFile, { value: 73 })
    const r = readExternalMood({ role: 'dayu' })
    assert.equal(r.ok, true)
    assert.equal(r.source, 'env:YUSHEN_MOOD_FILE')
    assert.equal(r.value, 73)
  })
})

// ---------------- 策略分档（逐字对齐 B 站源码） ----------------

check('策略：精确值逐档对齐 moodPolicy（含 45 回复线 / 85 陌生人线）', () => {
  scenario('policy-exact', {}, (home) => {
    const cases = [
      [100, { level: 'high', skipChance: 0.05, picks: 5, comment: true, reply: true, vent: false, stranger: 'brag' }],
      [85, { level: 'high', skipChance: 0.05, picks: 5, comment: true, reply: true, vent: false, stranger: 'brag' }],
      [84, { level: 'high', skipChance: 0.05, picks: 5, comment: true, reply: true, vent: false, stranger: 'none' }],
      [70, { level: 'high', skipChance: 0.05, picks: 5, comment: true, reply: true, vent: false, stranger: 'none' }],
      [69, { level: 'stable', skipChance: 0.15, picks: 4, comment: true, reply: true, vent: false, stranger: 'none' }],
      [50, { level: 'stable', skipChance: 0.15, picks: 4, comment: true, reply: true, vent: false, stranger: 'none' }],
      [49, { level: 'tired', skipChance: 0.35, picks: 3, comment: true, reply: true, vent: false, stranger: 'none' }],
      [45, { level: 'tired', skipChance: 0.35, picks: 3, comment: true, reply: true, vent: false, stranger: 'none' }],
      [44, { level: 'tired', skipChance: 0.35, picks: 3, comment: true, reply: false, vent: false, stranger: 'none' }],
      [35, { level: 'tired', skipChance: 0.35, picks: 3, comment: true, reply: false, vent: false, stranger: 'none' }],
      [34, { level: 'low', skipChance: 0.7, picks: 2, comment: false, reply: false, vent: true, stranger: 'vent' }],
      [0, { level: 'low', skipChance: 0.7, picks: 2, comment: false, reply: false, vent: true, stranger: 'vent' }],
    ]
    for (const [value, expected] of cases) {
      writeJson(path.join(home, 'dayu', 'mood.json'), { mood: value })
      const r = readExternalMood()
      assert.equal(r.ok, true)
      assert.equal(r.value, value)
      assert.deepEqual(r.policy, expected, `mood=${value} 的策略必须与 B 站 moodPolicy 一致`)
      assert.deepEqual(moodPolicy(value), expected, `moodPolicy(${value}) 必须与 B 站一致`)
    }
  })
})

check('策略：非法值返回 null，单调性成立', () => {
  assert.equal(moodPolicy(Number.NaN), null)
  assert.equal(moodPolicy(undefined), null)
  assert.equal(moodPolicy('abc'), null)

  const tiers = [moodPolicy(80), moodPolicy(60), moodPolicy(40), moodPolicy(10)]
  for (let i = 1; i < tiers.length; i += 1) {
    assert.ok(tiers[i].skipChance >= tiers[i - 1].skipChance, '心情越低越容易跳过')
    assert.ok(tiers[i].picks <= tiers[i - 1].picks, '心情越低挑得越少')
  }
})

// ---------------- 鱼神自己的状态 ----------------

check('状态：路径落在 DSH_HOME/dayu/state，缺文件给默认值', () => {
  scenario('state-defaults', {}, (home) => {
    assert.equal(stateFile('dayu'), path.join(home, 'dayu', 'state', 'dayu.json'))
    assert.equal(stateFile('xiaoyu'), path.join(home, 'dayu', 'state', 'xiaoyu.json'))

    const s = readFishState('xiaoyu')
    assert.deepEqual(
      { mood: s.mood, expression: s.expression, lastReason: s.lastReason, updatedAt: s.updatedAt },
      { mood: 50, expression: '平静', lastReason: '', updatedAt: null },
    )
    assert.equal(s.role, 'xiaoyu')
    assert.equal(s.exists, false)
  })
})

check('状态：角色隔离，各写各的文件', () => {
  scenario('state-roles', {}, (home) => {
    const dayu = recordFishState('dayu', { mood: 77, expression: '得意' }, { note: '今天赢了' })
    assert.equal(dayu.ok, true)
    assert.equal(dayu.file, path.join(home, 'dayu', 'state', 'dayu.json'))
    assert.equal(fs.existsSync(path.join(home, 'dayu', 'state', 'dayu.json')), true)
    assert.equal(fs.existsSync(path.join(home, 'dayu', 'state', 'xiaoyu.json')), false)

    const xiaoyuBefore = readFishState('xiaoyu')
    assert.equal(xiaoyuBefore.exists, false)
    assert.equal(xiaoyuBefore.mood, 50)

    recordFishState('xiaoyu', { mood: 33 })
    assert.equal(readFishState('xiaoyu').mood, 33)
    assert.equal(readFishState('dayu').mood, 77)
    assert.equal(readFishState('dayu').expression, '得意')
    assert.notEqual(readFishState('dayu').updatedAt, null)
  })
})

check('状态：只接受 mood / expression / lastReason', () => {
  scenario('state-fields', {}, () => {
    assert.throws(() => recordFishState('xiaoyu', { persona: { name: '假人' } }), /不能写 persona/)
    assert.throws(() => recordFishState('xiaoyu', { mood: 50, owner: 'x' }), /不能写 owner/)
    assert.throws(() => recordFishState('xiaoyu', { mood: 'abc' }), /mood 必须是/)
    assert.throws(() => recordFishState('xiaoyu', {}), /没有要写的内容/)
    assert.throws(() => recordFishState('xiaoyu', null), /patch 必须是对象/)
    assert.throws(() => recordFishState('xiaoyu', []), /patch 必须是对象/)
  })
})

check('状态：mood 夹到 0~100，note 进 notes 并截断', () => {
  scenario('state-clamp', {}, () => {
    recordFishState('xiaoyu', { mood: 150 })
    assert.equal(readFishState('xiaoyu').mood, 100)
    recordFishState('xiaoyu', { mood: -20 })
    assert.equal(readFishState('xiaoyu').mood, 0)

    recordFishState('xiaoyu', { expression: '困' }, { note: '鱼'.repeat(500) })
    const s = readFishState('xiaoyu')
    assert.equal(s.expression, '困')
    assert.equal(s.notes.length, 1)
    assert.equal(s.notes[0].note.length, 300)
    assert.equal(typeof s.notes[0].at, 'string')
  })
})

check('状态：已有 persona 不被 recordFishState 覆盖', () => {
  scenario('state-persona', {}, (home) => {
    const file = path.join(home, 'dayu', 'state', 'xiaoyu.json')
    writeJson(file, { persona: { name: '小肥鱼', core: '妹妹' }, mood: 70, expression: '平静' })

    recordFishState('xiaoyu', { mood: 64, lastReason: '刷完一轮' })

    const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
    assert.deepEqual(raw.persona, { name: '小肥鱼', core: '妹妹' })
    assert.equal(raw.mood, 64)
    assert.equal(raw.lastReason, '刷完一轮')
    assert.equal(readFishState('xiaoyu').persona.core, '妹妹')
  })
})

// ---------------- 日记 ----------------

check('日记：默认 private，字段 role/source/at/text/category 齐全', () => {
  scenario('diary-default', {}, (home) => {
    const out = appendFishDiary('dayu', { text: '今天刷到个好视频', category: 'mood', source: 'bili' })
    assert.equal(out.ok, true)
    assert.equal(out.book, 'private')
    assert.equal(out.file, path.join(home, 'dayu', 'diary', 'dayu', 'private.jsonl'))
    assert.equal(diaryFile('dayu'), path.join(home, 'dayu', 'diary', 'dayu', 'private.jsonl'))
    assert.equal(diaryFile('xiaoyu', 'owner'), path.join(home, 'dayu', 'diary', 'xiaoyu', 'owner.jsonl'))

    const rows = readDiaryRows(out.file)
    assert.equal(rows.length, 1)
    const row = rows[0]
    assert.equal(row.role, 'dayu')
    assert.equal(row.source, 'bili')
    assert.equal(typeof row.at, 'string')
    assert.equal(row.text, '今天刷到个好视频')
    assert.equal(row.category, 'mood')
    assert.equal(row.book, 'private')
  })
})

check('日记：owner 与 private 分文件，互不串行', () => {
  scenario('diary-books', {}, (home) => {
    appendFishDiary('dayu', '私房话')
    appendFishDiary('dayu', { text: '给老板看的', category: 'report' }, 'owner')

    const priv = path.join(home, 'dayu', 'diary', 'dayu', 'private.jsonl')
    const owner = path.join(home, 'dayu', 'diary', 'dayu', 'owner.jsonl')
    assert.equal(readDiaryRows(priv).length, 1)
    assert.equal(readDiaryRows(priv)[0].text, '私房话')
    assert.equal(readDiaryRows(owner).length, 1)
    assert.equal(readDiaryRows(owner)[0].text, '给老板看的')
    assert.equal(readDiaryRows(owner)[0].book, 'owner')
  })
})

check('日记：角色隔离', () => {
  scenario('diary-roles', {}, (home) => {
    appendFishDiary('dayu', '哥哥的日记')
    appendFishDiary('xiaoyu', '妹妹的日记')

    const dayuFile = path.join(home, 'dayu', 'diary', 'dayu', 'private.jsonl')
    const xiaoyuFile = path.join(home, 'dayu', 'diary', 'xiaoyu', 'private.jsonl')
    assert.equal(readDiaryRows(dayuFile).length, 1)
    assert.equal(readDiaryRows(xiaoyuFile).length, 1)
    assert.equal(readDiaryRows(dayuFile)[0].role, 'dayu')
    assert.equal(readDiaryRows(xiaoyuFile)[0].role, 'xiaoyu')
    assert.equal(readDiaryRows(dayuFile)[0].text, '哥哥的日记')
    assert.equal(readDiaryRows(xiaoyuFile)[0].text, '妹妹的日记')
  })
})

check('日记：正文超长截断', () => {
  scenario('diary-truncate', {}, () => {
    const out = appendFishDiary('xiaoyu', { text: '鱼'.repeat(5000), category: 'long' })
    assert.equal(out.row.text.length, MAX_DIARY_TEXT)
    assert.equal(readDiaryRows(out.file)[0].text.length, MAX_DIARY_TEXT)
  })
})

check('日记：空正文 / 坏入参拒绝', () => {
  scenario('diary-bad-entry', {}, () => {
    assert.throws(() => appendFishDiary('xiaoyu', ''), /日记正文不能为空/)
    assert.throws(() => appendFishDiary('xiaoyu', '   '), /日记正文不能为空/)
    assert.throws(() => appendFishDiary('xiaoyu', {}), /日记正文不能为空/)
    assert.throws(() => appendFishDiary('xiaoyu', 42), /日记内容必须是/)
    assert.throws(() => appendFishDiary('xiaoyu', ['x']), /日记内容必须是/)
  })
})

// ---------------- 路径拒绝 ----------------

check('路径拒绝：角色白名单（state / diary / external / apply）', () => {
  scenario('reject-roles', {}, (home) => {
    const badRoles = [
      '../evil',
      '..\\evil',
      'dayu/../xiaoyu',
      'C:\\Windows',
      'DAYU',
      ' admin',
      'dayu ',
      '',
      null,
      undefined,
      123,
      ['dayu'],
    ]
    for (const bad of badRoles) {
      assert.throws(() => stateFile(bad), /未知角色/, `stateFile(${String(bad)}) 应拒绝`)
      assert.throws(() => readFishState(bad), /未知角色/, `readFishState(${String(bad)}) 应拒绝`)
      assert.throws(() => recordFishState(bad, { mood: 50 }), /未知角色/, `recordFishState(${String(bad)}) 应拒绝`)
      assert.throws(() => appendFishDiary(bad, 'x'), /未知角色/, `appendFishDiary(${String(bad)}) 应拒绝`)
      assert.throws(() => applyMoodSnapshot(bad, { value: 50 }), /未知角色/, `applyMoodSnapshot(${String(bad)}) 应拒绝`)
    }
    assert.throws(() => readExternalMood({ role: 'root' }), /未知角色/)
    assert.throws(() => readExternalMood({ role: '../xiaoyu' }), /未知角色/)
    // 全部被拒 = 一个文件都没写出去
    assert.equal(fs.existsSync(path.join(home, 'dayu')), false)
  })
})

check('路径拒绝：日记本白名单，产物只落在 diary 根下', () => {
  scenario('reject-books', {}, (home) => {
    const badBooks = ['../owner', '..\\..\\owner', 'shared', 'PRIVATE', 'Private', '', null, 42]
    for (const bad of badBooks) {
      assert.throws(() => diaryFile('dayu', bad), /未知日记本/, `diaryFile(dayu, ${String(bad)}) 应拒绝`)
      assert.throws(() => appendFishDiary('dayu', 'x', bad), /未知日记本/, `appendFishDiary(book=${String(bad)}) 应拒绝`)
    }
    assert.deepEqual([...DIARY_BOOKS], ['private', 'owner'])
    assert.deepEqual([...ROLES], ['dayu', 'xiaoyu'])

    for (const role of ROLES) {
      for (const book of DIARY_BOOKS) {
        const file = diaryFile(role, book)
        assert.ok(file.startsWith(path.join(home, 'dayu', 'diary') + path.sep), '日记必须落在 diary 根下')
      }
    }
  })
})

// ---------------- 观察式心情落盘 ----------------

check('applyMoodSnapshot：只记 observation，不动人格与心情，保留 reason/note', () => {
  const label = 'apply-basic'
  const envFile = path.join(labelDir(label), 'ext', 'mood.json')
  scenario(label, { YUSHEN_MOOD_FILE: envFile }, (home) => {
    writeJson(envFile, { mood: 30, at: '2026-10-23T03:00:00.000Z' })
    writeJsonl(path.join(path.dirname(envFile), 'mood-history.jsonl'), [
      { value: 30, reason: 'duty', note: '被弹幕气到', at: '2026-10-23T03:00:00.000Z' },
    ])
    const file = path.join(home, 'dayu', 'state', 'xiaoyu.json')
    writeJson(file, { persona: { name: '小肥鱼', core: '妹妹' }, mood: 88, expression: '冷静', lastReason: '在值班' })

    const external = readExternalMood({ role: 'xiaoyu' })
    assert.equal(external.ok, true)
    assert.equal(external.value, 30)

    const applied = applyMoodSnapshot('xiaoyu', external)
    assert.equal(applied.ok, true)
    assert.equal(applied.deduped, false)
    assert.equal(applied.observation.mood, 30)
    assert.equal(applied.observation.level, 'low')
    assert.equal(applied.observation.source, 'env:YUSHEN_MOOD_FILE')
    assert.equal(applied.observation.at, '2026-10-23T03:00:00.000Z')
    assert.equal(applied.observation.reason, 'duty')
    assert.equal(applied.observation.note, '被弹幕气到')
    assert.equal(typeof applied.observation.appliedAt, 'string')

    const after = readFishState('xiaoyu')
    assert.equal(after.mood, 88)
    assert.equal(after.expression, '冷静')
    assert.equal(after.lastReason, '在值班')
    assert.deepEqual(after.persona, { name: '小肥鱼', core: '妹妹' })
    assert.equal(after.observation.mood, 30)
    assert.equal(after.observations.length, 1)
  })
})

check('applyMoodSnapshot：相同 source/value/at 去重，不写盘也不动 updatedAt', () => {
  scenario('apply-dedupe', {}, () => {
    const ext = { ok: true, value: 72, at: '2026-10-23T05:00:00.000Z', source: 'bili', reason: 'duty', note: '刷完' }
    const first = applyMoodSnapshot('xiaoyu', ext)
    assert.equal(first.ok, true)
    assert.equal(first.deduped, false)
    assert.equal(first.observation.note, '刷完')

    const file = stateFile('xiaoyu')
    const before = fs.readFileSync(file, 'utf8')
    const beforeMtime = fs.statSync(file).mtimeMs
    const beforeUpdatedAt = readFishState('xiaoyu').updatedAt

    const second = applyMoodSnapshot('xiaoyu', ext)
    assert.equal(second.ok, true)
    assert.equal(second.deduped, true)
    assert.equal(fs.readFileSync(file, 'utf8'), before, '去重时不能重写文件')
    assert.equal(fs.statSync(file).mtimeMs, beforeMtime, '去重时不能碰 mtime')
    assert.equal(readFishState('xiaoyu').updatedAt, beforeUpdatedAt, '去重时不能更新 updatedAt')
    assert.equal(readFishState('xiaoyu').observations.length, 1)

    // 三要素任一不同 → 正常追加
    const third = applyMoodSnapshot('xiaoyu', { ...ext, at: '2026-10-23T06:00:00.000Z' })
    assert.equal(third.deduped, false)
    assert.equal(readFishState('xiaoyu').observations.length, 2)

    const fourth = applyMoodSnapshot('xiaoyu', { ...ext, source: 'dsh' })
    assert.equal(fourth.deduped, false)
    assert.equal(readFishState('xiaoyu').observations.length, 3)

    // at 都为空时，同 source/value 也算同一条
    applyMoodSnapshot('xiaoyu', { ok: true, value: 50, source: 'x' })
    const noAt = applyMoodSnapshot('xiaoyu', { ok: true, value: 50, source: 'x' })
    assert.equal(noAt.deduped, true)
  })
})

check('applyMoodSnapshot：多次观察只留最近 20 条', () => {
  scenario('apply-cap', {}, () => {
    for (let i = 0; i < 25; i += 1) {
      const out = applyMoodSnapshot('dayu', { ok: true, value: 60 + (i % 10), at: `2026-10-23T00:00:${String(i).padStart(2, '0')}.000Z`, source: 'test' })
      assert.equal(out.ok, true)
    }
    const state = readFishState('dayu')
    assert.equal(state.observations.length, 20)
    assert.equal(state.observations[19].mood, 64)
    assert.equal(state.observation.mood, 64)
    assert.equal(state.mood, 50) // 默认心情没被观察改掉
  })
})

check('applyMoodSnapshot：外部不可用就不写', () => {
  scenario('apply-unavailable', {}, (home) => {
    recordFishState('xiaoyu', { mood: 71, expression: '还好' })
    const file = path.join(home, 'dayu', 'state', 'xiaoyu.json')
    const before = fs.readFileSync(file, 'utf8')

    for (const external of [{ ok: false }, null, undefined, {}, { ok: true }, { ok: true, value: 'abc' }]) {
      const out = applyMoodSnapshot('xiaoyu', external)
      assert.equal(out.ok, false)
      assert.equal(out.observation, null)
    }

    assert.equal(fs.readFileSync(file, 'utf8'), before)
    assert.equal(readFishState('xiaoyu').mood, 71)
    assert.equal(readFishState('xiaoyu').observations, undefined)
  })
})

check('applyMoodSnapshot：角色隔离，不碰另一个角色的文件', () => {
  scenario('apply-isolation', {}, (home) => {
    recordFishState('xiaoyu', { mood: 44 })
    const xiaoyuFile = path.join(home, 'dayu', 'state', 'xiaoyu.json')
    const before = fs.readFileSync(xiaoyuFile, 'utf8')

    const out = applyMoodSnapshot('dayu', { ok: true, value: 90, source: 'bili', at: '2026-10-23T04:00:00.000Z' })
    assert.equal(out.ok, true)
    assert.equal(out.role, 'dayu')

    assert.equal(fs.readFileSync(xiaoyuFile, 'utf8'), before)
    assert.equal(readFishState('xiaoyu').mood, 44)
    assert.equal(readFishState('dayu').observation.mood, 90)
    assert.equal(readFishState('dayu').observation.level, 'high')
  })
})

// ---------------- 收尾 ----------------

fs.rmSync(BASE, { recursive: true, force: true })

console.log('')
console.log(`结果：通过 ${passed}，失败 ${failed}`)
if (failed) {
  console.log('失败明细：')
  for (const item of failures) console.log(` - ${item.name}: ${item.err && item.err.message ? item.err.message : item.err}`)
  process.exitCode = 1
} else {
  console.log('state-adapter：全部断言通过')
  process.exitCode = 0
}
