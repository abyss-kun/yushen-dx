// 群聊补投：把已落盘但没有回音的群消息重新投给居民，并把她的回答写回群时间线。
// 关联靠「服务端独有 nonce 出现在她的会话正文里」，不靠会话 FIFO，也不靠时间窗猜。
// 用法：node scripts/group-redeliver.mjs [--conversation group:fish-god] [--role xiaoyu] [--dry] [--wait 120] [--watch]
import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { appendConversationEvent, listConversationEvents } from '../lib/conversation-events.js'
import { promptRpc } from '../lib/dsh-rpc.js'
import { transcriptDigest } from '../lib/transcript.js'
import { readLedger, residentRoles } from '../lib/residence.js'
import { readOutbox, markQueued, markReplied } from '../lib/group-outbox.js'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const NOISE = /^(Current runtime context|Time sampled while preparing)/

function arg(name, def) {
  const i = process.argv.indexOf(`--${name}`)
  return i > 0 ? process.argv[i + 1] : def
}
const conversationId = arg('conversation', 'group:fish-god')
const onlyRole = arg('role', '')
const dry = process.argv.includes('--dry')
const watch = process.argv.includes('--watch')
const waitMs = Number(arg('wait', '120')) * 1000

const readState = readOutbox
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function scan() {
  const rows = []
  for (const role of residentRoles()) {
    try { rows.push(...listConversationEvents({ role, channel: 'workbench', conversationId }, { limit: 200 })) } catch { /* 还没有该角色事件 */ }
  }
  const incoming = new Map()
  for (const row of rows) if (row.direction === 'incoming' && !incoming.has(row.messageId)) incoming.set(row.messageId, row)
  const answered = new Set()
  for (const r of rows) {
    if (r.direction !== 'outgoing') continue
    const m = /^reply-(owner-[0-9a-z-]+?)(?:-nonce-|-)/.exec(String(r.messageId))
    if (m) answered.add(m[1])
  }
  return { incoming, answered }
}

async function collect(ledger, report) {
  const deadline = Date.now() + waitMs
  const concluded = new Set()
  while (Date.now() < deadline) {
    let idle = true
    for (const [key, rec] of Object.entries(ledger.sent || {})) {
      if (rec.replyAt || concluded.has(key)) continue
      idle = false
      const [, messageId, role] = key.split('|')
      if (!rec.sessionId) continue
      const d = transcriptDigest(rec.sessionId, { turns: 60 })
      const turns = d.turns || []
      const at = turns.findIndex((t) => t.role === 'user' && String(t.text).includes(rec.nonce))
      if (at < 0) continue
      const collected = []
      for (let i = at + 1; i < turns.length; i += 1) {
        const t = turns[i]
        if (t.role === 'user' && !NOISE.test(String(t.text))) break
        if (t.role === 'assistant' && String(t.text || '').trim()) collected.push(t)
      }
      if (!collected.length) continue
      const last = collected[collected.length - 1]
      if (Date.now() - Date.parse(last.at || 0) < 6000) { idle = false; continue }
      try {
        appendConversationEvent({ role, channel: 'workbench', conversationId, direction: 'outgoing', messageId: `reply-${messageId}-${rec.nonce}`, text: last.text })
        rec.replyAt = new Date().toISOString()
        markReplied({ conversationId, messageId, role })
        concluded.add(key)
        report.push({ messageId, role, status: 'replied', at: last.at, chars: last.text.length })
      } catch (error) {
        report.push({ messageId, role, status: 'persist-failed', error: String(error?.message || error) })
      }
    }
    if (idle) break
    await sleep(4000)
  }
}

async function cycle() {
  const { incoming, answered } = scan()
  const ledger = readState()
  const roles = residentRoles().filter((r) => !onlyRole || r === onlyRole)
  const report = []
  for (const [messageId, row] of incoming) {
    if (answered.has(messageId)) continue
    for (const role of roles) {
      const key = `${conversationId}|${messageId}|${role}`
      if (ledger.sent?.[key]?.replyAt) continue
      const liveSession = String(readLedger().roles?.[role]?.sessionId || '')
      if (!liveSession) { report.push({ messageId, role, status: 'no-body' }); continue }
      const nonce = `nonce-${crypto.randomBytes(4).toString('hex')}`
      const prompt = `【鱼神框架群聊 ${conversationId}；发言者：老板；消息：${messageId}；群聊关联 ${nonce}】\n这是共享群聊，不是私聊。只就这条消息回答，不转述其他私聊内容。\n${row.text}`
      if (dry) { report.push({ messageId, role, status: 'dry-run', sessionId: liveSession, nonce }); continue }
      try {
        await promptRpc({ sessionId: liveSession, text: prompt })
        ledger.sent[key] = markQueued({ conversationId, messageId, role, sessionId: liveSession, nonce, via: 'redeliver' })
        report.push({ messageId, role, status: 'queued', sessionId: liveSession, nonce })
      } catch (error) {
        report.push({ messageId, role, status: 'enqueue-failed', error: String(error?.message || error) })
      }
    }
  }
  if (waitMs > 0 && !dry && report.some((x) => x.status === 'queued')) await collect(ledger, report)
  return report
}

if (watch) {
  console.log(`[group-redeliver] watch ${conversationId}，每 15 秒看一次`)
  for (;;) {
    const report = await cycle()
    if (report.length) console.log(JSON.stringify({ at: new Date().toISOString(), report }))
    await sleep(15000)
  }
} else {
  console.log(JSON.stringify({ ok: true, conversationId, waited: waitMs > 0 && !dry, report: await cycle() }, null, 2))
}
