import { archiveSource, readArchive } from '../lib/brain-archive.js'
import { qqBridgeRoot } from '../lib/paths.js'
const root = qqBridgeRoot()
const sources = [
  ['dayu', `${root}\\roles\\傲娇版大鱼.md`, 'persona'],
  ['dayu', `${root}\\roles\\大肥鱼.md`, 'persona'],
  ['dayu', `${root}\\state\\persona-memory.json`, 'history'],
  ['xiaoyu', `${root}\\roles\\小肥鱼.md`, 'persona'],
  ['xiaoyu', `${root}\\state\\persona-memory-小肥鱼.json`, 'history'],
  ['xiaoyu', `${root}\\state\\persona-memory-notes.jsonl`, 'history'],
  ['xiaoyu', `${root}\\state\\persona-journal-小肥鱼.jsonl`, 'history'],
]
for (const [role, file, kind] of sources) {
  const result = archiveSource(role, file, { kind })
  const verified = readArchive(role, result.sha256)
  console.log(JSON.stringify({ role, source: file, sha256: result.sha256, verified: verified.sha256 === result.sha256, duplicate: result.duplicate }))
}
