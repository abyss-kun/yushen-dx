// 重启后自检：一次把「三条会话挂上预设没有」这些事查清楚。
// 只读，不改任何东西。用法：node scripts/verify-after-boot.mjs
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const rows = []
const ok = (name, pass, detail = '') => rows.push({ name, pass, detail })

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')) } catch { return fallback }
}

// 1) 常驻会话：三条都在、有 sessionId
const ledger = readJson(path.join(DATA, 'residence.json'), { roles: {} })
for (const role of ['dayu', 'xiaoyu', 'dragon']) {
  const row = ledger.roles?.[role] || {}
  ok(`${role} 有常驻会话`, Boolean(row.sessionId), row.sessionId ? String(row.sessionId).slice(0, 20) : '还没有（唤醒一次会重建）')
}

// 2) 发放台账：预设是不是 yushen
const issueDir = path.join(DATA, 'runtime')
for (const role of ['dayu', 'xiaoyu', 'dragon']) {
  const row = readJson(path.join(issueDir, role, 'session-issue.json'), null)
  if (!row) { ok(`${role} 发放台账`, false, '还没有记录'); continue }
  ok(`${role} 预设=${row.preset}`, String(row.preset) === 'yushen-desk' && row.ok !== false, row.preset ? `${row.preset} / 工具 ${row.tools} 个` : '没有预设字段')
}

// 3) 分身回体：handoff 目录（桥跑过一次 digest 才会有）
const bridgeState = path.join('D:/deepseekTools/qq-bridge/state')
ok('桥 handoff 目录存在', fs.existsSync(path.join(bridgeState, 'handoff')), '桥跑一次 digest 后会有文件')

// 4) 工作账：今天有没有落
const today = new Date().toISOString().slice(0, 10)
const worklog = path.join(DATA, 'worklog', `${today}.jsonl`)
ok('今天有工作账', fs.existsSync(worklog), worklog)

// 5) 结构对账：源码和记录一致
try {
  const { execFileSync } = await import('node:child_process')
  const here = path.dirname(fileURLToPath(import.meta.url))
  execFileSync(process.execPath, [path.join(here, 'framework-record.mjs'), 'check'], { stdio: 'pipe' })
  ok('结构对账', true, '与最后一条改动记录一致')
} catch (e) {
  ok('结构对账', false, String(e?.stderr || e?.message || e).slice(0, 120))
}

const pass = rows.filter((r) => r.pass).length
for (const r of rows) console.log(`${r.pass ? '✓' : '✗'} ${r.name}${r.detail ? ` — ${r.detail}` : ''}`)
console.log(`\n自检：通过 ${pass} / ${rows.length}`)
process.exit(pass === rows.length ? 0 : 1)
