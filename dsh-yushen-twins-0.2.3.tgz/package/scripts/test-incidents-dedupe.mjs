// 事故单去重：同样的错不该半小时开一张新单；结过的单也不该吞掉复发的新单。
// 用法：node scripts/test-incidents-dedupe.mjs
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'inc-dedupe-'))
process.env.DSH_HOME = tmp

const { noteIncident, listIncidents, resolveIncident } = await import('../lib/incidents.js')
const { openCount } = await import('../lib/incidents.js')

const T0 = Date.parse('2026-10-28T01:00:00+08:00')
const MIN = 60 * 1000
const text = '真机：健康 — fetch failed；真机：状态 — fetch failed'

// 1) 同一个错，40 分钟一次，连来三次 —— 应该只有一张单、次数 3
const a = noteIncident({ sessionId: 'selfcheck', title: '自省：站不稳', source: 'self-check', text, at: T0 })
const b = noteIncident({ sessionId: 'selfcheck', title: '自省：站不稳', source: 'self-check', text, at: T0 + 40 * MIN })
const c = noteIncident({ sessionId: 'selfcheck', title: '自省：站不稳', source: 'self-check', text, at: T0 + 80 * MIN })
const rows1 = listIncidents({ limit: 50 })
const same = rows1.filter((r) => r.text === text)

// 2) 结单后再复发 —— 应该开新单，而不是给旧单 +1
resolveIncident(a.id, { status: 'fixed', note: '测试结单' })
const d = noteIncident({ sessionId: 'selfcheck', title: '自省：站不稳', source: 'self-check', text, at: T0 + 100 * MIN })
const rows2 = listIncidents({ limit: 50 })
const same2 = rows2.filter((r) => r.text === text)

const out = {
  sameIds: same.map((r) => r.id),
  sameCounts: same.map((r) => r.count),
  afterResolveIds: same2.map((r) => r.id),
  newIncidentIsNew: d.id !== a.id,
  open: openCount(),
}
const fail = []
if (same.length !== 1) fail.push(`40 分钟间隔的同一个错开了 ${same.length} 张单（应该 1 张）`)
if (Number(same[0]?.count) !== 3) fail.push(`次数应为 3，实际 ${same[0]?.count}`)
if (!out.newIncidentIsNew) fail.push('结单后复发被吞进旧单，没开新单')
if (same2.length !== 2) fail.push(`结单后复发后应有 2 张单，实际 ${same2.length}`)

fs.rmSync(tmp, { recursive: true, force: true })
if (fail.length) { console.error(JSON.stringify({ ok: false, fail, out }, null, 1)); process.exit(1) }
console.log(JSON.stringify({ ok: true, out }))
