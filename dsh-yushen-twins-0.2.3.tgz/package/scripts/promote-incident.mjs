// 把已结的事故单转成正式修复档案（先取编号，再填正文）。
// 用法：
//   node scripts/promote-incident.mjs inc-xxxx --dry-run   （只看会建什么）
//   node scripts/promote-incident.mjs inc-xxxx --write     （真写）

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { execFileSync } from 'node:child_process'
import { qqBridgeRoot } from '../lib/paths.js'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const QQ = process.env.QQ_BRIDGE || qqBridgeRoot()
const GENERATOR = path.join(QQ, 'scripts', 'new-fix-record.mjs')

const id = process.argv[2]
const write = process.argv.includes('--write')
if (!id) { console.error('用法：node scripts/promote-incident.mjs <事故单号> [--dry-run|--write]'); process.exit(2) }

const rows = (() => { try { return JSON.parse(fs.readFileSync(path.join(DATA, 'incidents.json'), 'utf8')) } catch { return [] } })()
const row = rows.find((r) => r.id === String(id))
if (!row) { console.error(`没有这张事故单：${id}`); process.exit(1) }
if (row.status !== 'fixed' && row.status !== 'closed') { console.error(`这单还是 ${row.status}，先结单再转档`); process.exit(1) }
if (!fs.existsSync(GENERATOR)) { console.error(`找不到编号脚本：${GENERATOR}`); process.exit(1) }

const title = String(row.title || '事故').slice(0, 40)
const args = [GENERATOR, title, '--category', '事故']
if (!write) args.push('--dry-run')
const out = execFileSync(process.execPath, args, { cwd: QQ, encoding: 'utf8' })
console.log(out.trim())
if (!write) { console.log('（dry-run：没建文件；加 --write 才写）'); process.exit(0) }

// 取最新生成的文件：修复档案/<yyyy-MM>/<id>-*.md
const monthDir = path.join(QQ, '修复档案', new Date().toISOString().slice(0, 7))
const files = fs.existsSync(monthDir) ? fs.readdirSync(monthDir).filter((f) => f.endsWith('.md')) : []
const newest = files.sort((a, b) => fs.statSync(path.join(monthDir, b)).mtimeMs - fs.statSync(path.join(monthDir, a)).mtimeMs)[0]
if (!newest) { console.error('没找到刚生成的档案'); process.exit(1) }
const file = path.join(monthDir, newest)
console.log(`档案：${file}`)

let text = fs.readFileSync(file, 'utf8')
const symptom = String(row.text || '').replace(/\n/g, ' ')
const note = String(row.note || '（结单时没写结论）').replace(/\n/g, ' ')
text = text
  .replace(/(## 症状\s*\n)([\s\S]*?)(\n## )/, `$1${symptom}\n$3`)
  .replace(/(## 结论 \/ 怎么修的\s*\n)([\s\S]*?)(\n## )/, `$1${note}\n$3`)
  .replace(/(## 根因\s*\n)([\s\S]*?)(\n## )/, `$1待补：由值班人补根因\n$3`)
if (!/## 验证/.test(text)) text += `\n## 验证\n\n- 事故单：${row.id}（出现 ${row.count || 1} 次，结单 ${row.fixedAt || ''}）\n- 自动转档，验证步骤待补\n`
text = text.replace(/主人/g, '老板')
fs.writeFileSync(file, text, 'utf8')
console.log('已填正文：症状 / 结论 / 根因待补 / 验证待补')
