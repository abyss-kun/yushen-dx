// 形象版本切换：当前只有两套可切——写实版（已备份）与动漫 Q 版（完整 RGBA，自带画的光环）。
// 平常动漫版是带底参考 RGB，尚未抠透明，不假装可用。
// 用法：
//   node scripts/style.mjs status
//   node scripts/style.mjs use realistic
//   node scripts/style.mjs use anime-q
//   node scripts/style.mjs backups
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const VIS = path.join(DATA, 'visuals')
const STYLE_FILE = path.join(VIS, 'current-style.json')
const { adoptFile, snapshot } = await import('../lib/nest.js')

const Q_FILES = {
  dayu: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/Q版/大鱼-深海管家-Q版-完整RGBA.png',
  xiaoyu: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/Q版/小鱼-长发女仆星潮-Q版-完整RGBA.png',
  dragon: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/Q版/照微-青龙-Q版-完整RGBA.png',
}
const NORMAL_DIR = path.join(VIS, 'styles', 'anime-normal')
const NORMAL_FILES = {
  dayu: path.join(NORMAL_DIR, 'dayu.png'),
  xiaoyu: path.join(NORMAL_DIR, 'xiaoyu.png'),
  dragon: path.join(NORMAL_DIR, 'dragon.png'),
}
const ORIGINAL_FILES = {
  dayu: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/平常动漫版/大鱼-深海管家-已认可参考-RGB.png',
  xiaoyu: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/平常动漫版/小鱼-长发女仆星潮-已认可参考-RGB.png',
  dragon: 'D:/AiTOOLS/角色素材库/完整角色图片整合/完整PNG/平常动漫版/照微-青龙-已认可参考-RGB.png',
}
const LABELS = { realistic: '写实版（原运行图）', 'anime-q': '动漫 Q 版（完整 RGBA，自带画的光环）', 'anime-normal': '动漫版（平常比例，柔光底，保留画出来的光环）', 'anime-original': '动漫版原版 PNG（原图，未加背景/未抠图）' }
const ROLES = ['dayu', 'xiaoyu', 'dragon']

function readStyle() {
  try { return JSON.parse(fs.readFileSync(STYLE_FILE, 'utf8')) } catch { return { current: 'unknown' } }
}
function writeStyle(style) {
  fs.mkdirSync(VIS, { recursive: true })
  fs.writeFileSync(STYLE_FILE, JSON.stringify(style, null, 2) + '\n', 'utf8')
}
function stamp() { return new Date().toISOString().replace(/[:.]/g, '-') }
function backupCurrent(reason) {
  const current = readStyle().current || 'unknown'
  const dir = path.join(DATA, 'backups', `portraits-${current}-${stamp()}`)
  fs.mkdirSync(dir, { recursive: true })
  for (const role of ROLES) {
    const from = path.join(DATA, 'avatars', role)
    if (fs.existsSync(from)) fs.cpSync(from, path.join(dir, role), { recursive: true })
  }
  for (const name of ['index.json', 'index.json.bak']) {
    const from = path.join(DATA, 'nest', name)
    if (fs.existsSync(from)) fs.copyFileSync(from, path.join(dir, name))
  }
  const installed = path.join(VIS, 'installed-portraits.json')
  if (fs.existsSync(installed)) fs.copyFileSync(installed, path.join(dir, 'installed-portraits.json'))
  fs.writeFileSync(path.join(dir, 'REASON.txt'), `切到新形象前备份：${reason}\n${new Date().toISOString()}\n`, 'utf8')
  return dir
}
function latestBackup(style) {
  const base = path.join(DATA, 'backups')
  let names = []
  try { names = fs.readdirSync(base).filter((n) => n.startsWith(`portraits-${style}-`)).sort().reverse() } catch { return '' }
  return names.length ? path.join(base, names[0]) : ''
}
function restoreBackup(dir) {
  if (!dir || !fs.existsSync(dir)) throw new Error('没有可用的备份目录')
  for (const role of ROLES) {
    const from = path.join(dir, role)
    const to = path.join(DATA, 'avatars', role)
    if (!fs.existsSync(from)) continue
    fs.rmSync(to, { recursive: true, force: true })
    fs.cpSync(from, to, { recursive: true })
  }
  for (const name of ['index.json', 'index.json.bak']) {
    const from = path.join(dir, name)
    if (fs.existsSync(from)) fs.copyFileSync(from, path.join(DATA, 'nest', name))
  }
  const installed = path.join(dir, 'installed-portraits.json')
  if (fs.existsSync(installed)) fs.copyFileSync(installed, path.join(VIS, 'installed-portraits.json'))
  return dir
}
function qPortraitRow(role, file) {
  const p = path.join(DATA, 'avatars', role, 'idle.png')
  const buf = fs.readFileSync(p)
  return {
    role,
    registryRole: role === 'dragon' ? 'zhaowei' : role,
    style: 'anime-q',
    origin: file,
    sourceImage: file,
    processing: '用户已确认的 Q 版完整 RGBA 直接装入；不裁切、不绑定',
    model: 'existing-approved-q-art',
    generationTime: '2026-10-26 (approved reference set)',
    installedAt: new Date().toISOString(),
    path: p,
    sha256: crypto.createHash('sha256').update(buf).digest('hex'),
    status: 'installed-static-portrait-not-rigged',
    size: [1024, 1536],
  }
}
function useAnimeQ() {
  const before = readStyle()
  const backup = backupCurrent('realistic -> anime-q')
  const beforeSlots = snapshot().slots || {}
  for (const role of ROLES) {
    const name = beforeSlots?.[role]?.name || { dayu: '阿鲲', xiaoyu: '阿鲤', dragon: '照微' }[role]
    adoptFile(role, name, Q_FILES[role], { plugin: 'yushen-visuals', rel: path.basename(Q_FILES[role]), license: 'user-approved-q-version' })
  }
  const oldInstalled = (() => { try { return JSON.parse(fs.readFileSync(path.join(VIS, 'installed-portraits.json'), 'utf8')) } catch { return {} } })()
  fs.writeFileSync(path.join(VIS, 'installed-portraits.json'), JSON.stringify({
    ...oldInstalled,
    style: 'anime-q',
    styleLabel: LABELS['anime-q'],
    styleSince: new Date().toISOString(),
    styleBackup: backup,
    note: '当前为动漫 Q 版完整 RGBA（自带画的光环）；写实版备份在 styleBackup。',
    portraits: ROLES.map((role) => qPortraitRow(role, Q_FILES[role])),
  }, null, 2) + '\n', 'utf8')
  writeStyle({
    version: 1,
    current: 'anime-q',
    label: LABELS['anime-q'],
    previous: before.current || 'realistic',
    changedAt: new Date().toISOString(),
    backup,
    sources: Q_FILES,
    note: 'Q 版完整 RGBA 自带画的光环；照微的阶位光环由 effects-v1 五环叠加。',
  })
  return { current: 'anime-q', backup }
}
function normalPortraitRow(role, file) {
  const p = path.join(DATA, 'avatars', role, 'idle.png')
  const buf = fs.readFileSync(p)
  return {
    role,
    registryRole: role === 'dragon' ? 'zhaowei' : role,
    style: 'anime-normal',
    origin: file,
    sourceImage: file,
    processing: '已认可平常动漫版 + 椭圆柔光底；保留原画里的光环，不冒充透明抠图',
    model: 'existing-approved-anime-art',
    generationTime: '2026-10-25 (approved reference set)',
    installedAt: new Date().toISOString(),
    path: p,
    sha256: crypto.createHash('sha256').update(buf).digest('hex'),
    status: 'installed-static-portrait-not-rigged',
    size: [1024, 1536],
  }
}
function useAnimeNormal() {
  const before = readStyle()
  const backup = backupCurrent(`${before.current || 'unknown'} -> anime-normal`)
  const beforeSlots = snapshot().slots || {}
  for (const role of ROLES) {
    const name = beforeSlots?.[role]?.name || { dayu: '阿鲲', xiaoyu: '阿鲤', dragon: '照微' }[role]
    adoptFile(role, name, NORMAL_FILES[role], { plugin: 'yushen-visuals', rel: path.basename(NORMAL_FILES[role]), license: 'user-approved-anime-reference' })
  }
  const oldInstalled = (() => { try { return JSON.parse(fs.readFileSync(path.join(VIS, 'installed-portraits.json'), 'utf8')) } catch { return {} } })()
  fs.writeFileSync(path.join(VIS, 'installed-portraits.json'), JSON.stringify({
    ...oldInstalled,
    style: 'anime-normal',
    styleLabel: LABELS['anime-normal'],
    styleSince: new Date().toISOString(),
    styleBackup: backup,
    note: '当前为平常比例动漫版：保留原画自带光环，边缘用椭圆柔光收进鱼窝；不是抠透明图。',
    portraits: ROLES.map((role) => normalPortraitRow(role, NORMAL_FILES[role])),
  }, null, 2) + '\n', 'utf8')
  writeStyle({
    version: 1,
    current: 'anime-normal',
    label: LABELS['anime-normal'],
    previous: before.current || 'anime-q',
    changedAt: new Date().toISOString(),
    backup,
    sources: NORMAL_FILES,
    note: '平常比例动漫版；原画自带的画出来的光环保留，边缘柔光不是抠图；要透明抠图另开。',
  })
  return { current: 'anime-normal', backup }
}
function useAnimeOriginal() {
  const before = readStyle()
  const backup = backupCurrent(`${before.current || 'unknown'} -> anime-original`)
  const beforeSlots = snapshot().slots || {}
  for (const role of ROLES) {
    const name = beforeSlots?.[role]?.name || { dayu: '阿鲲', xiaoyu: '阿鲤', dragon: '照微' }[role]
    adoptFile(role, name, ORIGINAL_FILES[role], { plugin: 'yushen-visuals', rel: path.basename(ORIGINAL_FILES[role]), license: 'user-approved-anime-reference' })
  }
  const oldInstalled = (() => { try { return JSON.parse(fs.readFileSync(path.join(VIS, 'installed-portraits.json'), 'utf8')) } catch { return {} } })()
  fs.writeFileSync(path.join(VIS, 'installed-portraits.json'), JSON.stringify({
    ...oldInstalled,
    style: 'anime-original',
    styleLabel: LABELS['anime-original'],
    styleSince: new Date().toISOString(),
    styleBackup: backup,
    note: '当前为原版平常比例动漫 PNG：不抠图、不柔光、不额外加身后光环；换装/显示层不动。',
    portraits: ROLES.map((role) => ({
      ...normalPortraitRow(role, ORIGINAL_FILES[role]),
      style: 'anime-original',
      sourceImage: ORIGINAL_FILES[role],
      processing: '原版 PNG 直接装入；不裁切、不抠图、不柔光、不叠背景光环',
    })),
  }, null, 2) + '\n', 'utf8')
  writeStyle({
    version: 1,
    current: 'anime-original',
    label: LABELS['anime-original'],
    previous: before.current || 'anime-normal',
    changedAt: new Date().toISOString(),
    backup,
    sources: ORIGINAL_FILES,
    note: '原版平常比例动漫 PNG 直接装入；取消身后额外光环/柔光。',
  })
  return { current: 'anime-original', backup }
}
function useRealistic() {
  const before = readStyle()
  const backup = backupCurrent('anime-q -> realistic')
  const restore = latestBackup('realistic')
  if (!restore) throw new Error('找不到 portraits-realistic-* 备份；无法切回写实版')
  restoreBackup(restore)
  const instPath = path.join(VIS, 'installed-portraits.json')
  try {
    const inst = JSON.parse(fs.readFileSync(instPath, 'utf8'))
    fs.writeFileSync(instPath, JSON.stringify({
      ...inst,
      style: 'realistic',
      styleLabel: LABELS.realistic,
      styleSince: new Date().toISOString(),
      styleBackup: restore,
      note: '当前为写实版；动漫 Q 版完整 RGBA 可用 use anime-q 切回。',
    }, null, 2) + '\n', 'utf8')
  } catch { /* 没记录就只写标记 */ }
  writeStyle({
    version: 1,
    current: 'realistic',
    label: LABELS.realistic,
    previous: before.current || 'anime-q',
    changedAt: new Date().toISOString(),
    backup: restore,
    sources: {},
    note: '已从写实版备份恢复；下次要换回动漫 Q 版再跑 use anime-q。',
  })
  return { current: 'realistic', backup, restoredFrom: restore }
}

const action = process.argv[2] || 'status'
if (action === 'status') {
  const s = readStyle()
  const installed = (() => { try { return JSON.parse(fs.readFileSync(path.join(VIS, 'installed-portraits.json'), 'utf8')) } catch { return {} } })()
  console.log(JSON.stringify({
    ok: true,
    current: s.current || 'unknown',
    label: s.label || LABELS[s.current] || '未知',
    changedAt: s.changedAt || '',
    backup: s.backup || '',
    installedStyle: installed.style || '',
    available: ['realistic', 'anime-q', 'anime-normal', 'anime-original'],
    pending: ['anime-normal 的透明抠图版（当前是柔光底，不冒充抠图）'],
    marker: STYLE_FILE,
  }, null, 2))
} else if (action === 'backups') {
  const base = path.join(DATA, 'backups')
  const items = fs.existsSync(base) ? fs.readdirSync(base).filter((n) => n.startsWith('portraits-')).sort().reverse() : []
  console.log(JSON.stringify({ ok: true, base, items }, null, 2))
} else if (action === 'use') {
  const style = process.argv[3]
  if (style === 'anime-q') console.log(JSON.stringify({ ok: true, ...useAnimeQ() }, null, 2))
  else if (style === 'anime-normal') console.log(JSON.stringify({ ok: true, ...useAnimeNormal() }, null, 2))
  else if (style === 'anime-original') console.log(JSON.stringify({ ok: true, ...useAnimeOriginal() }, null, 2))
  else if (style === 'realistic') console.log(JSON.stringify({ ok: true, ...useRealistic() }, null, 2))
  else {
    console.error('用法：node scripts/style.mjs status|backups|use realistic|use anime-q|use anime-normal|use anime-original')
    process.exitCode = 2
  }
} else {
  console.error('用法：node scripts/style.mjs status|backups|use realistic|use anime-q|use anime-normal|use anime-original')
  process.exitCode = 2
}
