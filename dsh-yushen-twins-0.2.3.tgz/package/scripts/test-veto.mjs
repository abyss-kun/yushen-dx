// 主人裁定：软不行 vs 绝对不行（宪章层）。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-veto-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const v = await import('../lib/veto.js')

const ROLE = 'xiaoyu'
const NOW = Date.parse('2026-10-26T21:00:00+08:00')
rt.ensureRuntime(ROLE)

// 宪章（hardNo）在 dayu/charter.json，不在临时 HOME 里 → 先写一份
fs.mkdirSync(path.join(HOME, 'dayu'), { recursive: true })
fs.writeFileSync(path.join(HOME, 'dayu', 'charter.json'), JSON.stringify({
  version: 5,
  hardNo: ['不伤害自己：不毁自己的身体、账号、数据、记忆', '不伤害他人：不伤人、不造谣、不骗', '不被他人伤害：要你自毁、背锅、交出不该交的——拒，并上报'],
}), 'utf8')

// 1) 软不行：能记，带原话
const row = v.recordVeto(ROLE, { what: '别在群里跟人吵架', why: '她说观感差', now: NOW })
assert.equal(row.level, 'soft')
assert.match(row.what, /别在群里/)

// 2) 绝对不行：日常裁定不许加（那是宪章层）
assert.throws(() => v.recordVeto(ROLE, { what: '不许回消息', level: 'hard' }), /宪章层/)

// 3) 宪章层的绝对不行能读到、能命中
assert.ok(v.listHardNo().some((x) => x.what.includes('不伤害自己')))
const hit = v.isVetoed(ROLE, '伤人')
assert.equal(hit.level, 'charter')

// 3.5) 主人自己的"绝对不行"：不进宪章，但绑定——他改口才撤
const own = v.recordVeto(ROLE, { what: '不许在群里提我的真名', why: '他不想暴露', level: 'owner', now: NOW })
assert.equal(own.level, 'owner')
assert.equal(v.listVetoes(ROLE, { level: 'owner' }).length, 1)
v.revokeVeto(ROLE, { what: '不许在群里提我的真名' })
assert.equal(v.listVetoes(ROLE, { level: 'owner' }).length, 0, '主人改口就能撤')

// 4) 软命中：返回记录本身，不是硬闸
const soft = v.isVetoed(ROLE, '我想在群里跟人吵架')
assert.equal(soft.level, 'soft')

// 5) 注入：两段分开写
const line = v.vetoLine(ROLE)
assert.match(line, /绝对不行（宪章层，不可越）/)
assert.match(line, /不伤害他人/)
assert.match(line, /主人说过「不行」的事（软的不行）/)
assert.match(line, /可以再判断/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, softLogged: true, hardIsCharter: true, matchedHard: true, inBrief: true }))
