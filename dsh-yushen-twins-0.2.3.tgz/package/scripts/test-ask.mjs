// 主动求助：记录、去重、回答闭环。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-ask-'))
process.env.DSH_HOME = HOME
const ask = await import('../lib/ask.js')

// 1) 问一条：默认只放工作台，不自动 QQ
const a = ask.askOwner({ role: 'xiaoyu', text: '这块污渍归不归我？', sessionId: 'sess-1' })
assert.equal(a.ok, true)
assert.deepEqual(a.ask.channels, ['workbench'])
assert.equal(ask.listAsks({ status: 'pending' }).length, 1)

// 1b) 她自己选 QQ：通道记下来
const qq = ask.askOwner({ role: 'xiaoyu', text: '另一种问法', channels: ['workbench', 'qq'] })
assert.deepEqual(qq.ask.channels, ['workbench', 'qq'])
ask.withdrawAsk(qq.ask.id, '自己找到答案了')

// 2) 10 分钟内重复问：去重
const b = ask.askOwner({ role: 'xiaoyu', text: '这块污渍归不归我？' })
assert.equal(b.duplicate, true)
assert.equal(ask.listAsks({ status: 'pending' }).length, 1)

// 3) 老板回答：状态变 answered，保留回答
const c = ask.answerAsk(a.ask.id, '归你，擦吧')
assert.equal(c.ok, true)
const answered = ask.listAsks({ status: 'answered' })
assert.equal(answered.length, 1)
assert.equal(answered[0].answer, '归你，擦吧')
assert.equal(ask.listAsks({ status: 'pending' }).length, 0)

// 4) 空问题/空回答拒绝
assert.equal(ask.askOwner({ role: 'xiaoyu', text: '  ' }).ok, false)
assert.equal(ask.answerAsk(a.ask.id, '   ').ok, false)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, ask: true, dedupe: true, answered: true, rejectsEmpty: true }))
