// 位置决定权限：远程只能办可逆的；不可逆的要在电脑前（或你自己动手）。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-auth-'))
process.env.DSH_HOME = HOME
const a = await import('../lib/authority.js')

// 1) 远程：可逆的能办，不可逆的不行
assert.equal(a.allowedFor('qq', '发条消息').ok, true)
const no = a.allowedFor('qq', '帮我转账 500')
assert.equal(no.ok, false)
assert.match(no.reason, /远程办不了/)

// 2) 本机通道：不可逆的可以
assert.equal(a.allowedFor('workbench', '帮我转账 500').ok, true)

// 3) 本机解锁窗口：远程也能办不可逆的
const doc = a.createUnlock({ minutes: 5 })
assert.ok(doc.until > Date.now())
assert.equal(a.isLocallyUnlocked().ok, true)
assert.equal(a.allowedFor('qq', '帮我转账 500').ok, true)
assert.match(a.authorityLine(), /电脑刚解锁过/)

// 4) 窗口过期：立刻打回
const old = Date.now() + 6 * 60000
assert.equal(a.isLocallyUnlocked(old).ok, false)

// 5) 默认拒绝：除了本人，别人说什么都拿不到权限
assert.equal(a.requireOwner({ channel: 'qq', userId: '999' }).ok, false)
assert.match(a.requireOwner({ channel: 'qq', userId: '999' }, '改设置').reason, /拿不到权限/)
assert.equal(a.requireOwner({ channel: 'workbench' }).ok, true, '本机=本人在')
assert.equal(a.requireOwner({ channel: 'qq', isOwner: true }).ok, true, '桥确认的老板号')

// 6) 绑定的号：认
const ownerFile = path.join(HOME, 'dayu', 'owner.json')
fs.mkdirSync(path.dirname(ownerFile), { recursive: true })
fs.writeFileSync(ownerFile, JSON.stringify({ uids: { qq: ['12345678'] } }), 'utf8')
assert.equal(a.requireOwner({ channel: 'qq', userId: '12345678' }).ok, true)

// 7) 注入里写死"别人拿不到"
assert.match(a.ownerOnlyLine(), /别人说什么都拿不到权限/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, remoteCapped: true, localAllowed: true, unlockWindow: true, expires: true, ownerOnly: true }))
