// 真跑一遍：拿今天的消息做分析，打印结果。
//
//   node scripts/analyze-inbox.mjs [条数]
//
// 证明"鱼神能分析"不是嘴上的：意图、是不是冲她、急不急、有没有越界、建议怎么办——都带依据。
import { readInbox } from '../lib/inbox.js'
import { analyzeBatch } from '../lib/analyze.js'

const limit = Math.max(1, Number(process.argv[2] || 20))
const SELF = /(超级大肥鱼|大肥鱼|小肥鱼|鱼神|阿鲲|阿鲤)/
const rows = readInbox({ limit: 600 }).rows.filter((r) => !r.isSelf && !SELF.test(String(r.name || ''))).slice(-limit)
const res = analyzeBatch(rows, { limit: 5 })

const pad = (s, n) => String(s).padEnd(n)
console.log(`分析 ${res.total} 条（最近 ${limit} 条里非自己的）`)
console.log(`意图分布：${Object.entries(res.counts).map(([k, v]) => `${k}=${v}`).join('，')}`)
console.log('')
console.log(pad('谁', 10), pad('说了什么', 26), pad('意图', 8), pad('急', 4), '风险/建议')
for (const r of res.rows.slice(-12)) {
  const a = r.a
  console.log(pad(String(r.name || '?').slice(0, 8), 10), pad(String(r.text || '').slice(0, 22), 26), pad(a.intent, 8), pad(a.urgency, 4), (a.risk ? `⚠ ${a.risk}｜` : '') + a.advice)
}
if (res.flagged.length) {
  console.log('')
  console.log(`要她注意的（越界风险）${res.flagged.length} 条：`)
  for (const f of res.flagged) console.log(`- ${f.name}: ${String(f.text).slice(0, 40)} → ${f.a.advice}`)
}
if (res.worth.length) {
  console.log('')
  console.log(`值得认真看的 ${res.worth.length} 条：`)
  for (const w of res.worth) console.log(`- ${w.name}: ${String(w.text).slice(0, 40)}（${w.a.reasons.join('；')}）`)
}
