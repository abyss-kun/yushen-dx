// 移动端接口回归：配对 → 令牌 → 发消息（幂等）→ 拉回复 → 撤销。
// 只测路由与鉴权，不依赖 DSH 宿主（prompt/digest/ensure 都是桩）。
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-mobile-routes-'))
process.env.DSH_HOME = home

const { createMobileGateway } = await import('../lib/mobile-gateway.js?test=' + Date.now())
const { createMobileRoutes } = await import('../lib/mobile-routes.js?test=' + Date.now())

const sent = []
const gateway = createMobileGateway()
const routes = createMobileRoutes({
  gateway,
  isAllowed: () => true,
  readBody: async (req) => req.body || {},
  version: '9.9.9',
  prompt: async (args) => { sent.push(args) },
  digest: () => ({
    ok: true,
    turns: [
      { role: 'user', text: '在吗', at: '2026-10-25T00:00:01.000Z' },
      { role: 'assistant', text: '在。', at: '2026-10-25T00:00:02.000Z' },
      { role: 'assistant', text: '刚忙完。', at: '2026-10-25T00:00:03.000Z' },
    ],
  }),
  ensure: async () => 'session-test-1',
})

function req(method, url, { token = '', body = null, ip = '127.0.0.1' } = {}) {
  const headers = {}
  if (token) headers['x-mobile-token'] = token
  return { method, url, headers, body, socket: { remoteAddress: ip } }
}
async function call(request) {
  let status = 0
  let payload = ''
  const res = { writeHead(code) { status = code }, end(text) { payload = text } }
  await routes.handler(request, res)
  return { status, json: payload ? JSON.parse(payload) : null }
}

let r = await call(req('GET', '/api/yushen/mobile/status'))
assert.equal(r.status, 200)
assert.equal(r.json.paired, false)
assert.equal(r.json.version, '9.9.9')

r = await call(req('GET', '/api/yushen/mobile/pair-code'))
assert.equal(r.status, 200)
const code = r.json.code
assert.match(code, /^\d{6}$/)

r = await call(req('POST', '/api/yushen/mobile/pair', { body: { code, name: '测试机' } }))
assert.equal(r.status, 200)
const token = r.json.token
assert.ok(token && token.length > 20)

r = await call(req('POST', '/api/yushen/mobile/pair', { body: { code, name: '别的机' } }))
assert.equal(r.status, 400)

r = await call(req('GET', '/api/yushen/mobile/status', { token }))
assert.equal(r.status, 200)
assert.equal(r.json.paired, true)
assert.equal(r.json.device.name, '测试机')

r = await call(req('POST', '/api/yushen/mobile/messages', { token, body: { messageId: 'm-1', role: 'xiaoyu', text: '在吗' } }))
assert.equal(r.status, 200)
assert.equal(sent.length, 1)
assert.equal(sent[0].role, 'xiaoyu')
assert.equal(sent[0].sessionId, 'session-test-1')

r = await call(req('POST', '/api/yushen/mobile/messages', { token, body: { messageId: 'm-1', role: 'xiaoyu', text: '在吗' } }))
assert.equal(r.status, 200)
assert.equal(r.json.duplicate, true)
assert.equal(sent.length, 1)

r = await call(req('GET', '/api/yushen/mobile/messages?after=2026-10-25T00:00:02.000Z', { token }))
assert.equal(r.status, 200)
assert.equal(r.json.messages.length, 1)
assert.equal(r.json.messages[0].text, '刚忙完。')
assert.equal(r.json.next, '2026-10-25T00:00:03.000Z')

r = await call(req('GET', '/api/yushen/mobile/history?limit=10', { token }))
assert.equal(r.status, 200)
assert.equal(r.json.messages.length, 3)

r = await call(req('POST', '/api/yushen/mobile/devices/revoke', { body: { deviceId: gateway.listDevices()[0].id } }))
assert.equal(r.status, 200)
assert.equal(r.json.revoked, true)

r = await call(req('POST', '/api/yushen/mobile/messages', { token, body: { messageId: 'm-2', text: '还在吗' } }))
assert.equal(r.status, 401)

// 配对码：回环永远可以；非回环必须过工作台鉴权
const strict = createMobileRoutes({
  gateway,
  isAllowed: () => false,
  readBody: async (req) => req.body || {},
  version: '9.9.9',
  prompt: async () => {},
  digest: () => ({ ok: true, turns: [] }),
  ensure: async () => 'session-test-1',
})
async function callStrict(request) {
  let status = 0
  const res = { writeHead(c) { status = c }, end() {} }
  await strict.handler(request, res)
  return status
}
assert.equal(await callStrict(req('GET', '/api/yushen/mobile/pair-code', { ip: '192.168.1.50' })), 401)
assert.equal(await callStrict(req('GET', '/api/yushen/mobile/pair-code')), 200)

console.log('移动端接口：探测、配对一次性、令牌鉴权、消息幂等、游标拉取、历史、撤销、配对码仅限本机 全部通过')
