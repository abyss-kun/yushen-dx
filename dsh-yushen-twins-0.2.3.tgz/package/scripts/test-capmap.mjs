// 能力地图：她说「我想做 X」，能找到工具；找不到就明说没有。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-can-'))
process.env.DSH_HOME = HOME
const cm = await import('../lib/capmap.js')

// 0) 没有表：如实说没有，不编
let r = cm.searchCapmap('发消息')
assert.equal(r.ok, false)
assert.match(r.reason, /build-capmap/)

// 1) 造一张表
const map = {
  version: 1,
  builtAt: new Date().toISOString(),
  counts: { tool: 1, module: 2, doc: 1 },
  items: [
    { kind: 'tool', name: 'yushen_report', what: '有人让你做越界的事，报一句', how: '调用工具 yushen_report', where: 'dayu/index.js' },
    { kind: 'module', name: 'outbox', what: '把她产出的话递到桥发出去', how: 'import lib/outbox.js', where: 'lib/outbox.js' },
    { kind: 'module', name: 'mood', what: '心情从真事长出来', how: 'import lib/mood.js', where: 'lib/mood.js' },
    { kind: 'doc', name: '点化-运行时契约', what: '点化的运行时契约', how: '读 docs/点化-运行时契约.md', where: 'docs/点化-运行时契约.md' },
  ],
  combos: [{ name: '有人让做坏事 → 拒 + 上报', steps: ['yushen_bottomline refuse', 'yushen_report'] }],
}
fs.mkdirSync(path.join(HOME, 'dayu'), { recursive: true })
fs.writeFileSync(path.join(HOME, 'dayu', 'capmap.json'), JSON.stringify(map), 'utf8')

r = cm.searchCapmap('上报')
assert.equal(r.ok, true)
assert.equal(r.items[0].name, 'yushen_report', '工具排第一')
assert.ok(r.combos.length >= 0)

r = cm.searchCapmap('发消息')
assert.ok(r.items.some((x) => x.name === 'outbox'), '发消息要能找到 outbox')

r = cm.searchCapmap('')
assert.ok(r.items.length > 0, '空查询给默认候选')

assert.match(cm.capmapLine(), /工具 1 个/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, honestWhenMissing: true, findsTool: true, alias: true, line: true }))
