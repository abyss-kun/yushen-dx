#!/usr/bin/env node
// 修复联动的手动入口：跑一次"助手诊断 → 缺口台账对账 → 生成能力请求"。
// 插件启动时也会自动跑这一圈（见 index.js 的 repair-loop 挂载），这个脚本用于当场验证。
//
// 用法：
//   node scripts/repair-loop.mjs            # 人看的摘要
//   node scripts/repair-loop.mjs --json     # 机器读的 JSON
//
// 只读诊断 + 只追加台账；不改任何业务文件。

import { runRepairLoop } from '../lib/repair-loop.js';

const asJson = process.argv.includes('--json');
const result = await runRepairLoop({});

if (asJson) {
  console.log(JSON.stringify(result, null, 2));
} else {
  console.log('修复联动对账（只读诊断 + 台账追加）');
  console.log(`助手诊断：${result.diagnosed ? '成功' : '不可用（助手缺失或超时）'}  分类=${result.classification ?? '—'}`);
  console.log(`台账里原本 open：${result.openBefore} 项`);
  console.log(`这次标记 resolved：${result.resolvedNow.length ? result.resolvedNow.join('、') : '无'}`);
  console.log(`仍然修不了：${result.stillOpen.length ? result.stillOpen.join('、') : '无'}`);
  console.log(`新增能力请求：${result.capabilitiesRequested.length ? result.capabilitiesRequested.join('、') : '无（同一缺口今天已记过）'}`);
  console.log(`缺口台账：${result.gapsFile}`);
  console.log(`能力请求：${result.requestsFile}`);
}
