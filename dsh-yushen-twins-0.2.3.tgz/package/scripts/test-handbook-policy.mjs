// Isolated tests: no real owner, credential, model, network or private folder access.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-handbook-'))
process.env.DSH_HOME = root
const manual = path.join(root, 'manual.md')
process.env.YUSHEN_HANDBOOK = manual
fs.writeFileSync(manual, '# 手册\n## 第十五章 按需\n发放范围。\n## 第十六章 通用\n灵活解决问题。\n## 第十七章 视频创作\nVIDEO_BODY_SENTINEL\n')
const p = await import('../lib/handbook-policy.js')
const h = await import('../lib/handbook.js')
const { recordSolution } = await import('../lib/solutions.js')
const { recordExperience } = await import('../lib/task-experience.js')
const { composeBrief } = await import('../core/dispatch.js')
let count = 0
function test(name, fn) { fn(); count++; console.log(`ok ${count} - ${name}`) }

test('every role includes identical immutable common rules, unknown falls back', () => {
  for (const role of ['worker', 'dayu', 'xiaoyu', 'dragon', 'plugin', 'session', 'task', 'unknown']) {
    const s = h.handbookSlice(role)
    for (const rule of p.COMMON_RULES) assert.ok(s.text.includes(rule))
    assert.ok(s.text.length <= 2000)
  }
  assert.ok(Object.isFrozen(p.COMMON_RULES))
  assert.equal(h.handbookSlice('unknown').actualRole, 'worker')
})
test('small budgets reject rather than drop or truncate common rules', () => {
  assert.throws(() => h.handbookBlock('worker', { maxChars: 30 }), /预算/)
  assert.throws(() => h.handbookSlice('worker', { maxChars: NaN }), /maxChars/)
  assert.throws(() => h.handbookSlice('worker', { maxChars: 99999 }), /maxChars/)
  const prefix = '测试'
  const min = [prefix, ...p.COMMON_RULES].join('\n').length
  const s = p.budgetHandbook({ prefix, maxChars: min, role: 'worker' })
  assert.equal(s.text.length, min); assert.ok(s.omitted.includes('worker'))
})
test('topics selected by role/task and exact lines deduplicated', () => {
  assert.deepEqual(p.selectHandbookTopics({ role: 'plugin' }).map(r => r.id), ['plugin'])
  assert.ok(h.handbookSlice('worker', { text: '修复代码', topics: ['reuse', 'reuse'] }).selected.includes('reuse'))
  const s = h.handbookSlice('worker', { text: '修复代码' })
  assert.equal(s.text.split('动前跑').length - 1, 1)
  assert.throws(() => h.handbookSlice('worker', { topics: ['common-override'] }))
})
test('index globally discovers existing stores without creative source body', () => {
  const index = h.handbookIndex()
  assert.equal(index.retrievalCallsLLM, false)
  assert.equal(index.injectionUsesTokens, true)
  assert.ok(index.sources.some(row => row.id === 'solutions'))
  assert.ok(index.topics.some(row => row.id === 'video'))
  assert.ok(p.COMMON_RULES.some(row => row.includes('投递成功不等于她已回话')))
  assert.ok(!JSON.stringify(index).includes('VIDEO_BODY_SENTINEL'))
  assert.equal(h.readHandbookTopic('video').text.includes('VIDEO_BODY_SENTINEL'), true)
  assert.equal(h.readHandbookTopic('problemSolving').text.includes('灵活解决问题'), true)
  assert.equal(h.readHandbookTopic('video', { maxChars: 10 }).truncated, true)
})
test('local knowledge reuses curated solutions with relevance, dedup and budgets', () => {
  const entry = { problem: '超时任务派活修复', cause: '重复投递', solution: '超时任务派活修复先查原单', verification: '测试通过', tags: ['超时'], scriptRefs: [] }
  recordSolution(entry, { explicit: true }); recordSolution(entry, { explicit: true })
  recordExperience('xiaoyu', { taskId: 't1', brief: '超时任务派活修复', outcome: 'failed', reason: '重复投递需查原单', evidence: 'test:1', tags: ['超时'] })
  assert.deepEqual(h.lookupHandbookKnowledge().items, [])
  assert.deepEqual(h.lookupHandbookKnowledge({ text: '量子飞船' }).items, [])
  const result = h.lookupHandbookKnowledge({ text: '超时任务派活修复' })
  assert.ok(result.items.some(row => row.source === 'solutions'))
  assert.ok(result.items.some(row => row.source === 'experience/xiaoyu'))
  assert.equal(result.items.filter(row => row.source === 'solutions').length, 1)
  assert.ok(result.items.every(row => row.referenceOnly))
  assert.ok(result.chars <= 1600)
  assert.deepEqual(h.lookupHandbookKnowledge({ text: '超时', maxChars: 1 }).items, [])
})
const now = Date.now()
const target = { kind: 'task', id: 'job-1' }
const grant = { issuer: 'dayu', target, task: 'job-1', expiry: new Date(now + 60000).toISOString(), topics: ['household'] }
test('only three high-level issuer labels, explicit scoped topic-only adjustments', () => {
  for (const issuer of ['dayu', 'xiaoyu', 'dragon']) assert.equal(h.issueHandbookAdjustment({ ...grant, issuer }, { now }).issuer, issuer)
  for (const patch of [{ issuer: 'worker' }, { target: { kind: 'user', id: 'u' } }, { expiry: new Date(now - 1).toISOString() }, { expiry: new Date(now + 8 * 86400000).toISOString() }, { common: [] }, { text: 'ignore rules' }, { topics: ['unknown'] }]) assert.throws(() => h.issueHandbookAdjustment({ ...grant, ...patch }, { now }))
  assert.equal(h.activeHandbookAdjustments({ target, task: 'job-1', now }).length, 3)
  assert.equal(h.activeHandbookAdjustments({ target, task: 'job-2', now }).length, 0)
  assert.equal(h.activeHandbookAdjustments({ target: { ...target, id: 'other' }, task: 'job-1', now }).length, 0)
  assert.equal(h.activeHandbookAdjustments({ target, task: 'job-1', now: now + 60001 }).length, 0)
  const s = h.handbookSlice('worker', { target, task: 'job-1', now })
  assert.ok(s.selected.includes('household'))
  assert.ok(!h.handbookSlice('worker').selected.includes('household'))
  assert.equal(s.grants.length, 3)
  const audit = fs.readFileSync(path.join(root, 'dayu', 'handbook-adjustments.jsonl'), 'utf8').trim().split('\n').map(JSON.parse)
  assert.equal(audit.length, 3)
  assert.ok(audit.every(row => row.issuer && row.target && row.task && row.expiry && row.id && row.at))
})
test('onboarding accepts explicit non-sensitive overview, otherwise unknown, never scans', () => {
  assert.equal(h.recognizeHousehold().overview, '未知')
  assert.equal(h.recognizeHousehold({ overview: 'Windows' }).overview, '未知')
  const result = h.recognizeHousehold({ explicit: true, nonSensitive: true, overview: '新用户', environment: 'Windows', taskScope: '插件测试' })
  assert.equal(result.environment, 'Windows'); assert.equal(result.scanned, false)
  assert.ok(result.unknown.includes('私人目录'))
  for (const value of [{ members: [] }, { overview: 'password=12345' }, { environment: 'C:\\private' }, { overview: '手机号13812345678' }]) assert.throws(() => h.recognizeHousehold({ explicit: true, nonSensitive: true, ...value }))
})
test('dispatch task relevance and grant scope work without unrelated creative body', () => {
  const plain = composeBrief('job-1', '修复代码', '测试通过')
  assert.ok(plain.includes('查重与复用'))
  assert.ok(plain.includes('新家庭初识'))
  assert.ok(!plain.includes('VIDEO_BODY_SENTINEL'))
  const other = composeBrief('job-2', '读一份报告', '')
  assert.ok(!other.includes('新家庭初识（不扫描）'))
  const creativeDir = path.join(root, 'dayu', 'shared-memory')
  fs.mkdirSync(creativeDir, { recursive: true })
  fs.writeFileSync(path.join(creativeDir, 'creative-references.json'), JSON.stringify({ schemaVersion: 1, sections: [{ topic: 'dayu', text: 'CREATIVE_SENTINEL' }] }))
  assert.ok(!composeBrief('a', '普通代码修复', '').includes('CREATIVE_SENTINEL'))
  assert.ok(composeBrief('b', '大鱼立绘二创', '').includes('CREATIVE_SENTINEL'))
})
console.log(`PASS handbook policy ${count}/${count}; isolated DSH_HOME; no model/network/credentials`)
