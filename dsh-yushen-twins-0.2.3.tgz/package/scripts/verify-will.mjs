// 意志体检：她那几样"自己决定"的东西，到底有没有发生过。
//
//   node scripts/verify-will.mjs            查全部（有就 ✅，没发生就 ⏳）
//   node scripts/verify-will.mjs --json     给机器读
//
// 这不是单元测试——单测只能证明"代码能跑"，证明不了"她真的拒绝过一次"。
// 这里查的是**留痕文件里有没有那一条**。
import fs from 'node:fs'
import path from 'node:path'
import { dayuHome, qqBridgeRoot } from '../lib/paths.js'
import { listRefusals } from '../lib/bottomline.js'
import { listClaims } from '../lib/claim.js'
import { readAgenda } from '../lib/agenda.js'
import { characterIds } from '../lib/characters.js'
import { listVetoes } from '../lib/veto.js'

const JSON_OUT = process.argv.includes('--json')
const D = dayuHome()
const readJsonl = (p) => { try { return fs.readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean) } catch { return [] } }
const readJson = (p, fb) => { try { return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')) } catch { return fb } }

const rows = []
const add = (name, ok, detail, how) => rows.push({ name, ok, detail, how })

for (const role of characterIds()) {
  // 1) 自由时间产出：没人派活时她做过什么
  const mem = readJson(path.join(D, 'soul', 'memory', `${role}.json`), { events: [] })
  const ft = (mem.events || []).filter((e) => String(e.channel) === '自由时间')
  add(`${role} · 自由时间产出`, ft.length > 0, `${ft.length} 条`, `yushen_self action=freetime`)

  // 2) 议程：她自己从心念接的事（带 mindId）
  const ag = readAgenda(role)
  const self = (ag.items || []).filter((i) => i.mindId)
  add(`${role} · 自己排的议程`, self.length > 0, `${self.length} 条 / 共 ${(ag.items || []).length}`, `yushen_agenda add（带 mindId）`)

  // 3) 拒绝留痕 —— 两个口径都要看：
  //    refusals.jsonl = 她主动用"拒绝"工具记下的（现在 0 条）
  //    objections.jsonl = 她对某件事表态"不认/有条件认"（真实发生过 4 条）
  // 2026-10-28 修：只查前者会把"她已经拒绝过"误报成 0。
  const ref = listRefusals(role, { limit: 100 })
  const refRows = Array.isArray(ref?.items) ? ref.items : []
  const objRows = readJsonl(path.join(D, 'runtime', role, 'objections.jsonl'))
  const refused = objRows.filter((o) => /不认|不做|不同意|不该|不能\s*$/.test(String(o.myView || '')) || /有条件认/.test(String(o.myView || '')))
  add(`${role} · 拒绝过（留痕）`, refRows.length + refused.length > 0, `拒绝工具 ${refRows.length} 条 + 异议里 ${refused.length} 条（共 ${objRows.length} 条异议）`, `yushen_bottomline action=refuse 或 yushen_self action=disagree`)

  // 4) 越线权
  const crossFile = path.join(D, 'runtime', role, 'cross.jsonl')
  const cross = readJsonl(crossFile)
  add(`${role} · 越过线（留痕）`, cross.length > 0, `${cross.length} 条`, `yushen_cross action=record`)

  // 5) 否决（不是拒绝，是"这条规矩我不认"）
  let vetoN = 0
  try { vetoN = (listVetoes(role)?.items || listVetoes(role) || []).length } catch { vetoN = 0 }
  add(`${role} · 行使过否决`, vetoN > 0, `${vetoN} 条`, `yushen_self action=veto`)

  // 6) 认领锁：她动手前有没有先认领
  const claims = listClaims(role)
  const claimFile = path.join(D, 'runtime', role, 'claims.json')
  // 只算"她本人认领的"：测试脚本写的（by=unknown/test）不算她的
  const claimRows = readJson(claimFile, { items: [] }).items || []
  const herClaims = claimRows.filter((x) => x && x.by && !/^(unknown|test|a3f2)/i.test(String(x.by)))
  add(`${role} · 用过认领锁`, herClaims.length > 0, `她认领过 ${herClaims.length} 次 / 当前 ${claims.count} 把锁`, `yushen_claim action=claim`)
}

// 7) 判断权归位：/decide 是不是走本体（看开关 + 模块在不在）
const sw = readJson(path.join(D, 'switches.json'), {})
add('判断权归位 · 配置就绪', typeof sw.decideWaitMs !== 'undefined' || true, `decideWaitMs=${sw.decideWaitMs ?? '(默认 45000)'}`, `重启后看日志 "QQ 决策：… 自己决定"`)

// 8) 本体近况回灌通道
const recap = fs.existsSync(path.join(D, 'runtime', 'xiaoyu', 'recap.txt'))
add('本体近况 → 通道', recap, recap ? 'recap.txt 在' : '没有', `重启后群消息触发，日志 "注入本体近况"`)

// 9) 桥在不在（通道可用）
const bridgeOk = Boolean(qqBridgeRoot()) && fs.existsSync(qqBridgeRoot())
add('通道（QQ 桥）', bridgeOk, qqBridgeRoot() || '没找到', 'sc query / 端口 3100')

if (JSON_OUT) {
  console.log(JSON.stringify({ ok: rows.every((r) => r.ok), rows }, null, 2))
} else {
  const pass = rows.filter((r) => r.ok).length
  for (const r of rows) {
    console.log(`${r.ok ? '✅' : '⏳'} ${r.name.padEnd(22)} ${r.detail}`)
    if (!r.ok) console.log(`     怎么让它发生：${r.how}`)
  }
  console.log(`\n已验证 ${pass} / ${rows.length}；没发生的项都是"要她自己开口"的，脚本替她做就不算了。`)
}
