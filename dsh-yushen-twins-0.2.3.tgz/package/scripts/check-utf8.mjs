// 编码体检：源码里不许出现非法 UTF-8、替换符、或 GBK 二次编码的乱码。
// 背景：2026-10-30 早，client.js 被按 GBK 读进来又用 UTF-8 写回去，
// 中文整段变成乱码、引号也被搞断，语法直接报错，界面起不来。
// 用法：node scripts/check-utf8.mjs
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const EXT = new Set(['.js', '.mjs', '.cjs', '.json', '.md', '.yml', '.yaml', '.html', '.css'])
const SKIP = new Set(['node_modules', '.git', '.state', 'dist', 'backups', 'archive', 'release', '__pycache__', 'tmp', 'out'])
// 两个自己就带这些字面量的文件：encoding.js 拿替换符当哨兵，这个脚本是检测器本身
const ALLOW = new Set(['lib/encoding.js', 'scripts/check-utf8.mjs'])

// GBK 乱码的典型碎片（用码点拼，避免检测器自己被自己命中）
const MOJIBAKE = [
  new RegExp('\\u9365\\u80a9'), // 楸肩
  new RegExp('\\u9359\\u4e0a'), // 鍙上
  new RegExp('\\u9f98'), // 龘
  new RegExp('\\u951f\\u65a4\\u62f7'), // 锟斤拷
]

function walk(dir, out = []) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name.startsWith('.')) continue
    if (SKIP.has(ent.name)) continue
    const p = path.join(dir, ent.name)
    if (ent.isDirectory()) walk(p, out)
    else if (EXT.has(path.extname(ent.name).toLowerCase())) out.push(p)
  }
  return out
}

const decoder = new TextDecoder('utf-8', { fatal: true })
const bad = []
for (const file of walk(ROOT)) {
  const rel = path.relative(ROOT, file).split(path.sep).join('/')
  if (ALLOW.has(rel)) continue
  const buf = fs.readFileSync(file)
  let text
  try {
    text = decoder.decode(buf)
  } catch {
    bad.push([file, '不是合法 UTF-8'])
    continue
  }
  if (text.includes('\uFFFD')) bad.push([file, '含替换符 U+FFFD（原来有字节被写坏了）'])
  for (const re of MOJIBAKE) {
    if (re.test(text)) { bad.push([file, '像 GBK 二次编码的乱码']); break }
  }
}

if (bad.length) {
  console.error(`编码体检：${bad.length} 个文件有问题`)
  for (const [f, why] of bad) console.error(`  ${path.relative(ROOT, f)} — ${why}`)
  process.exit(1)
}
console.log('编码体检：干净')
