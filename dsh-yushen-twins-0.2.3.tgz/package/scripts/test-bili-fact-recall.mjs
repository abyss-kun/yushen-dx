import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'bili-recall-'))
const { recallBiliFacts } = await import('../lib/bili-fact-recall.js')
const root = path.join(process.env.DSH_HOME, 'dayu', 'conversations', 'xiaoyu', 'bili')
fs.mkdirSync(root, { recursive: true })
const crypto = await import('node:crypto')
const writeFact = (conversationId, row) => {
  const file = path.join(root, `${crypto.createHash('sha256').update(conversationId).digest('hex')}.jsonl`)
  fs.writeFileSync(file, JSON.stringify(row) + '\n', { flag: 'a' })
}
writeFact('comment:BV1:9', { direction: 'incoming', messageId: 'comment:BV1:9', text: '真实评论事实', speaker: 'UP', at: new Date().toISOString(), mediaRefs: ['https://img.test/a.jpg'], source: 'bili-comment', semantics: 'raw-fact' })
writeFact('private:BV1', { direction: 'incoming', messageId: 'private:BV1', text: '私信事实', speaker: '私信人', at: new Date().toISOString(), mediaRefs: [], source: 'bili-private', semantics: 'raw-fact' })
const comment = recallBiliFacts({ channel: 'bili', role: 'xiaoyu', conversationId: 'comment:BV1:9', audience: 'group' })
assert.equal(comment.length, 1)
assert.equal(comment[0].quote, '真实评论事实')
assert.equal(comment[0].mediaRefs[0], 'https://img.test/a.jpg')
assert.deepEqual(recallBiliFacts({ channel: 'bili', role: 'xiaoyu', conversationId: 'private:BV1', audience: 'private' })[0].quote, '私信事实')
assert.deepEqual(recallBiliFacts({ channel: 'bili', role: 'xiaoyu', conversationId: 'comment:BV1:10', audience: 'group' }), [])
assert.deepEqual(recallBiliFacts({ channel: 'bili', role: 'xiaoyu', conversationId: 'comment:BV1:9', audience: 'private' })[0].audience, 'private')
assert.throws(() => recallBiliFacts({ channel: 'qq', role: 'xiaoyu', conversationId: 'comment:BV1:9', audience: 'group' }))
console.log('bili raw fact recall: source granularity, media provenance and audience isolation passed')
