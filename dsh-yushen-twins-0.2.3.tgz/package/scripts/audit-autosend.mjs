// 代答扫描：有没有"不经她决定就替她发消息"的路。
//
//   node scripts/audit-autosend.mjs
//
// 扫三类：
//   1) 桥里 sendToQQ(...) 的第二个参数是库里捞出来的句子（reply / hit.reply / pickReply）
//   2) 话术库/学习库命中后 12 行内出现 sendToQQ
//   3) 鱼神侧 outbox 调用缺 decisionId
// 0 条才算干净；有就 exit 2。
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { qqBridgeSrc } from '../lib/paths.js'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const BRIDGE = process.env.QQ_BRIDGE_SRC || qqBridgeSrc()

const targets = []
for (const d of [path.join(BRIDGE), path.join(ROOT, 'lib'), path.join(ROOT, 'dayu')]) {
  if (!fs.existsSync(d)) continue
  for (const f of fs.readdirSync(d)) if (f.endsWith('.js')) targets.push(path.join(d, f))
}

const findings = []
for (const file of targets) {
  let text = ''
  try { text = fs.readFileSync(file, 'utf8') } catch { continue }
  const lines = text.split(/\r?\n/)

  lines.forEach((line, i) => {
    const at = i + 1
    // 1) 直接拿库里的句子发（她的决定 dec.reply 例外——那是她说的）
    const isDecisionReply = /\bdec\.reply\b/.test(line)
    if (!isDecisionReply && /sendToQQ\([^)]*\b(reply|hit\.reply|pickReply|phraseReply)\b/.test(line)) {
      findings.push({ file, at, why: '把库里的句子直接发出去', code: line.trim().slice(0, 110) })
    }
    // 2) 命中后很近的地方发消息
    if (/(pickReply|tryPhraseReply|findMatch)\(/.test(line)) {
      const window = lines.slice(i, i + 12)
      const sendAt = window.findIndex((l) => /sendToQQ\(|send_group_msg|send_private_msg/.test(l))
      if (sendAt >= 0) findings.push({ file, at: i + sendAt + 1, why: '库命中后直接发送', code: window[sendAt].trim().slice(0, 110) })
    }
    // 3) outbox 没有决定 id
    if (/sendAs\(|shareImage\(/.test(line) && !/decisionId/.test(line)) {
      const window = lines.slice(i, i + 6).join(' ')
      if (!/decisionId/.test(window)) findings.push({ file, at, why: '递话没带决定 id', code: line.trim().slice(0, 110) })
    }
  })
}

const uniq = []
const seen = new Set()
for (const f of findings) {
  const k = `${f.file}:${f.at}`
  if (seen.has(k)) continue
  seen.add(k)
  uniq.push(f)
}

if (!uniq.length) {
  console.log(JSON.stringify({ ok: true, scanned: targets.length, findings: 0, note: '没有代答路径：所有发出去的话都要经过她的决定' }, null, 2))
  process.exit(0)
}
console.log(JSON.stringify({ ok: false, scanned: targets.length, findings: uniq.length, items: uniq.map((f) => ({ where: `${f.file.replace(ROOT, '').replace(BRIDGE, '桥')}:${f.at}`, why: f.why, code: f.code })) }, null, 2))
process.exit(2)
