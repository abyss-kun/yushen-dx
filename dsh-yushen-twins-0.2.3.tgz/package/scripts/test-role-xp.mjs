// 头顶经验条的算式自测：只验证“真实计数怎么变成 XP”，不生成假经验。
// 与 client.js 的 Nest 轮询同一套：基础（按当前阶位）+ 已结事故×10（共同值守）+ 自己做完×25。
// 2026-10-30 老板定：**只算自己想做、自己排、自己做完的议程条目（by=self + state=done）；他派的活不算。**
const BASE = { dayu: 600, xiaoyu: 300, dragon: 1000 }
const RANK_BASE = { L0: 0, L1: 100, L2: 300, L3: 600 }
const CAP = 2000
function xpFor(role, fixed, done = 0, rank = '') {
  const base = role === 'dragon' ? BASE.dragon : (RANK_BASE[rank] ?? BASE[role])
  return base + Number(fixed) * 10 + Number(done) * 25
}
const rows = [
  ['dayu', xpFor('dayu', 44, 0, 'L3'), 1040],
  ['xiaoyu', xpFor('xiaoyu', 44, 0, 'L2'), 740],
  ['dragon', xpFor('dragon', 44, 0), 1440],
]
for (const [role, got, want] of rows) {
  if (got !== want) throw new Error(`${role} XP ${got} != ${want}`)
}
// 多结一张事故单：三个人都真的 +10
for (const [role, got] of rows) {
  const after = xpFor(role, 45, 0, role === 'dayu' ? 'L3' : role === 'xiaoyu' ? 'L2' : '')
  if (after !== got + 10) throw new Error(`${role} 事故经验没涨`)
}
// 只给大鱼多一件自己做完的：只有她 +25，另外两个不动（老板派的活不进这个数）
const dayuDone = xpFor('dayu', 44, 1, 'L3')
const xiaoyuSame = xpFor('xiaoyu', 44, 0, 'L2')
if (dayuDone !== 1065) throw new Error(`dayu done XP ${dayuDone}`)
if (xiaoyuSame !== 740) throw new Error(`xiaoyu 被大鱼的单带动：${xiaoyuSame}`)
if (xpFor('dragon', 44, 0) !== 1440) throw new Error('dragon 被单只经验带动')
// 上限只影响条，不影响数字
if (Math.min(1, dayuDone / CAP) > 1) throw new Error('进度必须 <= 1')
console.log(JSON.stringify({
  ok: true,
  current: rows.map(([role, xp]) => ({ role, xp, cap: CAP, progress: Math.min(1, xp / CAP) })),
  incidentGrowth: '+10 / 张已结事故（三人共同值守）',
  jobGrowth: '+25 / 自己做完的议程条目（by=self + done，只加给该角色；老板派的活不算）',
  note: '数字来自真实计数；没有随机、没有动画假涨。',
}, null, 2))
