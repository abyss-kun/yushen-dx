// 社交分寸：同类消息进来，提醒她"上次这类被纠正过"；只提醒，不替她判。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-manners-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const co = await import('../lib/corrections.js')
const ma = await import('../lib/manners.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-27T21:00:00+08:00')
rt.ensureRuntime(ROLE)

// 0) 没纠正记录：不提醒
assert.equal(ma.similarCorrection(ROLE, '收到您的消息'), null)

// 1) 记一次纠正：别用客服腔
co.noteCorrection(ROLE, { what: '回消息太像客服', was: '收到您的消息，我马上处理', should: '直接说事', now: NOW })

const hit = ma.similarCorrection(ROLE, '收到您的消息，这就处理')
assert.ok(hit, '相似的应该认出来')
assert.match(hit.correction.what, /客服/)

// 2) 完全不相关：不硬凑
assert.equal(ma.similarCorrection(ROLE, '今天天气不错'), null)

// 3) tick 记提醒，简报里出现；过 30 分钟自动消失
const n = ma.noteManners(ROLE, [{ id: 'm1', text: '收到您的消息，我看看', isSelf: false }], { now: NOW })
assert.equal(n, 1)
assert.match(ma.mannersLine(ROLE, { now: NOW }), /像你上次被纠正过的那类/)
assert.equal(ma.mannersLine(ROLE, { now: NOW + 31 * 60000 }), '')

// 4) 自己的话不提醒
assert.equal(ma.noteManners(ROLE, [{ id: 'm2', text: '收到您的消息', isSelf: true }], { now: NOW }), 0)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, detects: true, noStretch: true, ttl: true, ignoresSelf: true }))
