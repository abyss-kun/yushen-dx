// 她的判断（影子期）：每条新消息按她自己的权重评一次，留痕、不拦。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-judge-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const judge = await import('../lib/judgment.js')

const NOW = Date.parse('2026-10-26T04:00:00+08:00')
const ROLE = 'dayu'
const day = '2026-10-26'

function writeInbox(rows) {
  const file = path.join(HOME, 'dayu', 'inbox', 'qq', `${day}.jsonl`)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, rows.map((r) => `${JSON.stringify(r)}\n`).join(''), 'utf8')
}

rt.ensureRuntime(ROLE)
writeInbox([
  { id: 'g#1', at: new Date(NOW - 50 * 60000).toISOString(), atMe: false, key: 'group:1', kind: 'group', name: '甲', text: '闲聊' },
  { id: 'g#2', at: new Date(NOW - 2 * 60000).toISOString(), atMe: true, key: 'group:1', kind: 'group', name: '乙', text: '@她 问个事' },
])

// 1) 评一遍：两条都评，且分数/结论都有
let out = judge.judgeOnce(ROLE, { now: NOW })
assert.equal(out.judged, 2)
assert.equal(out.tally.reply + out.tally.later + out.tally.skip, 2)
let rows = judge.readJudgments(ROLE, { day }).rows
assert.equal(rows.length, 2)
assert.ok(rows[0].score > 0 && rows[0].score <= 1)
assert.ok(['reply', 'later', 'skip'].includes(rows[0].verdict))
assert.equal(rows[1].atMe, true, '@ 要记下来')
assert.ok(rows[1].score > rows[0].score, '刚被 @ 的比 50 分钟前的欲望高')
assert.equal(rows[1].bridge, null, '影子期不替桥下结论')

// 2) 幂等：再跑一次不重复评
out = judge.judgeOnce(ROLE, { now: NOW })
assert.equal(out.judged, 0)
assert.equal(judge.readJudgments(ROLE, { day }).rows.length, 2)

// 3) 权重真的影响判断：把门槛拉到顶，新消息一律不回
rt.setWeight(ROLE, 'replyGate', 1, { who: 'owner', why: '测一下' })
writeInbox([
  { id: 'g#1', at: new Date(NOW - 50 * 60000).toISOString(), atMe: false, key: 'group:1', kind: 'group', name: '甲', text: '闲聊' },
  { id: 'g#2', at: new Date(NOW - 2 * 60000).toISOString(), atMe: true, key: 'group:1', kind: 'group', name: '乙', text: '@她 问个事' },
  { id: 'g#3', at: new Date(NOW - 60000).toISOString(), atMe: false, key: 'group:1', kind: 'group', name: '丙', text: '又一条' },
])
out = judge.judgeOnce(ROLE, { now: NOW })
assert.equal(out.judged, 1)
assert.equal(out.tally.reply, 0, '门槛 1.0 时没人能过（都是 later/skip）')

// 4) 不写桥、不发消息：只在本体 runtime 下留档
const judgeDir = judge.judgmentsDir(ROLE)
assert.ok(fs.existsSync(judgeDir))
assert.equal(fs.existsSync(path.join(HOME, 'bridge')), false, '不该碰桥的目录')

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, judged: true, idempotent: true, weighted: true, shadowOnly: true }))
