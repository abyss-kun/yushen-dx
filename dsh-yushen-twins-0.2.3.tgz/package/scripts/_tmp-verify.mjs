import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'

const HOME = path.join(os.homedir(), '.dsh')
const base = 'http://127.0.0.1:58549'
const b64 = (b) => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const yaml = fs.readFileSync(path.join(HOME, '.credentials.yaml'), 'utf8')
const at = yaml.indexOf('client-connection/browser-session:')
const m = yaml.slice(at, at + 500).match(/secret:\s*([A-Za-z0-9_-]+)/)
const key = Buffer.from(m[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64')
const authority = new URL(base).host
const iat = Date.now()
const body = b64(Buffer.from(JSON.stringify({ version: 1, authority, issuedAt: iat, expiresAt: iat + 3600e3 })))
const sig = b64(crypto.createHmac('sha256', key).update(body).digest())
const cookie = `dsh-auth-${b64(crypto.createHash('sha256').update(authority).digest())}=v1.${body}.${sig}`
const H = { cookie, 'content-type': 'application/json' }

const text = '# 冒烟文件\n这是通过上传接口存下来的。\n'
const up = await (await fetch(base + '/api/yushen/upload', { method: 'POST', headers: H, body: JSON.stringify({ name: '冒烟.md', dataUrl: 'data:text/markdown;base64,' + Buffer.from(text).toString('base64') }) })).json()
console.log('upload:', up.ok, up.path, up.size)
const file = await (await fetch(base + '/api/yushen/file?path=' + encodeURIComponent(up.path), { headers: H })).json()
console.log('file:', file.ok, (file.text || '').split('\n')[0])
