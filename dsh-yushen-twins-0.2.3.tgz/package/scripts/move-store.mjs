// 把备份库搬到另一块盘。默认只演算，不搬。
//
//   node scripts/move-store.mjs            看会搬多少、搬到哪
//   node scripts/move-store.mjs --apply    真搬：复制 → 校验 → 改配置 → 旧库改名留底
//
// 为什么必须先搬库：
//   1. 库现在在 ~/.dsh/dayu/protection/store —— 就在数据目录里面。
//      于是"把整个数据目录当一个备份根"会变成"备份里面装着备份"，校验也会直接拒绝。
//   2. 库和源数据在同一块盘（C:）。盘坏 = 源和备份一起没。
//   搬出去之后，才谈得上"优先备份她们、再备份整个软件"。
//
// 安全：先复制、逐个核对大小、抽样核对哈希、改配置、旧库改名留底（不删）。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const CFG = path.join(HOME, 'dayu', 'protection', 'config.json')
const apply = process.argv.includes('--apply')
const force = process.argv.includes('--force')

function fail(msg) { console.error(`不行：${msg}`); process.exit(1) }
function readCfg() { try { return JSON.parse(fs.readFileSync(CFG, 'utf8').replace(/^\uFEFF/, '')) } catch { return null } }
function dirStat(dir) {
  let files = 0; let bytes = 0
  const walk = (d) => {
    let list = []
    try { list = fs.readdirSync(d, { withFileTypes: true }) } catch { return }
    for (const e of list) {
      const p = path.join(d, e.name)
      if (e.isDirectory()) walk(p)
      else { files += 1; try { bytes += fs.statSync(p).size } catch { /* 跳过 */ } }
    }
  }
  walk(dir)
  return { files, bytes }
}
function sha(file, limit = 4 * 1024 * 1024) {
  try {
    const fd = fs.openSync(file, 'r')
    const buf = Buffer.alloc(Math.min(limit, fs.statSync(file).size))
    fs.readSync(fd, buf, 0, buf.length, 0)
    fs.closeSync(fd)
    return crypto.createHash('sha256').update(buf).digest('hex')
  } catch { return '' }
}

const cfg = readCfg()
if (!cfg) fail(`读不到配置：${CFG}`)
const SRC = cfg.store
const DST = process.env.YUSHEN_STORE_TO || path.join('D:', 'DSH', '备份库', 'store')
if (!fs.existsSync(SRC)) fail(`现在的库不存在：${SRC}`)
if (path.resolve(SRC) === path.resolve(DST)) fail('源和目标是同一个路径')
const freeOnD = (() => {
  try {
    const st = fs.statfsSync('D:\\')
    return `${((st.bavail * st.bsize) / 1073741824).toFixed(0)} GB`
  } catch { return '读不到（不影响搬，空间自己确认一下）' }
})()

const s = dirStat(SRC)
console.log(`现在：${SRC}`)
console.log(`      ${s.files} 个文件，${(s.bytes / 1048576).toFixed(0)} MB`)
console.log(`要搬到：${DST}`)
console.log(`      D 盘剩余：${freeOnD}`)
console.log(`配置里要改的字段：store = ${DST}`)

if (!apply) {
  console.log('\n这是演算。真搬加 --apply。')
  process.exit(0)
}

if (fs.existsSync(DST) && fs.readdirSync(DST).length > 0 && !force) {
  fail(`目标已经有东西：${DST}（确认要覆盖加 --force）`)
}

console.log('\n1/4 复制…')
fs.mkdirSync(path.dirname(DST), { recursive: true })
fs.cpSync(SRC, DST, { recursive: true, force: true, preserveTimestamps: true })

console.log('2/4 核对数量与大小…')
const d = dirStat(DST)
if (d.files !== s.files) fail(`文件数对不上：源 ${s.files} / 目标 ${d.files}`)
if (d.bytes !== s.bytes) fail(`总大小对不上：源 ${s.bytes} / 目标 ${d.bytes}`)

console.log('3/4 抽样核对哈希…')
const sample = []
try {
  const objs = fs.readdirSync(path.join(SRC, 'objects')).slice(0, 20)
  for (const n of objs) sample.push(path.join('objects', n))
  const snaps = fs.readdirSync(path.join(SRC, 'snapshots')).slice(-3)
  for (const n of snaps) sample.push(path.join('snapshots', n))
} catch { /* 结构不对就只比大小 */ }
let bad = 0
for (const rel of sample) {
  const a = sha(path.join(SRC, rel))
  const b = sha(path.join(DST, rel))
  if (a && b && a !== b) bad += 1
}
if (bad) fail(`抽样有 ${bad} 个文件哈希不一致`)
console.log(`      抽样 ${sample.length} 个，全一致`)

console.log('4/4 改配置、旧库改名留底…')
const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)
fs.copyFileSync(CFG, `${CFG}.bak-move-${stamp}`)
const next = { ...cfg, store: DST }
const tmp = `${CFG}.tmp`
fs.writeFileSync(tmp, `${JSON.stringify(next, null, 2)}\n`, 'utf8')
fs.renameSync(tmp, CFG)
const oldName = `${SRC}.old-${stamp}`
try { fs.renameSync(SRC, oldName) } catch { console.log(`  （旧库改名失败，先留着，不影响新库：${SRC}）`) }

console.log(`\n搬完了。新库：${DST}`)
console.log(`旧库留在：${oldName}（确认没问题、跑几天之后再删）`)
console.log('下一步：重启宿主，跑一次备份，确认新库里有新快照。')
