// 第二批：补删 (file, name)。同样先备份 → 删 → node --check → 不过就还原。
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DRY = process.argv.includes('--dry')
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)

const TARGETS = [
  ['lib/hands.js', 'handsLine'],
  ['lib/memory.js', 'touchMemory'],
  ['lib/bodies.js', 'listBodies'],
  ['lib/mind-store.js', 'revokeMindItem'],
]

function spanOf(lines, name) {
  const re = new RegExp(`^export (async )?function ${name}\\s*\\(`)
  const start = lines.findIndex((l) => re.test(l))
  if (start < 0) return null
  let s = start
  while (s > 0 && /^\s*\*/.test(lines[s - 1])) s -= 1
  if (s > 0 && /^\/\*\*/.test(lines[s - 1])) s -= 1
  for (let i = start + 1; i < lines.length; i += 1) {
    if (lines[i].replace(/\r$/, '') === '}') return { start: s, end: i }
  }
  return null
}

const byFile = new Map()
for (const [f, n] of TARGETS) {
  if (!byFile.has(f)) byFile.set(f, [])
  byFile.get(f).push(n)
}

let changed = 0
for (const [rel, names] of byFile) {
  const abs = path.join(ROOT, rel)
  if (!fs.existsSync(abs)) continue
  const original = fs.readFileSync(abs, 'utf8')
  let lines = original.split('\n')
  const log = []
  for (const n of names) {
    const sp = spanOf(lines, n)
    if (!sp) { log.push(`${n} ✗ 没找到`); continue }
    const size = sp.end - sp.start + 1
    if (size > 400) { log.push(`${n} ✗ 跨 ${size} 行，可疑`); continue }
    lines = [...lines.slice(0, sp.start), ...lines.slice(sp.end + 1)]
    log.push(`${n}(-${size}行)`)
  }
  const text = lines.join('\n')
  if (text === original) { console.log(`${rel}: 没变（${log.join('、')}）`); continue }
  if (DRY) { console.log(`[dry] ${rel}: ${log.join('、')}`); changed += 1; continue }
  const bak = `${abs}.bak-${stamp}`
  fs.writeFileSync(bak, original, 'utf8')
  fs.writeFileSync(abs, text, 'utf8')
  try {
    execFileSync(process.execPath, ['--check', abs], { stdio: 'pipe' })
    console.log(`${rel}: ${log.join('、')}  ✓`)
    changed += 1
  } catch (e) {
    fs.copyFileSync(bak, abs)
    console.log(`${rel}: ✗ 语法不过，已还原`)
  }
}
console.log(`\n${DRY ? '会改' : '改了'} ${changed} 个文件`)
