// 遗忘的命令行：跟她在对话里用的是同一套（lib/forget.js）。
//
//   node scripts/forget.mjs status        现在多重、上次清是什么时候、下次什么时候到点
//   node scripts/forget.mjs plan          要扔什么（只看，不删）
//   node scripts/forget.mjs clean --yes   真删：先进冷档 → 删 → 记账
//   node scripts/forget.mjs auto           她自己那一趟（到点才跑；不带 --yes 只演算）
import { status, plan, apply, autoOnce, policy } from '../lib/forget.js'

const cmd = String(process.argv[2] || 'status')
const yes = process.argv.includes('--yes')

const mb = (n) => `${Math.round((Number(n) || 0) / 1048576)} MB`

try {
  if (cmd === 'status') {
    const s = status()
    console.log(`数据目录：${s.dir}  共 ${s.totalMB} MB`)
    console.log(`  快照   ${s.snapshots.files} 份   ${s.snapshots.MB} MB`)
    console.log(`  对象库 ${s.objects.files} 个   ${s.objects.MB} MB`)
    console.log(`  安装包 ${s.artifacts.files} 个   ${s.artifacts.MB} MB`)
    console.log(`  自动清理：${s.policy.auto.enabled ? '开' : '关'}（每 ${s.policy.auto.minHoursBetweenRuns} 小时最多一次）`)
    console.log(`  上次清理：${s.lastRun ? `${s.lastRun.at}（扔了 ${s.lastRun.freedMB ?? 0} MB）` : '还没有'}`)
    console.log(`  下次到点：${s.dueInHours > 0 ? `${s.dueInHours} 小时后` : '已经到点了'}`)
  } else if (cmd === 'plan') {
    const p = plan()
    console.log(`策略来源：${p.policySource}`)
    console.log(`快照：留 ${p.snapshots.keep} 份，扔 ${p.snapshots.drop.length} 份`)
    console.log(`对象：留 ${p.objects.referenced} 个被引用，扔 ${p.objects.drop.length} 个没人要的${p.objects.safeToGc ? '' : '（引用集读不出来，这次不扔）'}`)
    console.log(`安装包副本：扔 ${p.artifacts.drop.length} 个`)
    console.log(`合计可释放：${mb(p.willFreeBytes)}${p.overCap ? '（超过单次上限，会分批）' : ''}`)
    for (const s of p.snapshots.drop.slice(0, 5)) console.log(`  - 快照 ${s.at}  ${mb(s.bytes)}`)
  } else if (cmd === 'clean') {
    if (!yes) {
      const p = plan()
      console.log(`这是演算：会释放 ${mb(p.willFreeBytes)}。要真删请加 --yes。`)
      console.log(`  快照 ${p.snapshots.drop.length} 份 / 对象 ${p.objects.drop.length} 个 / 安装包 ${p.artifacts.drop.length} 个`)
      process.exit(0)
    }
    const r = await apply({ dryRun: false })
    console.log(`清完了：快照 ${r.done.snapshots} 份、对象 ${r.done.objects} 个、安装包 ${r.done.artifacts} 个`)
    console.log(`释放 ${r.freedMB} MB；冷档：${r.done.cold || '（这次没进冷档）'}`)
  } else if (cmd === 'auto') {
    const r = await autoOnce({ dryRun: !yes })
    if (r.skipped) console.log(`没跑：${r.skipped}`)
    else if (r.dryRun) console.log(`演算：会释放 ${mb(r.willFreeBytes)}（要真删加 --yes）`)
    else console.log(`自动清理完成：释放 ${r.freedMB} MB`)
  } else {
    console.log('用法：status | plan | clean [--yes] | auto [--yes]')
    process.exit(1)
  }
} catch (error) {
  console.error(`出错：${error?.message || error}`)
  process.exit(1)
}
