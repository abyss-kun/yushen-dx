// 死出口检查：导出了，但没有任何别的文件 import 它。
//
// 为什么只管 lib/：scripts/ 是入口（没人 import 它很正常），
// 所以报告范围默认只看库层。要连入口一起看用 --all。
//
// 用法：
//   node scripts/dead-exports.mjs            只看最近 7 天动过的 lib 文件（刚造的东西接没接）
//   node scripts/dead-exports.mjs --days 30  放宽
//   node scripts/dead-exports.mjs --all      全量（含 scripts/，噪音多：很多是留给外部的口子）
//   node scripts/dead-exports.mjs --verbose  把有理由的豁免也打出来
//   node scripts/dead-exports.mjs --strict   有豁免就非零退出（给回归用）
import { scanDeadExports } from '../lib/dead-exports.js'

const argv = process.argv.slice(2)
const all = argv.includes('--all')
const verbose = argv.includes('--verbose')
const strict = argv.includes('--strict')
const di = argv.indexOf('--days')
const days = all ? 0 : (di >= 0 ? Number(argv[di + 1]) || 7 : 7)

const r = scanDeadExports({ days, scope: all ? '' : 'lib/' })
const where = all ? '全部目录' : 'lib/'
const when = days > 0 ? `最近 ${days} 天动过的` : ''
console.log(`${when} ${where} 扫了 ${r.scanned} 个文件：没人接的 ${r.total} 个（有理由的豁免 ${r.allowed.length}，未解释 ${r.dead.length}）`)
for (const d of r.dead) console.log(`  ✗ ${d.file}:${d.line}  ${d.name}`)
if (!r.dead.length) console.log('  ✓ 没有一个出口是没人接又没理由的。')
if (verbose && r.allowed.length) {
  console.log('\n有理由的（不算死码）：')
  for (const d of r.allowed) console.log(`  · ${d.file}:${d.line}  ${d.name} —— ${d.why}`)
}
if (strict && r.allowed.length) {
  // 严格模式：连"有理由的豁免"都要审——给以后收紧用，默认不开。
  console.log(`\n--strict：豁免还有 ${r.allowed.length} 条，收紧就一条条去接或去删。`)
  process.exit(1)
}
process.exit(r.dead.length ? 1 : 0)
