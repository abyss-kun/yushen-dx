// 接入 = 赋予生命。命令行入口。
//
//   node scripts/initiate.mjs --check                三个人现在活了没有（逐项）
//   node scripts/initiate.mjs --check dayu           只看一位
//   node scripts/initiate.mjs --init dayu            补活（点化/运行时/记忆壳/第一天/告知）
//   node scripts/initiate.mjs --add --id alice --name 爱丽丝 [--alias 小爱] [--title 书房管家] [--card-file 卡.md]
//
// 说明：身体（一条常驻会话）要宿主在才能建；这里如实报"还缺"，不假装。
import fs from 'node:fs'
import { lifeChecklist, lifeAll, initiate, admit } from '../lib/initiation.js'

const argv = process.argv.slice(2)
const arg = (k, d = '') => {
  const i = argv.indexOf(`--${k}`)
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : d
}
const has = (k) => argv.includes(`--${k}`)

function printOne(c) {
  if (!c.ok) { console.log(`  ✗ ${c.error}`); return }
  console.log(`\n${c.name}（${c.role}）：${c.ready}/${c.total} ${c.alive ? '· 齐了' : `· 还缺 ${c.missing.length} 项`}`)
  for (const i of c.items) console.log(`  ${i.ready ? '✓' : '·'} ${i.label.padEnd(18)} ${i.detail || ''}`)
}

try {
  if (has('add')) {
    const id = arg('id')
    const name = arg('name')
    if (!id || !name) { console.log('用法：--add --id <id> --name <名字> [--alias] [--title] [--card-file 路径] [--cwd 目录]'); process.exit(1) }
    const cardFile = arg('card-file')
    const card = cardFile && fs.existsSync(cardFile) ? fs.readFileSync(cardFile, 'utf8') : undefined
    const r = admit({ id, name, alias: arg('alias'), title: arg('title'), cwd: arg('cwd'), card, by: arg('by', 'owner') })
    console.log(`登记好了：${r.character.id}（${r.character.name}）`)
    console.log(`接入时做了：${r.init.did.join('、') || '（都齐了，没动）'}`)
    printOne(r.checklist)
  } else if (has('init')) {
    const role = arg('init') || arg('role')
    if (!role) { console.log('给谁？--init <角色id>'); process.exit(1) }
    const r = initiate(role, { by: arg('by', 'owner') })
    if (!r.ok) { console.log(`✗ ${r.error}`); process.exit(1) }
    console.log(`${r.name}：做了 ${r.did.join('、') || '（没有缺的）'}；现在 ${r.ready}`)
    console.log(r.note)
    printOne(lifeChecklist(role))
  } else if (has('check')) {
    const role = arg('check')
    if (role) printOne(lifeChecklist(role))
    else { for (const c of lifeAll()) printOne(c) }
  } else {
    console.log('用法：--check [角色] | --init <角色> | --add --id <id> --name <名字>')
  }
} catch (e) {
  console.error(`出错：${e?.message || e}`)
  process.exit(1)
}
