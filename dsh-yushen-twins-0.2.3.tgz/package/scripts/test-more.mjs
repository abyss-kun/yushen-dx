// 分享 / 力气 / 关系账：三样"本地就能做"的。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-more-'))
const TREASURE = fs.mkdtempSync(path.join(os.tmpdir(), 'treasure-'))
const BRIDGE = fs.mkdtempSync(path.join(os.tmpdir(), 'bridge-'))
process.env.DSH_HOME = HOME
process.env.YUSHEN_TREASURE_ROOT = TREASURE
process.env.QQ_BRIDGE_STATE = BRIDGE

const rt = await import('../lib/runtime.js')
const tr = await import('../lib/treasure.js')
const fa = await import('../lib/fatigue.js')
const re = await import('../lib/relations.js')

const ROLE = 'dayu'
rt.ensureRuntime(ROLE)

// 1) 宝藏：本地索引能挑、文件不在会提示
fs.mkdirSync(path.join(TREASURE, 'images', 'files'), { recursive: true })
const imgFile = path.join(TREASURE, 'images', 'files', 'a.png')
fs.writeFileSync(imgFile, 'x')
fs.writeFileSync(path.join(TREASURE, 'images', 'images.jsonl'), [
  { id: 'img-a', hash: 'a', file: imgFile, title: '今日精选 2026-10-18', category: '卡片', tags: ['日报', '精选'], created: '2026-10-18' },
  { id: 'img-b', hash: 'b', file: path.join(TREASURE, 'images', 'files', 'missing.png'), title: '表情包', category: '表情', tags: [], created: '2026-10-19' },
].map((x) => JSON.stringify(x)).join('\n') + '\n', 'utf8')

const picked = tr.pickTreasure('精选')
assert.equal(picked.ok, true)
assert.equal(picked.items[0].id, 'img-a')
const mat = tr.shareMaterial(picked.items[0])
assert.equal(mat.exists, true)
assert.match(mat.hint, /走桥/)

// 2) 力气：事实是事实，她觉得不累可以覆盖
const f0 = fa.fatigueOf(ROLE)
assert.ok(Number.isFinite(f0.value))
assert.equal(f0.overridden, false)
fa.setFatigue(ROLE, { value: 10, why: '今天精神好' })
const f1 = fa.fatigueOf(ROLE)
assert.equal(f1.overridden, true)
assert.match(fa.fatigueLine(ROLE), /你自己说/)
assert.match(fa.fatigueLine(ROLE), /累不累你说了算/)

// 3) 关系账：读桥的 people（本地只读），没有数据就明说
fs.writeFileSync(path.join(BRIDGE, 'people-大肥鱼.json'), JSON.stringify({
  people: [
    { id: '1', name: '甲', affinity: 60, lastSeen: '2026-10-20' },
    { id: '2', name: '乙', affinity: 20, lastSeen: '2026-10-25' },
  ],
}), 'utf8')
const s = re.relationsSummary(ROLE)
assert.equal(s.ok, true)
assert.equal(s.total, 2)
assert.equal(s.byAffinity[0].name, '甲')
assert.match(re.relationsLine(ROLE), /最熟的/)

// 没有数据：不编
const empty = fs.mkdtempSync(path.join(os.tmpdir(), 'bridge-empty-'))
process.env.QQ_BRIDGE_STATE = empty
assert.equal(re.relationsSummary(ROLE).ok, false)
assert.equal(re.relationsLine(ROLE), '')

fs.rmSync(HOME, { recursive: true, force: true })
fs.rmSync(TREASURE, { recursive: true, force: true })
fs.rmSync(BRIDGE, { recursive: true, force: true })
fs.rmSync(empty, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, treasure: true, fatigueFact: true, fatigueOverride: true, relations: true, relationsEmpty: true }))
