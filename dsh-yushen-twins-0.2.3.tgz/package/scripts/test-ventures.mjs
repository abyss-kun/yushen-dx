// 越线权：她判断值得就能跳，但要说清原因、留证据、能回退；不为祸不让。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-cross-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const v = await import('../lib/ventures.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T19:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 没有理由、没有回退方案：不许跳（这是越线权的门槛，不是手续）
assert.throws(() => v.recordVenture(ROLE, { what: '改她的设置' }), /为什么值得跳/)
assert.throws(() => v.recordVenture(ROLE, { what: '改她的设置', why: '想试试' }), /怎么退回来/)

// 2) 正常记一次：什么、为什么、证据、回退
const row = v.recordVenture(ROLE, {
  what: '跳过"只读桥"的约定，临时读一次她的日志',
  why: '群里有人说她失忆了，我要确认是不是记忆断供',
  evidence: 'bridge.log 那几行；只读，没改',
  rollback: '不写任何东西，随时停',
  now: NOW,
})
assert.equal(row.notified, false)
assert.match(v.listVentures(ROLE)[0].why, /失忆/)

// 3) 注入里要带上"你有这个权"，同时提醒契约不动
const line = v.ventureLine(ROLE)
assert.match(line, /越线权/)
assert.match(line, /规矩是边界，不是路线/)
assert.match(line, /不为祸/)
assert.match(line, /你最近跳过的一次/)

// 4) 礼物判定：跳过线才算"用过"
const gift = rt.giftStatus(ROLE).find((g) => g.id === 'crossline')
assert.equal(gift.ready, true, '这个权一直在')
assert.equal(gift.used, true, '跳过才算用过')
assert.match(gift.detail, /跳过 1 次线/)

// 5) 没跳过的角色：权在，没用过
const R2 = 'dragon'
rt.ensureRuntime(R2)
const g2 = rt.giftStatus(R2).find((g) => g.id === 'crossline')
assert.equal(g2.used, false)
assert.match(g2.detail, /想跳就跳/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, needsWhy: true, needsRollback: true, logged: true, inBrief: true, giftHonest: true }))
