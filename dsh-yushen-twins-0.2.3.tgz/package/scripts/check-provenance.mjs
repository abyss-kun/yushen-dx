// 查「改了没记 / 记了没改 / 动了不该动的」。
//
//   node scripts/check-provenance.mjs           # 人看
//   node scripts/check-provenance.mjs --json    # 机器吃
//   node scripts/check-provenance.mjs --hours 24
//
// 为什么有它（老板 2026-10-30）："防止你们忘了——明明不需要修改的，结果改了。"
// 只查、不改。查的是这个仓库里 git 认得的改动，对账 worklog.jsonl。
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const { listWork } = await import(pathToFileURL(path.join(ROOT, 'lib/worklog.js')).href)

const argv = process.argv.slice(2)
const wantJson = argv.includes('--json')
const hours = Math.max(1, Math.min(24 * 14, Number(argv[argv.indexOf('--hours') + 1]) || 12))

function git(args) {
  try {
    return execFileSync('git', args, { cwd: ROOT, encoding: 'utf8' })
  } catch { return null }
}

const status = git(['status', '--porcelain'])
if (status === null) {
  const out = { ok: false, error: '这个目录不是 git 仓库，查不了改动', checkedAt: new Date().toISOString() }
  console.log(wantJson ? JSON.stringify(out, null, 1) : `✗ ${out.error}`)
  process.exit(2)
}

const changed = status.split(/\r?\n/).filter(Boolean).map((line) => {
  const code = line.slice(0, 2).trim()
  const p = line.slice(3).trim().replace(/^"|"$/g, '').replace(/\\/g, '/')
  return { path: p, code }
})

// worklog 里的路径是相对「大小鱼」根的（dsh-yushen-twins/lib/...），这里统一成仓库内相对路径
const pkgName = path.basename(ROOT)
const norm = (p) => String(p || '').replace(/\\/g, '/').replace(new RegExp(`^${pkgName}/`), '')

const since = new Date(Date.now() - hours * 3600 * 1000).toISOString()
const rows = listWork(500).filter((r) => String(r.at || '') >= since)
const recorded = new Map()
for (const r of rows) for (const f of r.files || []) {
  const k = norm(f)
  if (!recorded.has(k)) recorded.set(k, [])
  recorded.get(k).push(r)
}

const protectedList = (() => {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(ROOT, '不可改清单.json'), 'utf8'))
    return Object.entries(j.items || {})
  } catch { return [] }
})()

const problems = { 改了没记: [], 记了没改: [], 动了不该动的: [] }

for (const c of changed) {
  if (/^(不可改清单\.json|CHANGELOG\.md)$/.test(c.path)) continue
  const hit = recorded.get(c.path)
  if (!hit) problems.改了没记.push(c.path)
  // 不可改：必须有记录，且 auth 里提到主人
  const guard = protectedList.find(([p]) => c.path === p || c.path.endsWith(p) || p.includes(c.path))
  if (guard) {
    const ok = (hit || []).some((r) => String(r.auth || '').includes('主人'))
    if (!ok) problems.动了不该动的.push(`${c.path}（${guard[1]}）`)
  }
}

// 记了没改：说改了但文件时间比记录还早（多半是记错文件）
for (const [f, list] of recorded) {
  const abs = path.join(ROOT, f)
  if (!fs.existsSync(abs)) continue
  if (changed.some((c) => c.path === f)) continue
  const newest = Math.max(...list.map((r) => Date.parse(r.at) || 0))
  if (Date.now() - newest < hours * 3600 * 1000 && fs.statSync(abs).mtimeMs < newest - 60 * 1000) {
    problems.记了没改.push(f)
  }
}

const bad = problems.改了没记.length + problems.动了不该动的.length
const out = { ok: bad === 0, checkedAt: new Date().toISOString(), hours, changed: changed.length, recorded: recorded.size, problems }

if (wantJson) {
  console.log(JSON.stringify(out, null, 1))
} else {
  console.log(`改了 ${changed.length} 个文件，近 ${hours} 小时有记录的 ${recorded.size} 个。`)
  for (const [k, list] of Object.entries(problems)) {
    if (!list.length) continue
    console.log(`\n${k}：`)
    for (const p of list.slice(0, 20)) console.log(`  - ${p}`)
  }
  if (!bad) console.log('\n✓ 改过的都有记录，没动不该动的。')
  else console.log('\n按 docs/改动留痕.md 补一条：node scripts/note-work.mjs …')
}
process.exit(bad ? 1 : 0)
