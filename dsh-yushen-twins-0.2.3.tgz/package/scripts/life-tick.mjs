// 生命时钟：不用等插件重载——这个脚本自己看时间、看额度，到点就叫她过自己的时间。
// 用法：ELECTRON_RUN_AS_NODE=1 "<exe>" scripts/life-tick.mjs [--force] [--role=xiaoyu] [--dry-run]
// 建议每 30 分钟跑一次（任务计划或插件里的定时器）；它只读本地状态 + 调 /residence/say。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { isAwake } from '../lib/awakening.js'
import { shouldRun, markRun } from '../lib/freetime.js'
import { capture } from '../lib/capture.js'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const args = process.argv.slice(2)
const force = args.includes('--force')
const dryRun = args.includes('--dry-run')
const only = (args.find((a) => a.startsWith('--role=')) || '').slice(7)
const token = fs.readFileSync(path.join(DATA, 'api-token'), 'utf8').trim()
const baseRaw = fs.readFileSync(path.join(DATA, 'base-url'), 'utf8').trim()
const base = /^https?:\/\//.test(baseRaw) ? baseRaw : `http://${baseRaw}`

function switches() {
  try { return JSON.parse(fs.readFileSync(path.join(DATA, 'switches.json'), 'utf8')) } catch { return {} }
}
async function api(pathname, { method = 'GET', body } = {}) {
  const res = await fetch(`${base}${pathname}`, {
    method,
    headers: { 'x-yushen-token': token, 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  })
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch { /* 非 JSON */ }
  if (!res.ok) throw new Error(`${pathname} HTTP ${res.status}: ${text.slice(0, 160)}`)
  return json
}

const out = { ok: true, at: new Date().toISOString(), ran: [], skipped: [] }
if (switches().freeTime === false) {
  out.ok = false
  out.reason = 'freeTime 关着'
  console.log(JSON.stringify(out, null, 2))
  process.exit(0)
}
const state = await api('/api/dayu/residence')
for (const [role, row] of Object.entries(state.roles || {})) {
  if (only && role !== only) continue
  if (!isAwake(role)) { out.skipped.push({ role, why: '未点化' }); continue }
  const lastActive = row.lastMessageAt || row.lastWakeAt || ''
  if (!force && !shouldRun(role, { lastActiveAt: lastActive })) { out.skipped.push({ role, why: '没到点/还在忙/额度用完' }); continue }
  const prompt = `${row.label || role}，现在是你的自由时间，没人派活。想做什么就做什么：发呆、翻资料、整理记忆、写点东西、或者什么都不做。做完用一句话记下你做了什么、为什么；不想说就不说。`
  if (dryRun) { out.ran.push({ role, dryRun: true, prompt }); continue }
  try {
    const sent = await api('/api/dayu/residence/say', { method: 'POST', body: { role, text: prompt } })
    markRun(role, { note: '自由时间' })
    try { capture(`【自由时间】叫醒 ${role}`, { kind: 'talk', source: '生命时钟', role }) } catch { /* 忽略 */ }
    out.ran.push({ role, sessionId: sent.sessionId, via: sent.via })
  } catch (error) {
    out.ran.push({ role, error: String(error?.message || error) })
  }
}
console.log(JSON.stringify(out, null, 2))
