// 架构依赖图：谁 import 谁、哪些是核心、哪些是孤岛。只读代码，不改任何东西。
// 用法：node scripts/arch-graph.mjs [--top 20]
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DIRS = ['lib', 'core', 'dayu', 'xiaoyu', 'adapters']
const files = []
for (const d of DIRS) {
  const dir = path.join(ROOT, d)
  if (!fs.existsSync(dir)) continue
  for (const f of fs.readdirSync(dir)) {
    if (f.endsWith('.js')) files.push(d + '/' + f)
  }
}
const key = (rel) => rel.replace(/\\/g, '/')
// 除了这些模块自己，脚本和入口也在 import 它们——不算进去会把"被脚本用"误判成孤岛。
const importers = [...files]
for (const extra of ['index.js']) {
  if (fs.existsSync(path.join(ROOT, extra))) importers.push(extra)
}
const scriptsDir = path.join(ROOT, 'scripts')
if (fs.existsSync(scriptsDir)) {
  for (const f of fs.readdirSync(scriptsDir)) if (f.endsWith('.mjs') || f.endsWith('.js')) importers.push('scripts/' + f)
}
const edges = new Map() // file -> Set(imported file)
const used = new Map()
for (const rel of importers) {
  const abs = path.join(ROOT, rel)
  const text = fs.readFileSync(abs, 'utf8')
  const set = new Set()
  for (const m of text.matchAll(/from\s+['"](\.[^'"]+)['"]/g)) {
    const target = path.normalize(path.join(path.dirname(abs), m[1]))
    let resolved = target
    if (!fs.existsSync(resolved)) resolved = `${target}.js`
    if (!fs.existsSync(resolved)) continue
    const r = key(path.relative(ROOT, resolved))
    if (r === rel) continue
    set.add(r)
    used.set(r, (used.get(r) || 0) + 1)
  }
  edges.set(rel, set)
}

const byFanIn = [...used.entries()].sort((a, b) => b[1] - a[1])
const top = Number(process.argv[process.argv.indexOf('--top') + 1]) || 15

console.log(`文件 ${files.length} 个，有引用的 ${used.size} 个，孤岛 ${files.length - used.size} 个\n`)
console.log('## 被引用最多（改之前先想清楚）')
for (const [f, n] of byFanIn.slice(0, top)) console.log(`${String(n).padStart(4)}×  ${f}`)
console.log('\n## 孤岛（没有任何 .js 引用；可能是入口/测试/死代码）')
for (const rel of files) if (!used.has(rel)) console.log(`      ${rel}`)
console.log('\n## 依赖最重（自己 import 最多）')
const byOut = [...edges.entries()].sort((a, b) => b[1].size - a[1].size).slice(0, 10)
for (const [f, s] of byOut) console.log(`${String(s.size).padStart(4)}  ${f}`)
