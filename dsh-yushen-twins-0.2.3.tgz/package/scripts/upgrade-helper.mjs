#!/usr/bin/env node
// 助手升级的手动入口（插件启动时也会自动跑）：已装过旧版本 → 装新版、改桌面快捷方式、归档旧目录。
//
// 用法：
//   node scripts/upgrade-helper.mjs            # 人看的摘要
//   node scripts/upgrade-helper.mjs --json     # 机器读的 JSON

import { autoUpgradeIfInstalled, helperInfo } from '../lib/repair-helper-install.js';

const asJson = process.argv.includes('--json');
const info = await helperInfo();
const result = await autoUpgradeIfInstalled();

if (asJson) {
  console.log(JSON.stringify({ bundled: { available: info.available, sha256: info.sha256, size: info.size }, result }, null, 2));
} else {
  console.log('鱼神修复助手 · 安装/升级检查');
  console.log(`发行包里的助手：${info.available ? '可用' : '不可用'}  sha256=${(info.sha256 || '').slice(0, 16)}…  ${info.size ?? '-'} bytes`);
  if (result.skipped) console.log(`跳过：${result.skipped}`);
  if (result.upgraded) console.log(`已升级：${result.from.join('、')} → ${result.to}`);
  if (result.shortcutUpdated) console.log('桌面快捷方式已更新指向新版本');
  if (result.archivedOldVersions?.length) console.log(`旧版本已归档：${result.archivedOldVersions.join('、')}`);
  if (result.sha256) console.log(`当前安装版本：${result.sha256.slice(0, 16)}…`);
}
