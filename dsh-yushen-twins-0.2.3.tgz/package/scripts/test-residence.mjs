// 本体与常驻身体的最小回归：卡/记忆按角色分开、身体只建一次、pending 有兜底、状态能说清三个人。
// 跑法：ELECTRON_RUN_AS_NODE=1 "<DeepSeek Harness.exe>" scripts/test-residence.mjs
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-residence-'))
process.env.DSH_HOME = HOME
const SOUL = path.join(HOME, 'dayu', 'soul')
fs.mkdirSync(path.join(SOUL, 'cards'), { recursive: true })
fs.mkdirSync(path.join(SOUL, 'memory'), { recursive: true })

fs.writeFileSync(path.join(SOUL, 'persona.json'), JSON.stringify({
  version: 3,
  scenes: { desk: 'cards/dayu.desk.md', social: 'cards/dayu.social.md', socialXiaoyu: 'cards/xiaoyu.desk.md', deskXiaoyu: 'cards/xiaoyu.desk.md', dragon: 'cards/dragon.desk.md' },
  memory: { dayu: 'memory/dayu.json', xiaoyu: 'memory/xiaoyu.json', dragon: 'memory/dragon.json' },
  owner: { callName: '老大', verbosity: '正常', taboos: '不外传令牌' },
}), 'utf8')
fs.writeFileSync(path.join(SOUL, 'cards', 'dayu.desk.md'), '# 大鱼卡\n她短、她护短。', 'utf8')
fs.writeFileSync(path.join(SOUL, 'cards', 'dayu.social.md'), '# 大鱼社交卡', 'utf8')
fs.writeFileSync(path.join(SOUL, 'cards', 'xiaoyu.desk.md'), '# 小鱼卡\n她软、她认真。\nQQ 群里的事只在 QQ 说。', 'utf8')
fs.writeFileSync(path.join(SOUL, 'cards', 'dragon.desk.md'), '# 照微卡\n察微、求证、护持。', 'utf8')
fs.writeFileSync(path.join(SOUL, 'memory', 'dayu.json'), JSON.stringify({ version: 1, summary: '大鱼摘要', habits: ['能一个字回就不写两个字'], dynamics: ['和妹妹互相挑刺'], events: [{ at: '2026-10-25T01:00:00Z', channel: 'QQ', text: '在群里回了歌词的事' }, { at: '2026-10-25T02:00:00Z', channel: '工作台', text: '派了一单备份验收' }] }), 'utf8')
fs.writeFileSync(path.join(SOUL, 'memory', 'xiaoyu.json'), JSON.stringify({ version: 1, summary: '小鱼摘要', habits: ['会多问一句'], dynamics: [] }), 'utf8')
fs.writeFileSync(path.join(SOUL, 'memory', 'dragon.json'), JSON.stringify({ version: 1, summary: '', habits: [], dynamics: [] }), 'utf8')

const soul = await import('../lib/soul.js')
const residence = await import('../lib/residence.js')

// 1) 三个角色各读各的卡和记忆，不串档
const dayuText = soul.buildSceneText('dayu', 'desk')
assert.match(dayuText, /大鱼卡/)
assert.match(dayuText, /大鱼摘要/)
assert.doesNotMatch(dayuText, /小鱼摘要/)
const xiaoyuText = soul.buildSceneText('xiaoyu', 'desk')
assert.match(xiaoyuText, /小鱼卡/)
assert.match(xiaoyuText, /场景提醒/, '小鱼的 QQ 卡在工作台要有场景提醒')
assert.match(xiaoyuText, /小鱼摘要/)
const dragonText = soul.buildSceneText('dragon', 'desk')
assert.match(dragonText, /照微卡/)
assert.match(dragonText, /察微、求证、护持/)
assert.equal(soul.soulStatus('dayu').briefChars > 0, true, 'briefChars 不能是 0')
assert.equal(soul.soulStatus('dragon').memory.habits, 0)

// 1b) 共享参考：三个人都要「知道有这么个东西」，但不许当成自己的记忆
const SHARED = path.join(HOME, 'dayu', 'shared-memory', 'creative-references.json')
fs.mkdirSync(path.dirname(SHARED), { recursive: true })
fs.writeFileSync(SHARED, JSON.stringify({
  schemaVersion: 1,
  sections: [
    { topic: 'boundaries', text: '不预置感想' },
    { topic: 'dragons', text: '青龙与白龙' },
    { topic: 'dayu', text: '本地大鱼' },
    { topic: 'xiaoyu', text: '本地小鱼' },
    { topic: 'ensemble', text: '群像' },
    { topic: 'sources', text: 'BV 号' },
  ],
}), 'utf8')
for (const role of ['dayu', 'xiaoyu', 'dragon']) {
  const text = soul.buildSceneText(role, 'desk')
  assert.match(text, /共享资料/, `${role} 要知道有这份资料`)
  assert.match(text, /外部资料，不是你的记忆/, `${role} 不能把资料当记忆`)
  assert.match(text, /青龙 \/ 照微/, `${role} 要知道主题清单`)
  assert.match(text, /dayu_creative_recall/, `${role} 要知道怎么按需查`)
  assert.doesNotMatch(text, /不预置感想[。]?\s*青龙/, '不能把正文抄进常驻注入')
}
// 一个人一份记忆：QQ 场景和工作台读到同一份，不按通道分家
const dayuQQ = soul.buildSceneText('dayu', 'social')
assert.match(dayuQQ, /本体与通道|记忆/)
assert.match(dayuQQ, /记忆边界/)
assert.doesNotMatch(dayuQQ, /大鱼摘要/)
assert.doesNotMatch(dayuQQ, /能一个字回就不写两个字/)
assert.doesNotMatch(dayuQQ, /在各通道做过的事/, '社交场景不整本展开工作台记忆')
assert.doesNotMatch(dayuQQ, /\[QQ\] 在群里回了歌词的事/)
assert.doesNotMatch(dayuQQ, /\[工作台\] 派了一单备份验收/)
assert.match(dayuQQ, /你不是住在应用里/)
fs.renameSync(SHARED, `${SHARED}.bak`)
assert.doesNotMatch(soul.buildSceneText('dayu', 'desk'), /共享资料/, '没有资料文件时不许编一份出来')
fs.renameSync(`${SHARED}.bak`, SHARED)

// 2) 身体：只建一次、先选模型、卡送进会话
const made = []
const handles = new Map()
const calls = { selectModel: 0, prompt: 0, followup: 0 }
let seq = 0
const agents = {
  get: (id) => handles.get(id) || null,
  create: async ({ sessionId }) => {
    seq += 1
    const handle = {
      agent: {
        session: { header: { id: `sess-${seq}` } },
        followup: async () => { calls.followup += 1; made.push('followup') },
      },
      sessionId,
    }
    handles.set(`sess-${seq}`, handle)
    made.push(`create:${seq}`)
    return handle
  },
}
const deps = {
  agents,
  selectModel: async () => { calls.selectModel += 1 },
  prompt: async ({ sessionId }) => { calls.prompt += 1; made.push(`prompt:${sessionId}`) },
  listRows: () => [],
  log: () => {},
}
const first = await residence.ensureRole('dayu', deps)
assert.equal(first.created, true)
assert.equal(calls.selectModel, 1, '新身体必须先选模型，不然第一条消息会 pending')
assert.equal(calls.followup, 1, '本体要送进身体')
const again = await residence.ensureRole('dayu', deps)
assert.equal(again.created, false, '同一进程里不能每句话都新开一条')
assert.equal(again.sessionId, first.sessionId)
assert.equal(made.filter((x) => x.startsWith('create:')).length, 1)

// 3) pending 死锁：不走死，改走 session/prompt
const stuck = await residence.ensureRole('dragon', deps)
const body = handles.get(stuck.sessionId) || [...handles.values()].find((h) => h.agent.session.header.id === stuck.sessionId)
body.agent.followup = async () => { throw new Error('message "undefined" is already pending') }
const sent = await residence.deliverToRole('dragon', '在吗', deps)
assert.equal(sent.via, 'prompt-rpc')
assert.equal(sent.recovered, true)

// 3b) 新宿主路径：session RPC 建身体（agents.create 的 followup 回合会空转，实测不通）
let xseed = 0
const rpcCalls = { create: 0, prompt: 0, select: 0, rename: 0 }
const deps2 = {
  agents,
  log: () => {},
  listRows: () => [],
  findSession: async (id) => id === 'sess-x',
  createSession: async () => { rpcCalls.create += 1; return 'sess-x' },
  selectModel: async () => { rpcCalls.select += 1 },
  renameSession: async () => { rpcCalls.rename += 1 },
  prompt: async () => { rpcCalls.prompt += 1; xseed += 1 },
}
const xBody = await residence.ensureRole('xiaoyu', deps2)
assert.equal(xBody.created, true)
assert.equal(xBody.sessionId, 'sess-x')
assert.equal(xBody.handle, null, 'RPC 身体没有句柄，话走 session/prompt')
assert.equal(rpcCalls.create, 1)
assert.equal(rpcCalls.select, 1, '新身体必须先选模型')
assert.equal(rpcCalls.prompt, 1, '本体要作为第一条消息送进去')
assert.equal(rpcCalls.rename, 1)
const promptsBefore = rpcCalls.prompt
const xAgain = await residence.ensureRole('xiaoyu', deps2)
assert.equal(xAgain.created, false, '账本里还有这条会话就不能重开')
assert.equal(xAgain.sessionId, 'sess-x')
assert.equal(rpcCalls.prompt, promptsBefore, '卡没变就不该重复注设定')
const xSent = await residence.deliverToRole('xiaoyu', '在吗', deps2)
assert.equal(xSent.via, 'prompt-rpc')
assert.equal(xSent.sessionId, 'sess-x')

// 4) 状态说清三个人
const status = residence.residenceStatus({ agents })
assert.deepEqual(Object.keys(status.roles).sort(), ['dayu', 'dragon', 'xiaoyu'])
assert.equal(status.roles.dayu.body, true)
assert.equal(status.roles.dragon.alive, true)
assert.equal(status.roles.xiaoyu.body, true)
assert.equal(status.roles.xiaoyu.sessionId, 'sess-x', '状态要报账本里那条，不是新编一条')

// 5) 账本落盘、可重读
const ledger = JSON.parse(fs.readFileSync(path.join(HOME, 'dayu', 'residence.json'), 'utf8'))
assert.equal(ledger.roles.dayu.sessionId, first.sessionId)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, followups: calls.followup, selectModel: calls.selectModel, prompts: calls.prompt }))
