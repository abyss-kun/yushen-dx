#!/usr/bin/env node
// 会话体检：只读。查两件会让「崩溃后续跑」必炸的事。
//
//   ① 未收尾的会话：turn/start 比 turn/end 多（崩在一轮中间），或者有工具调用
//      发出去却没拿到结果（tool/call 的 callId 没有对应 tool/result）。
//      这类会话被重置后一续跑，就带着半截状态往下走。
//   ② 悬空的附件引用：会话里引用了 sha256:<64hex>，但
//      $DSH_HOME/attachments/v1/objects/<前两位>/<sha> 不存在。
//      重放时模型拿到的是空引用，直接报错。
//
// 为什么用 Node 而不是修复助手（C#）：会话是 session.v4.jsonl.zstd，
// 一个文件里是**多帧首尾相接**（一次追加一帧），.NET Framework 没有 zstd，
// Node 24 自带 zstdDecompressSync。
//
// 用法：
//   node scripts/session-doctor.mjs                 # 人看的摘要
//   node scripts/session-doctor.mjs --json          # 机器读的 JSON
//   node scripts/session-doctor.mjs --days 3        # 只看最近 3 天动过的
//   node scripts/session-doctor.mjs --strict        # 有问题就 exit 1
//   node scripts/session-doctor.mjs --limit 50      # 最多扫 50 个（新→旧）
//   node scripts/session-doctor.mjs --live-minutes 2  # 多久内算「可能正在跑」
//
// 只读：不写文件、不改会话、不发网络请求。输出含会话 id 与悬空 sha，
// 用于本机定位，不要贴到群里。

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import zlib from 'node:zlib';

const ZSTD_MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd]);
const SHA_RE = /"attachmentId"\s*:\s*"sha256:([0-9a-f]{64})"/g;
const MAX_FILE_BYTES = 64 * 1024 * 1024;

function arg(name, fallback) {
  const i = process.argv.indexOf('--' + name);
  if (i === -1) return fallback;
  const v = process.argv[i + 1];
  return v && !v.startsWith('--') ? v : true;
}

const asJson = process.argv.includes('--json');
const strict = process.argv.includes('--strict');
const days = Number(arg('days', 0)) || 0;
const limit = Number(arg('limit', 0)) || 0;
const liveMinutes = Number(arg('live-minutes', 2)) || 2;

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
const SESSIONS = path.join(HOME, 'sessions');
const OBJECTS = path.join(HOME, 'attachments', 'v1', 'objects');

/** 会话文件是多帧 zstd；按帧切再逐帧解，解不开的帧单独计数，不整体放弃。 */
function decodeSessionFile(file) {
  const buf = fs.readFileSync(file);
  if (buf.length > MAX_FILE_BYTES) return { tooLarge: true, text: '', frames: { ok: 0, failed: 0 } };
  if (buf.indexOf(ZSTD_MAGIC) === -1) {
    // 不是 zstd 就当纯文本（老格式或未压缩），照样能查。
    return { text: buf.toString('utf8'), frames: { ok: 0, failed: 0 } };
  }
  const offsets = [];
  let at = 0;
  while ((at = buf.indexOf(ZSTD_MAGIC, at)) !== -1) {
    offsets.push(at);
    at += 4;
  }
  const parts = [];
  let ok = 0;
  let failed = 0;
  for (let k = 0; k < offsets.length; k += 1) {
    const end = k + 1 < offsets.length ? offsets[k + 1] : buf.length;
    try {
      parts.push(zlib.zstdDecompressSync(buf.subarray(offsets[k], end)).toString('utf8'));
      ok += 1;
    } catch {
      failed += 1; // 尾帧截断（正好崩在写一半）会落在这里
    }
  }
  return { text: parts.join(''), frames: { ok, failed } };
}

function attachmentPath(sha) {
  return path.join(OBJECTS, sha.slice(0, 2), sha);
}

function scanSession(dir, liveWindowMs) {
  const file = path.join(dir, 'session.v4.jsonl.zstd');
  if (!fs.existsSync(file)) return null;
  const stat = fs.statSync(file);
  const { text, frames, tooLarge } = decodeSessionFile(file);
  const records = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try { records.push(JSON.parse(line)); } catch { /* 半行也算截断 */ }
  }

  let turnStarts = 0;
  let turnEnds = 0;
  const callIds = new Set();
  const resultIds = new Set();
  for (const r of records) {
    const type = r && r.type;
    if (type === 'turn/start') turnStarts += 1;
    else if (type === 'turn/end') turnEnds += 1;
    else if (type === 'tool/call') {
      const id = r.data && r.data.callId;
      if (typeof id === 'string') callIds.add(id);
    } else if (type === 'tool/result') {
      const d = r.data || {};
      const id = (d.message && d.message.toolCallId) || d.toolCallId || d.callId;
      if (typeof id === 'string') resultIds.add(id);
    }
  }
  const pendingCalls = [...callIds].filter((id) => !resultIds.has(id));
  const last = records.length ? records[records.length - 1] : null;
  const cwd = records.length && typeof records[0].cwd === 'string' ? records[0].cwd : '';
  const possiblyLive = Date.now() - stat.mtimeMs < liveWindowMs;

  const shas = new Set();
  for (const m of text.matchAll(SHA_RE)) shas.add(m[1]);
  const missing = [...shas].filter((sha) => !fs.existsSync(attachmentPath(sha)));

  return {
    id: path.basename(dir),
    cwd,
    fileBytes: stat.size,
    modifiedAt: stat.mtime.toISOString(),
    records: records.length,
    lastType: last && typeof last.type === 'string' ? last.type : 'unknown',
    turnStarts,
    turnEnds,
    unfinished: turnStarts > turnEnds,
    pendingToolCalls: pendingCalls.length,
    possiblyLive,
    frames,
    tooLarge: tooLarge === true,
    attachments: { referenced: shas.size, missingCount: missing.length, missing: missing.slice(0, 20) },
  };
}

function listSessionDirs() {
  if (!fs.existsSync(SESSIONS)) return [];
  const out = [];
  for (const workspace of fs.readdirSync(SESSIONS, { withFileTypes: true })) {
    if (!workspace.isDirectory()) continue;
    const wsDir = path.join(SESSIONS, workspace.name);
    for (const entry of fs.readdirSync(wsDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      out.push(path.join(wsDir, entry.name));
    }
  }
  return out;
}

const cutoff = days > 0 ? Date.now() - days * 86400000 : 0;
const liveWindowMs = liveMinutes * 60000;
let dirs = listSessionDirs()
  .map((dir) => {
    const f = path.join(dir, 'session.v4.jsonl.zstd');
    let mtime = 0;
    try { mtime = fs.statSync(f).mtimeMs; } catch { /* 没文件排最后 */ }
    return { dir, mtime };
  })
  .filter((x) => !cutoff || x.mtime >= cutoff)
  .sort((a, b) => b.mtime - a.mtime)
  .map((x) => x.dir);
if (limit > 0) dirs = dirs.slice(0, limit);

const sessions = [];
for (const dir of dirs) {
  const row = scanSession(dir, liveWindowMs);
  if (row) sessions.push(row);
}

const stale = (s) => (s.unfinished || s.pendingToolCalls > 0) && !s.possiblyLive;
const totals = {
  scanned: sessions.length,
  unfinished: sessions.filter((s) => s.unfinished).length,
  unfinishedStale: sessions.filter((s) => s.unfinished && !s.possiblyLive).length,
  pendingToolCalls: sessions.reduce((n, s) => n + s.pendingToolCalls, 0),
  staleSessions: sessions.filter(stale).length,
  corruptTail: sessions.filter((s) => s.frames.failed > 0).length,
  emptyTail: sessions.filter((s) => s.records === 0).length,
  referencedAttachments: sessions.reduce((n, s) => n + s.attachments.referenced, 0),
  missingAttachments: sessions.reduce((n, s) => n + s.attachments.missingCount, 0),
  sessionsWithMissing: sessions.filter((s) => s.attachments.missingCount > 0).length,
};

const issues = [];
if (totals.staleSessions > 0) issues.push(`${totals.staleSessions} 个会话停在半截（不在跑、也没走到 turn/end）：续跑会带着悬空状态`);
if (totals.pendingToolCalls > 0) issues.push(`共 ${totals.pendingToolCalls} 个工具调用发出去了没拿到结果`);
if (totals.sessionsWithMissing > 0) issues.push(`${totals.sessionsWithMissing} 个会话引用了已不存在的附件（共 ${totals.missingAttachments} 个，重放必炸）`);
if (totals.corruptTail > 0) issues.push(`${totals.corruptTail} 个会话有解不开的尾帧（可能崩在写入途中）`);

if (asJson) {
  console.log(JSON.stringify({ home: HOME, totals, issues, sessions }, null, 2));
} else {
  console.log(`会话体检（只读） · ${HOME}`);
  console.log(`扫描 ${totals.scanned} 个 · 未收尾 ${totals.unfinished}（其中不在跑 ${totals.unfinishedStale}）· 挂起工具调用 ${totals.pendingToolCalls} · 尾帧损坏 ${totals.corruptTail} · 空会话 ${totals.emptyTail}`);
  console.log(`附件引用 ${totals.referencedAttachments} 个 · 悬空 ${totals.missingAttachments} 个（涉及 ${totals.sessionsWithMissing} 个会话）`);
  if (issues.length) {
    console.log('\n需要注意：');
    for (const line of issues) console.log('  - ' + line);
  } else {
    console.log('\n没有发现会炸的地方。');
  }
  const worst = sessions
    .filter((s) => stale(s) || s.attachments.missingCount > 0)
    .sort((a, b) => (b.attachments.missingCount - a.attachments.missingCount) || (b.pendingToolCalls - a.pendingToolCalls))
    .slice(0, 20);
  if (worst.length) {
    console.log('\n逐条（最多 20 条）：');
    for (const s of worst) {
      const flags = [];
      if (s.unfinished) flags.push('未收尾');
      if (s.pendingToolCalls > 0) flags.push(`挂起工具${s.pendingToolCalls}`);
      if (s.attachments.missingCount > 0) flags.push(`悬空附件${s.attachments.missingCount}`);
      if (s.frames.failed > 0) flags.push(`坏帧${s.frames.failed}`);
      console.log(`  ${s.id}  ${s.turnStarts}/${s.turnEnds} turns  末条=${s.lastType}  ${flags.join(' ')}` +
        (s.cwd ? `  cwd=${s.cwd}` : ''));
    }
  }
}

if (strict && issues.length) process.exit(1);
