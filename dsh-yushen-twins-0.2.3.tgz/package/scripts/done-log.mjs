// done-log：读「做成过什么」的上报记录，顺手验一遍那条路还在不在。
//
// 为什么分开写：feel 记的是感觉（soul/feel），done 记的是交付（soul/deliveries），
// 两个文件、两种用途，合成一个脚本反而不好讲。
//
// 用法：
//   node dsh-yushen-twins/scripts/done-log.mjs               # 小鱼最近 10 条
//   node dsh-yushen-twins/scripts/done-log.mjs all --limit 30
//   node dsh-yushen-twins/scripts/done-log.mjs xiaoyu --grep 引用
//   node dsh-yushen-twins/scripts/done-log.mjs xiaoyu --gone  # 只看路径已经没了的
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const ROLES = ['dayu', 'xiaoyu', 'dragon']
const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DONE_DIR = path.join(HOME, 'dayu', 'soul', 'deliveries')

function parseArgs(argv) {
  const out = { role: 'xiaoyu', limit: 10, grep: '', gone: false, since: '' }
  const rest = []
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--limit') out.limit = Number(argv[++i]) || 10
    else if (a === '--grep') out.grep = String(argv[++i] || '')
    else if (a === '--since') out.since = String(argv[++i] || '')
    else if (a === '--gone') out.gone = true
    else if (!a.startsWith('-')) rest.push(a)
  }
  if (rest[0]) out.role = rest[0]
  return out
}

function readRole(role) {
  const file = path.join(DONE_DIR, `${role}.jsonl`)
  if (!fs.existsSync(file)) return { rows: [], bytes: 0 }
  const raw = fs.readFileSync(file, 'utf8')
  const rows = []
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue
    try { rows.push(JSON.parse(line)) } catch { /* 坏行跳过 */ }
  }
  return { rows, bytes: Buffer.byteLength(raw, 'utf8') }
}

const args = parseArgs(process.argv.slice(2))
const roles = args.role === 'all' ? ROLES : [args.role]
const all = []
for (const r of roles) {
  const { rows, bytes } = readRole(r)
  for (const row of rows) all.push({ ...row, _role: row.role || r })
  if (rows.length === 0) console.log(`· ${r}: 没有上报记录（文件 ${bytes} 字节）`)
}

let list = all
if (args.since) list = list.filter((x) => String(x.at || '') >= args.since)
if (args.grep) {
  const q = args.grep
  list = list.filter((x) => `${x.what || ''} ${x.path || ''} ${x.evidence || ''}`.includes(q))
}

const exists = (p) => {
  if (!p) return null
  try { return fs.existsSync(p) } catch { return false }
}

if (args.gone) list = list.filter((x) => exists(x.path) === false)
list.sort((a, b) => String(a.at || '').localeCompare(String(b.at || '')))
const shown = list.slice(-args.limit)

if (!shown.length) {
  console.log(args.gone ? '没有路径失效的记录。' : '没有符合的 done 记录。')
  process.exit(0)
}

let missing = 0
let checked = 0
console.log(`done · 共 ${all.length} 条，本次显示 ${shown.length} 条（${roles.join('/')}）\n`)
for (const x of shown) {
  const at = String(x.at || '').replace('T', ' ').slice(0, 16)
  const ok = exists(x.path)
  if (ok !== null) { checked++; if (!ok) missing++ }
  const mark = ok === null ? '（无路径）' : ok ? '✓ 在' : '✗ **不在了**'
  console.log(`${at}  ${x._role}  ${mark}`)
  console.log(`  做了：${String(x.what || '').slice(0, 110)}`)
  if (x.path) console.log(`  路径：${x.path}`)
  if (x.how) console.log(`  怎么验：${String(x.how).slice(0, 100)}`)
  console.log('')
}
console.log(`— 本次查了 ${checked} 条路径，${missing} 条已经找不到。`)
