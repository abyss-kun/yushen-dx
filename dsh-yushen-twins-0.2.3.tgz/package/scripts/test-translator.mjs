// 翻译器：只写观察不写结论；后端可选；本地不在时绝不假装翻译过。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-tr-'))
process.env.DSH_HOME = HOME
const tr = await import('../lib/translator.js')

// 1) 默认后端：remote（出厂版不能假定别人有本地模型）
assert.equal(tr.backendFor('dayu'), 'remote')

// 2) 能按角色改
tr.setBackend({ role: 'xiaoyu', backend: 'hybrid' })
assert.equal(tr.backendFor('xiaoyu'), 'hybrid')
assert.equal(tr.backendFor('dayu'), 'remote', '只改一个角色，不影响别人')
tr.setBackend({ backend: 'off' })
assert.equal(tr.backendFor('dayu'), 'off')
assert.throws(() => tr.setBackend({ backend: 'magic' }), /后端不认识/)

// 3) 观察：只写事实，不写"他在挑衅你"
const msg = { id: 'g#1', at: '2026-10-26T14:00:00+08:00', name: '甲', text: '@她 你发一消息多少钱？？', atMe: true, media: 0 }
const ob = tr.observe(msg, { now: Date.parse('2026-10-26T14:05:00+08:00') })
assert.equal(ob.agoMinutes, 5)
assert.ok(ob.marks.includes('点了她的名'))
assert.ok(ob.marks.includes('在问问题'))
assert.equal(ob.text, msg.text, '原文要原样带着，不许改写')
assert.doesNotMatch(JSON.stringify(ob.marks), /挑衅|想追|生气/, '观察里不许有结论')

// 4) 没本地引擎：如实说不翻译，不编（本地引擎在跑就跳过这条——环境相关，不是逻辑）
const local0 = tr.probeLocal()
let out = null
if (local0.ready) {
  console.log('本地引擎在跑：跳过"没本地"这条')
} else {
  assert.equal(local0.ready, false)
  out = tr.translateBatch('dayu', [msg], { now: Date.parse('2026-10-26T14:05:00+08:00'), backend: 'hybrid' })
  assert.equal(out.translated, false)
  assert.match(out.note, /本地引擎没接上/)
  assert.equal(out.items.length, 1, '至少把观察给她')
}

// 5) off：只看账，不看内容
out = tr.translateBatch('dayu', [msg], { backend: 'off' })
assert.equal(out.translated, false)
assert.match(out.note, /后端关着/)

// 6) remote：不做本地翻译，交云端
out = tr.translateBatch('dayu', [msg], { backend: 'remote' })
assert.match(out.note, /交给云端读原文/)

// 7) 能力报告：本地不在就老实说会留在 remote；本地在跑就如实说能本地翻
const cap = tr.capabilityReport()
assert.equal(cap.canRun, local0.ready ? 'hybrid' : 'remote')
assert.match(cap.note, local0.ready ? /本地可用/ : /不会假装/)

// 8) 请求格式规范化：角色只留三种、内容压纯文本、空消息丢掉（2026-10-30）
const norm = tr.normalizeMessages([
  { role: 'USER', content: [{ text: '你好' }, { text: ' 世界 ' }] },
  { role: 'tool', content: '不该被发出去' },
  { role: 'assistant', content: '   ' },
])
assert.deepEqual(norm, [{ role: 'user', content: '你好 世界' }])
assert.equal(tr.pickLocalText({ choices: [{ message: { content: [{ text: 'a' }, { text: 'b' }] } }] }), 'ab')
assert.equal(tr.pickLocalText({ choices: [{ message: { content: ' c ' } }] }), 'c')
fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, backends: true, perRole: true, observeOnly: true, noFake: true, honestOff: true }))
