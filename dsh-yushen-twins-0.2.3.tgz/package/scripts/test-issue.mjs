// 手册发放：她们签发；自己没接上鱼神，不发。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-issue-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const pg = await import('../lib/plug.js')
const is = await import('../lib/issue.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-27T19:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 以身作则：自己没接上鱼神，不许签发
assert.throws(() => is.issueHandbook(ROLE, { to: 'worker', now: NOW }), /还没接入鱼神/)

// 2) 接上之后：签发一本，留底（给谁、什么任务、哪些章、到哪天）
pg.markPlugged(ROLE, { now: NOW })
assert.throws(() => is.issueHandbook(ROLE, { now: NOW }), /发给谁/)
const row = is.issueHandbook(ROLE, { to: 'worker', task: '修 bug', chapters: ['第十章', '查重与复用'], expiresAt: NOW + 86400000, now: NOW })
assert.equal(row.issuer, ROLE)
assert.equal(row.to, 'worker')
assert.match(row.chapters.join(','), /第十章/)
const list = is.listIssued(ROLE, { now: NOW })
assert.equal(list.length, 1)
assert.equal(list[0].expired, false)

// 3) 过期会被标出来
const later = NOW + 2 * 86400000
assert.equal(is.listIssued(ROLE, { now: later })[0].expired, true)
assert.match(is.issuedLine(ROLE, { now: later }), /过期/)

// 4) 没发过：注入为空
assert.equal(is.issuedLine('xiaoyu', { now: NOW }), '')

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, needsPlugged: true, logs: true, expiry: true, empty: true }))
