import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-mobile-'))
const old = process.env.DSH_HOME
process.env.DSH_HOME = home
try {
  const { createMobileGateway } = await import('../lib/mobile-gateway.js?test=' + Date.now())
  const gateway = createMobileGateway()
  const pairing = gateway.issuePairing()
  assert.match(pairing.code, /^\d{6}$/)
  assert.throws(() => gateway.pair({ code: '000000' }), /无效或已过期/)
  const device = gateway.pair({ code: pairing.code, name: '老板安卓手机' })
  assert.ok(device.token)
  assert.equal(gateway.authenticate(device.token).name, '老板安卓手机')
  assert.deepEqual(gateway.listDevices().map((d) => d.name), ['老板安卓手机'])
  assert.equal(gateway.validateRole('dragon'), 'dragon')
  assert.throws(() => gateway.validateRole('qq'), /未知角色/)
  gateway.revoke(device.deviceId)
  assert.equal(gateway.authenticate(device.token), null)
  console.log('移动网关：一次性配对、独立设备令牌、撤销、角色隔离通过')
} finally {
  if (old === undefined) delete process.env.DSH_HOME
  else process.env.DSH_HOME = old
  fs.rmSync(home, { recursive: true, force: true })
}
