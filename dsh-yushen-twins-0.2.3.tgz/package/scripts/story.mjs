// 故事：老板和引路人的对话摘要，给她们好奇时翻。零模型、只读。
// 用法：ELECTRON_RUN_AS_NODE=1 "<exe>" scripts/story.mjs list|read [关键词]
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DIR = path.join(HOME, 'dayu', 'story')
const args = process.argv.slice(2)
const action = args[0] || 'list'
const rest = args.slice(1).join(' ').trim()

function files() {
  try { return fs.readdirSync(DIR).filter((n) => n.endsWith('.md')).sort().reverse() } catch { return [] }
}

if (action === 'list') {
  console.log(JSON.stringify({ ok: true, dir: DIR, items: files() }, null, 2))
} else if (action === 'read') {
  const list = files()
  const name = list.find((n) => n.includes(rest)) || list[0]
  if (!name) { console.log(JSON.stringify({ ok: false, error: '还没有故事' })); process.exit(3) }
  console.log(fs.readFileSync(path.join(DIR, name), 'utf8'))
} else {
  console.error('用法：list | read [关键词]')
  process.exitCode = 2
}
