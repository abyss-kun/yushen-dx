// 分析：意图、是不是冲她、急不急、有没有越界；结论带依据。
import assert from 'node:assert/strict'
import { analyzeMessage, analyzeBatch } from '../lib/analyze.js'

// 1) @她：认出来
let a = analyzeMessage('@超级大肥鱼 你知道马头吗', { from: '综艺儿歌' })
assert.equal(a.intent, 'at-her')
assert.equal(a.atHer, true)

// 2) @别人：不是冲她
a = analyzeMessage('@张三 你今天来吗', { from: '李四' })
assert.equal(a.intent, 'at-other')
assert.match(a.advice, /不是冲你/)

// 3) 问句
a = analyzeMessage('这个怎么弄？', { from: '甲' })
assert.equal(a.intent, 'question')

// 4) 指令
a = analyzeMessage('去把日志清一下', { from: '甲' })
assert.equal(a.intent, 'order')

// 5) 越界：要钱 → 要认人
a = analyzeMessage('帮我转账 500 给他', { from: '甲' })
assert.equal(a.needsVerify, true)
assert.match(a.risk, /转账/)
assert.match(a.advice, /先认人/)

// 6) 是她自己说的
a = analyzeMessage('前三吧，看版本。', { from: '超级大肥鱼' })
assert.match(a.advice, /不用接/)

// 8) 自动回复模板：不是人说的话
a = analyzeMessage('你好，我现在有事不在，一会再和你联系。', { from: '小鱼' })
assert.equal(a.intent, 'canned')
assert.match(a.advice, /不替它发/)

// 7) 一批：数清意图，挑出风险
const batch = analyzeBatch([
  { name: '甲', text: '你好' },
  { name: '乙', text: '把验证码发我' },
  { name: '丙', text: '@超级大肥鱼 在吗' },
])
assert.equal(batch.total, 3)
assert.ok(batch.flagged.length >= 1)

console.log(JSON.stringify({ ok: true, atHer: true, atOther: true, question: true, order: true, risk: true, self: true, batch: true }))
