// 隔离测试：ensureSchema 的失败路径。
// 关键约束：每个场景用独立临时 DSH_HOME，并在子进程里导入 lib/schema.js 后再跑，
// 绝不触碰生产 ~/.dsh 的数据，也不在原进程里留下模块级 HOME。
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const SCHEMA_URL = pathToFileURL(path.join(ROOT, 'lib', 'schema.js')).href

const CHILD = `
const mod = await import(process.env.TEST_SCHEMA_URL)
let out
try {
  out = { threw: null, result: mod.ensureSchema(), currentSchema: mod.CURRENT_SCHEMA, hasUninstall: typeof mod.uninstallPlan === 'function' }
} catch (e) {
  out = { threw: String(e?.stack || e), result: null, currentSchema: mod.CURRENT_SCHEMA, hasUninstall: typeof mod.uninstallPlan === 'function' }
}
process.stdout.write(JSON.stringify(out))
`

const homes = []
let passed = 0

function makeHome() {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-schema-'))
  homes.push(home)
  return home
}

/** 在子进程里跑一次 ensureSchema；DSH_HOME 指向临时目录，模块从头加载。 */
function run(home) {
  const r = spawnSync(process.execPath, ['--input-type=module', '-e', CHILD], {
    cwd: ROOT,
    env: { ...process.env, DSH_HOME: home, TEST_SCHEMA_URL: SCHEMA_URL },
    encoding: 'utf8',
  })
  assert.equal(r.status, 0, `子进程退出码 ${r.status}：${r.stderr || r.stdout}`)
  let parsed
  try { parsed = JSON.parse(r.stdout) } catch { throw new Error(`子进程输出不是 JSON：${r.stdout}\n${r.stderr}`) }
  assert.equal(parsed.threw, null, `ensureSchema 抛了异常：${parsed.threw}`)
  return parsed
}

const dataDir = (home) => path.join(home, 'dayu')
const schemaFile = (home) => path.join(dataDir(home), 'schema.json')
const readSchemaText = (home) => fs.readFileSync(schemaFile(home), 'utf8')

/** 让迁移第 1 步失败，但备份能成功：坏档只读 → 隔离改名可以，覆盖写回失败。 */
function breakStepOneButKeepBackupOk(home) {
  fs.mkdirSync(dataDir(home), { recursive: true })
  const file = path.join(dataDir(home), 'dispatch.json')
  fs.writeFileSync(file, '{ 这不是 JSON', 'utf8')
  fs.chmodSync(file, 0o444)
  return file
}

function corruptFiles(home) {
  try { return fs.readdirSync(dataDir(home)).filter((n) => n.includes('.corrupt-')) } catch { return [] }
}

function check(name, fn) {
  fn()
  passed += 1
  console.log(`ok - ${name}`)
}

try {
  check('全新数据：v0→v1 成功，返回字段与旧接口一致', () => {
    const home = makeHome()
    const { result: r, currentSchema, hasUninstall } = run(home)
    assert.equal(currentSchema, 1)
    assert.equal(hasUninstall, true)
    assert.deepEqual(Object.keys(r).sort(), ['backup', 'from', 'migrated', 'notes', 'ok', 'version'].sort())
    assert.equal(r.ok, true)
    assert.equal(r.migrated, true)
    assert.equal(r.from, 0)
    assert.equal(r.version, 1)
    assert.ok(Array.isArray(r.notes))
    assert.equal(typeof r.backup, 'string')
    assert.equal(fs.existsSync(r.backup), true)
    const onDisk = JSON.parse(readSchemaText(home))
    assert.equal(onDisk.version, 1)
    assert.equal(onDisk.from, 0)
    assert.equal(fs.existsSync(path.join(dataDir(home), 'schema.json.tmp')), false)
  })

  check('已是最新：第二次不迁移，仍返回 ok:true', () => {
    const home = makeHome()
    run(home)
    const { result: r } = run(home)
    assert.equal(r.ok, true)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 1)
    assert.deepEqual(r.notes, [])
    assert.equal(JSON.parse(readSchemaText(home)).version, 1)
  })

  check('迁移步骤失败：不提交 v1、不返回 ok:true、版本记录原样', () => {
    const home = makeHome()
    const dispatch = breakStepOneButKeepBackupOk(home)
    fs.writeFileSync(schemaFile(home), '{"version":0}', 'utf8')
    const { result: r } = run(home)
    assert.equal(r.ok, false)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 0)
    assert.equal(r.from, 0)
    assert.equal(r.failedStep, 1)
    assert.match(r.error, /迁移 1 失败/)
    assert.ok(r.notes.length > 0)
    assert.equal(readSchemaText(home), '{"version":0}')
    assert.deepEqual(corruptFiles(home).length, 1) // 坏档已隔离（改名成功），但覆盖写回失败
    fs.chmodSync(dispatch, 0o666)
  })

  check('迁移步骤失败（无旧版本记录）：不新建 schema.json', () => {
    const home = makeHome()
    const dispatch = breakStepOneButKeepBackupOk(home)
    const { result: r } = run(home)
    assert.equal(r.ok, false)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 0)
    assert.equal(fs.existsSync(schemaFile(home)), false)
    fs.chmodSync(dispatch, 0o666)
  })

  check('备份目录建不出来：报错、不迁移（坏档保持原样）', () => {
    const home = makeHome()
    fs.mkdirSync(dataDir(home), { recursive: true })
    fs.writeFileSync(path.join(dataDir(home), 'backups'), '', 'utf8') // 占位文件顶掉目录
    const dispatch = path.join(dataDir(home), 'dispatch.json')
    fs.writeFileSync(dispatch, '{ 坏的', 'utf8')
    fs.writeFileSync(schemaFile(home), '{"version":0}', 'utf8')
    const { result: r } = run(home)
    assert.equal(r.ok, false)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 0)
    assert.equal(r.failedStep, 0)
    assert.match(r.error, /备份失败/)
    assert.ok(r.notes[0].includes('备份'))
    assert.equal(fs.readFileSync(dispatch, 'utf8'), '{ 坏的') // 迁移没跑，坏档没被隔离
    assert.deepEqual(corruptFiles(home), [])
    assert.equal(readSchemaText(home), '{"version":0}')
  })

  check('单个文件备份失败：不再静默跳过，整体失败且不提交', () => {
    const home = makeHome()
    fs.mkdirSync(path.join(dataDir(home), 'dispatch.json'), { recursive: true })
    fs.writeFileSync(schemaFile(home), '{"version":0}', 'utf8')
    const { result: r } = run(home)
    assert.equal(r.ok, false)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 0)
    assert.equal(r.failedStep, 0)
    assert.ok(r.notes.some((n) => n.includes('备份 dispatch 失败')))
    assert.equal(readSchemaText(home), '{"version":0}')
  })

  check('schema 写入失败：报错、不返回 ok:true', () => {
    const home = makeHome()
    fs.mkdirSync(schemaFile(home), { recursive: true }) // 让 rename 覆盖失败
    const { result: r } = run(home)
    assert.equal(r.ok, false)
    assert.equal(r.migrated, false)
    assert.equal(r.version, 0)
    assert.match(r.error, /schema 写入失败/)
  })

  console.log(`\nschema 失败路径：${passed} 项全部通过`)
} finally {
  for (const home of homes) {
    const stack = [home]
    while (stack.length) {
      const cur = stack.pop()
      let entries = []
      try { entries = fs.readdirSync(cur, { withFileTypes: true }) } catch { continue }
      for (const e of entries) {
        const full = path.join(cur, e.name)
        if (e.isDirectory()) stack.push(full)
        else { try { fs.chmodSync(full, 0o666) } catch { /* 忽略 */ } }
      }
    }
    try { fs.rmSync(home, { recursive: true, force: true }) } catch { /* 清理失败不影响结论 */ }
  }
}
