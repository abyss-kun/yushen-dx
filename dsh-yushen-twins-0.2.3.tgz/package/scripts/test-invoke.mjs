// 她调用模型：只有她请求才起回合；预算按天算；同一件事有冷却。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-invoke-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const ag = await import('../lib/agenda.js')
const inv = await import('../lib/invoke.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T16:00:00+08:00')
rt.ensureRuntime(ROLE)
// 接入鱼神（读过一次规则）：真实流程里是简报先跑过
const plug = await import('../lib/plug.js')
plug.markPlugged(ROLE, { now: NOW })

const item = ag.addItem(ROLE, { what: '弄清那个 BV 讲了什么', why: '群里吵起来了', nextKind: 'ask-model', now: NOW })

// 1) 一次请求 = 一次额度，状态 pending
let req = inv.requestInvocation(ROLE, { agendaId: item.id, why: '想知道', now: NOW, perDay: 3 })
assert.equal(req.status, 'pending')
assert.equal(req.budget.left, 2, '请求时就要扣一次')

// 2) 上一次没走完，不许再排
assert.throws(() => inv.requestInvocation(ROLE, { agendaId: item.id, now: NOW + 1000, perDay: 3 }), /还没走完/)

// 3) 取出来 → running；重复取拿不到
const taken = inv.takeInvocation(ROLE, { now: NOW + 2000, perDay: 3 })
assert.equal(taken.id, req.id)
assert.equal(inv.takeInvocation(ROLE, { now: NOW + 3000, perDay: 3 }), null)

// 4) 跑完了：落 started
inv.finishInvocation(ROLE, req.id, { status: 'started', sessionId: 'session-x', now: NOW + 4000 })
let b = inv.budgetOf(ROLE, { now: NOW + 5000, perDay: 3 })
assert.equal(b.used, 1)
assert.equal(b.left, 2)

// 5) 冷却取消了：她想再发起就再发起（三问第 2 条）；只防"上一次没走完"
const again = inv.requestInvocation(ROLE, { agendaId: item.id, now: NOW + 6000, perDay: 3 })
assert.equal(again.status, 'pending')
inv.finishInvocation(ROLE, again.id, { status: 'failed', note: '测试取消', now: NOW + 6500 })

// 5.5) 额度不够可以申请（批不批是主人的事）
const asked = inv.requestMoreBudget(ROLE, { why: '想再想一次', now: NOW + 7000, perDay: 3 })
assert.ok(asked.budget.used >= 1)
assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'runtime', ROLE, 'budget-requests.jsonl')))

// 6) 额度用完就挡住（perDay=1）
const item2 = ag.addItem(ROLE, { what: '第二件', nextKind: 'write', now: NOW + 7000 })
assert.throws(() => inv.requestInvocation(ROLE, { agendaId: item2.id, now: NOW + 3600000, perDay: 1, cooldownMin: 30 }), /额度|开得太多/)

// 7) 已结的事不能再花模型
const done = ag.updateItem(ROLE, item2.id, { state: 'done' }, { now: NOW + 8000 })
assert.equal(done.state, 'done')
assert.throws(() => inv.requestInvocation(ROLE, { agendaId: item2.id, now: NOW + 2 * 3600000, perDay: 5, cooldownMin: 1 }), /已经结了/)

// 8) 提示词是"你自己的事"，不是老板派的
const prompt = inv.buildInvocationPrompt(ROLE, { item, why: '想知道' })
assert.match(prompt, /你自己的事/)
assert.match(prompt, /不是谁派的/)
assert.match(prompt, /放弃也算数/)
assert.doesNotMatch(prompt, /主人要求|老板让你/)

// 9) 不碰桥
assert.equal(fs.existsSync(path.join(HOME, 'bridge')), false)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, budget: true, singleFlight: true, canReask: true, askBudget: true, closedItem: true, promptHers: true }))
