// 改动记录与结构对账：每改一次框架，落一条记录 + 一份结构指纹。
//
// 目的（2026-10-30 老板定）：框架一开始是固定的；每改一处，都有对应记录。
// 如果重新检索时结构和记录不一致，就说明「没有记录对」——必须补记录，而不是继续改。
//
// 用法：
//   node scripts/framework-record.mjs snapshot --why "改了什么、为什么" [--files a,b] [--note "..."]
//   node scripts/framework-record.mjs check        # 结构变了但没记录 → 退出码 1
//   node scripts/framework-record.mjs list
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const FILE = path.join(ROOT, 'docs', '改动记录.jsonl')
const WATCH = ['lib', 'core', 'dayu', 'xiaoyu', 'adapters', 'scripts', 'client.js', 'index.js']

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name)
    if (e.isDirectory()) { if (!/node_modules|dist|archive|\.state|\.git/.test(p)) walk(p, out) } else if (/\.(js|mjs)$/.test(e.name)) out.push(p)
  }
  return out
}

function structure() {
  const files = []
  for (const w of WATCH) {
    const abs = path.join(ROOT, w)
    if (!fs.existsSync(abs)) continue
    if (fs.statSync(abs).isDirectory()) walk(abs, files)
    else files.push(abs)
  }
  const map = {}
  for (const f of files.sort()) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/')
    const text = fs.readFileSync(f, 'utf8')
    map[rel] = crypto.createHash('sha1').update(text).digest('hex').slice(0, 12)
  }
  return map
}

function gitCommit() {
  try { return execFileSync('git', ['-C', ROOT, 'rev-parse', '--short', 'HEAD'], { encoding: 'utf8' }).trim() } catch { return '' }
}

function readLog() {
  try {
    return fs.readFileSync(FILE, 'utf8').trim().split(/\r?\n/).filter(Boolean).map((l) => JSON.parse(l))
  } catch { return [] }
}

function arg(name) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 ? String(process.argv[i + 1] || '') : ''
}


// ── 生成《框架现状》：后人只读这一份，就知道结构、谁改了什么、结果怎样 ──────────
import { fileURLToPath as _fu } from 'node:url'

function headLine(abs) {
  try {
    const lines = fs.readFileSync(abs, 'utf8').split(/\r?\n/).slice(0, 6)
    const hit = lines.find((l) => l.trim().startsWith('//') && !/Copyright/.test(l)) || ''
    return hit.replace(/^\s*\/\/\s*/, '').slice(0, 60)
  } catch { return '' }
}

function counts() {
  const src = fs.existsSync(path.join(ROOT, 'dayu', 'index.js')) ? fs.readFileSync(path.join(ROOT, 'dayu', 'index.js'), 'utf8') : ''
  const tools = new Set([...src.matchAll(/name:\s*'((?:yushen|dayu)_[a-z_]+)'/g)].map((m) => m[1]))
  const routes = new Set([...src.matchAll(/route\s*===\s*'([^']+)'/g)].map((m) => m[1]))
  const docs = fs.existsSync(path.join(ROOT, 'docs')) ? fs.readdirSync(path.join(ROOT, 'docs')).filter((f) => f.endsWith('.md')).length : 0
  const scripts = fs.existsSync(path.join(ROOT, 'scripts')) ? fs.readdirSync(path.join(ROOT, 'scripts')).length : 0
  return { tools: tools.size, routes: routes.size, docs, scripts }
}

function renderState() {
  const log = readLog()
  const last = log.at(-1)
  const now = structure()
  const c = counts()
  // 未接线：没有任何 .js/.mjs 引用（近似：文件名字符串没在别处出现）
  const allText = []
  for (const rel of Object.keys(now)) { try { allText.push(fs.readFileSync(path.join(ROOT, rel), 'utf8')) } catch { /* 忽略 */ } }
  const blob = allText.join('\n')
  const orphans = Object.keys(now).filter((rel) => {
    const base = path.basename(rel).replace(/\.js$/, '')
    if (!rel.startsWith('lib/')) return false
    const hits = blob.split(`/${base}.js`).length - 1 + blob.split(`'./${base}.js'`).length - 1
    return hits <= 0
  })
  const byDir = {}
  for (const rel of Object.keys(now)) {
    const d = rel.split('/')[0]
    byDir[d] = (byDir[d] || 0) + 1
  }
  const L = []
  L.push('# 框架现状（自动生成，读这一份就够）')
  L.push('')
  L.push(`> 生成：${new Date().toISOString()}　提交：${last?.commit || '无'}　结构：${Object.keys(now).length} 个文件`)
  L.push('> 这份文件由 `scripts/framework-record.mjs` 生成，**不要手改**；改框架后跑一次 snapshot 会同步更新。')
  L.push('')
  L.push('## 一、现在是什么样')
  L.push('')
  L.push(`- 模块：${Object.entries(byDir).map(([d, n]) => `${d} ${n}`).join(' · ')}`)
  L.push(`- 工具 ${c.tools} 个 · 路由 ${c.routes} 条 · 脚本 ${c.scripts} 个 · 文档 ${c.docs} 份`)
  L.push(`- 最近一次改动：${last?.at?.slice(0, 16) || '无'}　${last?.why || ''}`)
  L.push('')
  L.push('## 二、分层与职责（每行取文件头第一句）')
  L.push('')
  for (const dir of ['core', 'lib', 'dayu', 'xiaoyu', 'adapters']) {
    const rows = Object.keys(now).filter((r) => r.startsWith(dir + '/')).sort()
    if (!rows.length) continue
    L.push(`### ${dir}/（${rows.length}）`)
    L.push('')
    L.push('| 文件 | 一句话 |')
    L.push('|---|---|')
    for (const rel of rows) L.push(`| \`${rel.slice(dir.length + 1)}\` | ${headLine(path.join(ROOT, rel)) || '（无头注释）'} |`)
    L.push('')
  }
  L.push('## 三、最近的改动（谁改的、改了什么、结果）')
  L.push('')
  L.push('| 时间 | 提交 | 谁 | 改了 | 为什么 |')
  L.push('|---|---|---|---:|---|')
  for (const row of log.slice(-15).reverse()) L.push(`| ${row.at.slice(0, 16)} | ${row.commit || '-'} | ${(row.changed || []).length} | ${String(row.why || '').slice(0, 80)} |`)
  L.push('')
  L.push('## 四、没接线的模块（写了但没人调用）')
  L.push('')
  L.push(orphans.length ? orphans.map((o) => `- \`${o}\``).join('\n') : '（无）')
  L.push('')
  L.push('## 五、人工备注')
  L.push('')
  const manual = path.join(ROOT, 'docs', '框架现状-人工.md')
  if (fs.existsSync(manual)) L.push(fs.readFileSync(manual, 'utf8').trim())
  else L.push('（没有 `docs/框架现状-人工.md`；风险、待办、历史原因写在那里，会合并进这份。）')
  L.push('')
  const out = path.join(ROOT, 'docs', '框架现状.md')
  fs.writeFileSync(out, L.join('\n'), 'utf8')
  return out
}
const cmd = process.argv[2] || 'check'
const now = structure()

if (cmd === 'snapshot') {
  const why = arg('why')
  if (!why) { console.error('要写 --why：这次改了什么、为什么'); process.exit(2) }
  const prev = readLog().at(-1)
  const changed = []
  for (const [f, h] of Object.entries(now)) if (!prev || !prev.structure || prev.structure[f] !== h) changed.push(f)
  if (prev) for (const f of Object.keys(prev.structure || {})) if (!(f in now)) changed.push(`${f}（已删除）`)
  const entry = {
    at: new Date().toISOString(),
    commit: gitCommit(),
    why,
    author: arg('author') || '未标注',
    note: arg('note'),
    files: (arg('files') ? arg('files').split(',') : changed).map((s) => s.trim()).filter(Boolean),
    changed,
    count: Object.keys(now).length,
    structure: now,
  }
  fs.mkdirSync(path.dirname(FILE), { recursive: true })
  fs.appendFileSync(FILE, JSON.stringify(entry) + '\n', 'utf8')
  console.log(`已记录：改了 ${changed.length} 个文件；结构共 ${entry.count} 个；commit ${entry.commit || '(无)'}`)
  console.log(changed.slice(0, 20).join('\n'))
  process.exit(0)
}

if (cmd === 'render') { console.log('已更新：' + path.relative(ROOT, renderState())); process.exit(0) }

if (cmd === 'list') {
  for (const row of readLog().slice(-10)) {
    console.log(`${row.at.slice(0, 16)}  ${row.commit || '-'}  ${row.count} 文件  ${row.why}`)
  }
  process.exit(0)
}

// check：结构变了但最后一条记录里没有 → 说明没记
const last = readLog().at(-1)
if (!last) {
  console.error('还没有任何改动记录（docs/改动记录.jsonl 不存在或为空）。先跑 snapshot --why "..."')
  process.exit(1)
}
const drift = []
for (const [f, h] of Object.entries(now)) if (last.structure[f] !== h) drift.push(f)
for (const f of Object.keys(last.structure || {})) if (!(f in now)) drift.push(`${f}（已删除）`)
if (drift.length) {
  console.error(`结构对不上：有 ${drift.length} 个文件变了，但没有对应记录。`)
  console.error(drift.slice(0, 30).join('\n'))
  console.error('\n补记录：node scripts/framework-record.mjs snapshot --why "改了什么、为什么"')
  process.exit(1)
}
console.log(`结构对账通过：${Object.keys(now).length} 个文件，与最后一条记录一致（${last.at.slice(0, 16)}）。`)
