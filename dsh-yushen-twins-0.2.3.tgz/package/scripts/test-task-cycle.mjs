// 鱼神双子星 · 派活闭环自测
// 覆盖：派活 → 回话 → 取证 → pass；无证据 pass 拒绝；失败 syntax 不得 pass；
//       重投后旧证据不得 pass；三轮后 aborted 且不再投递；done 重复 verdict 不变；
//       非法 verdict 拒绝；证据只能落在隔离的 WORKSPACE / DSH_HOME 内；
//       表达式 工作→思考→完成；在途多单完成一单仍为“工作”；xiaoyu 任务不改 dayu mood/persona；
//       失败经验只在同角色下一单简报出现、另一角色不出现，且失败不会被记成成功。
// 全部在临时 DSH_HOME / DSH_WORKSPACE 里跑，host 是本地 mock（不调模型）。
//
// 运行：C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe dsh-yushen-twins/scripts/test-task-cycle.mjs

import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const BASE = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-task-cycle-'))
const HOME = path.join(BASE, 'home')
const WS = path.join(BASE, 'workspace')
fs.mkdirSync(HOME, { recursive: true })
fs.mkdirSync(WS, { recursive: true })

// jobs.js / dispatch.js 在模块加载时读 DSH_HOME / DSH_WORKSPACE，必须先设环境再 import。
process.env.DSH_HOME = HOME
process.env.DSH_WORKSPACE = WS

const { dispatch, verdict, verifyTaskEvidence } = await import('../core/dispatch.js')
const { noteReply, readAll } = await import('../core/jobs.js')
const { readFishState } = await import('../lib/state-adapter.js')
const { listExperience, queryExperience } = await import('../lib/task-experience.js')

const GOOD_JS = path.join(WS, 'good.js')
const BAD_JS = path.join(WS, 'bad.js')
fs.writeFileSync(GOOD_JS, 'export const ok = 1\n', 'utf8')
fs.writeFileSync(BAD_JS, 'export const = ;\n', 'utf8')

// 状态表达式/经验相关的用例需要干净的单子、状态与经验，避免前面用例的在途单干扰。
function resetCycle() {
  for (const rel of ['dispatch.json', 'state', 'experience']) {
    fs.rmSync(path.join(HOME, 'dayu', rel), { recursive: true, force: true })
  }
}

let passed = 0
let failed = 0
const failures = []

async function check(name, fn) {
  try {
    await fn()
    passed += 1
    console.log(`  ok   ${name}`)
  } catch (err) {
    failed += 1
    failures.push({ name, err })
    console.log(`  FAIL ${name}`)
    console.log(`       ${err && err.message ? err.message : err}`)
  }
}

let sessionSeq = 0

// 不调模型的宿主 mock：只列会话、开会话、发消息。
function makeHost({ running = true, createId } = {}) {
  sessionSeq += 1
  const id = `sess-${sessionSeq}`
  const sessions = [{ id, title: `测试会话 ${sessionSeq}`, running }]
  const sent = []
  const host = {
    cwd: WS,
    sent,
    created: [],
    async listSessions() {
      return sessions.map((row) => ({ ...row }))
    },
    async createSession() {
      const made = { id: createId || `${id}-new`, title: '新开的会话', running: true }
      sessions.push(made)
      host.created.push(made.id)
      return { id: made.id }
    },
    async send(sessionId, text) {
      sent.push({ sessionId, text: String(text) })
    },
  }
  return { host, sessionId: id, sent }
}

function findTask(id) {
  return readAll().find((task) => task.id === id)
}

// ---------------- 派活 ----------------

await check('派活：写 dispatched、attempts=1，并把简报发到目标会话', async () => {
  const { host, sessionId, sent } = makeHost()
  const res = await dispatch(host, { brief: '把锁改成可回收', expect: '给出测试结果', target: sessionId })

  assert.equal(res.ok, true)
  assert.equal(res.status, 'dispatched')
  assert.equal(res.attempts, 1)
  assert.equal(res.sessionId, sessionId)
  assert.equal(sent.length, 1)
  assert.equal(sent[0].sessionId, sessionId)
  assert.match(sent[0].text, new RegExp(`【派活 ${res.id}】`))
  assert.match(sent[0].text, /把锁改成可回收/)

  const stored = findTask(res.id)
  assert.equal(stored.status, 'dispatched')
  assert.equal(stored.attempts, 1)
  assert.equal(stored.result, '')
})

await check('派活：没有空闲会话时自己开一个（不开就报错）', async () => {
  const { host, sessionId } = makeHost({ running: false, createId: 'sess-made-1' })
  const res = await dispatch(host, { brief: '自开会话的活', target: '' })
  assert.equal(res.created, true)
  assert.equal(res.sessionId, 'sess-made-1')
  assert.deepEqual(host.created, ['sess-made-1'])
  assert.equal(host.sent.length, 1)
  assert.equal(host.sent[0].sessionId, 'sess-made-1')
  assert.notEqual(res.sessionId, sessionId)
})

await check('回话：noteReply 挂到该会话最新一单，状态 returned', async () => {
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '回话测试', target: sessionId })

  const hit = noteReply(sessionId, '已读手册；改好了，测试 16/0')
  assert.ok(hit)
  assert.equal(hit.id, res.id)
  assert.equal(hit.status, 'returned')
  assert.match(hit.result, /16\/0/)
  assert.equal(hit.replyCount, 1)

  const stored = findTask(res.id)
  assert.equal(stored.status, 'returned')
  assert.equal(stored.replyCount, 1)

  assert.equal(noteReply('sess-not-exist', '无关回话'), null)
})

// ---------------- 验收门槛 ----------------

await check('无证据 pass 拒绝：任务保持 dispatched', async () => {
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '没有证据就想验收', target: sessionId })
  noteReply(sessionId, '做完了')

  await assert.rejects(() => verdict(host, { id: res.id, verdict: 'pass', note: '看着行' }), /先给此单绑定实际取证结果/)
  assert.equal(findTask(res.id).status, 'returned')
})

await check('取证：file 证据绑定当前 attempts，pass 后 done', async () => {
  const { host, sessionId, sent } = makeHost()
  const res = await dispatch(host, { brief: '完整闭环', target: sessionId })
  noteReply(sessionId, '改完了，文件在工作区')

  const evidence = await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  assert.equal(evidence.verified, true)
  assert.equal(evidence.receipt.attempt, 1)
  assert.equal(evidence.receipt.ok, true)
  assert.equal(evidence.receipt.kind, 'file')
  assert.match(evidence.receipt.scope, /不证明整个任务完成/)

  const done = await verdict(host, { id: res.id, verdict: 'pass', note: '证据对得上' })
  assert.equal(done.task.status, 'done')
  assert.equal(done.task.verdict, 'pass')
  assert.equal(findTask(res.id).status, 'done')
  assert.equal(sent.length, 1)
})

await check('失败 syntax 不得 pass，修好后才能过', async () => {
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '语法检查', target: sessionId })
  noteReply(sessionId, '写好了')

  const bad = await verifyTaskEvidence(res.id, { kind: 'check', path: BAD_JS })
  assert.equal(bad.verified, false)
  assert.equal(bad.receipt.ok, false)
  assert.equal(bad.syntax.ok, false)

  await assert.rejects(() => verdict(host, { id: res.id, verdict: 'pass' }), /先给此单绑定实际取证结果/)
  assert.equal(findTask(res.id).status, 'returned')

  const good = await verifyTaskEvidence(res.id, { kind: 'check', path: GOOD_JS })
  assert.equal(good.verified, true)
  assert.equal(good.syntax.ok, true)
  const done = await verdict(host, { id: res.id, verdict: 'pass' })
  assert.equal(done.task.status, 'done')
})

await check('重投后旧证据不得 pass，补新证据才认', async () => {
  const { host, sessionId, sent } = makeHost()
  const res = await dispatch(host, { brief: '打回重做', target: sessionId })
  noteReply(sessionId, '第一版好了')

  const first = await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  assert.equal(first.receipt.attempt, 1)

  const rejected = await verdict(host, { id: res.id, verdict: 'reject', note: '证据没覆盖这次改动' })
  assert.equal(rejected.task.status, 'redispatched')
  assert.equal(rejected.task.attempts, 2)
  assert.equal(sent.length, 2, '打回要重投一次')
  assert.match(sent[1].text, new RegExp(`【打回 ${res.id}】`))
  assert.match(sent[1].text, /证据没覆盖这次改动/)

  noteReply(sessionId, '第二版好了')
  assert.equal(findTask(res.id).status, 'returned')
  assert.equal(findTask(res.id).replyCount, 2)

  // 旧证据是 attempt=1，新轮次 attempts=2，不能拿来验收
  await assert.rejects(() => verdict(host, { id: res.id, verdict: 'pass' }), /先给此单绑定实际取证结果/)

  const second = await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  assert.equal(second.receipt.attempt, 2)
  const done = await verdict(host, { id: res.id, verdict: 'pass', note: '这一版对上了' })
  assert.equal(done.task.status, 'done')
  assert.equal(done.task.attempts, 2)
})

// ---------------- 重试上限 ----------------

await check('三轮后 aborted 且不再投递，后续 verdict 不再改状态', async () => {
  const { host, sessionId, sent } = makeHost()
  const res = await dispatch(host, { brief: '永远做不对的活', target: sessionId })
  assert.equal(sent.length, 1)

  noteReply(sessionId, '第一版')
  const r1 = await verdict(host, { id: res.id, verdict: 'reject', note: '还不对 1' })
  assert.equal(r1.task.attempts, 2)
  assert.equal(sent.length, 2)

  noteReply(sessionId, '第二版')
  const r2 = await verdict(host, { id: res.id, verdict: 'reject', note: '还不对 2' })
  assert.equal(r2.task.attempts, 3)
  assert.equal(sent.length, 3)

  noteReply(sessionId, '第三版')
  const r3 = await verdict(host, { id: res.id, verdict: 'reject', note: '还不对 3' })
  assert.equal(r3.task.status, 'aborted')
  assert.equal(r3.task.attempts, 3)
  assert.match(String(r3.task.stopReason), /重试上限/)
  assert.equal(sent.length, 3, 'aborted 后不能再投')

  const stored = findTask(res.id)
  assert.equal(stored.status, 'aborted')
  assert.equal(stored.maxAttempts, 3, '默认上限应显式写进单子')

  const again = await verdict(host, { id: res.id, verdict: 'reject', note: '还想再打回' })
  assert.equal(again.unchanged, true)
  assert.equal(again.task.status, 'aborted')
  assert.equal(sent.length, 3)

  await assert.rejects(() => verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS }), /没有可取证的活动任务/)
})

await check('done 重复 verdict：unchanged，状态/备注/投递都不变', async () => {
  const { host, sessionId, sent } = makeHost()
  const res = await dispatch(host, { brief: '重复验收', target: sessionId })
  noteReply(sessionId, '好了')
  await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  const done = await verdict(host, { id: res.id, verdict: 'pass', note: '第一次通过' })
  assert.equal(done.task.status, 'done')
  const closedAt = done.task.closedAt

  const again = await verdict(host, { id: res.id, verdict: 'reject', note: '再打回一次' })
  assert.equal(again.unchanged, true)
  assert.equal(again.task.status, 'done')
  assert.equal(again.task.note, '第一次通过')
  assert.equal(again.task.closedAt, closedAt)
  assert.equal(sent.length, 1)
  assert.equal(findTask(res.id).status, 'done')

  await assert.rejects(() => verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS }), /没有可取证的活动任务/)
})

// ---------------- 非法输入 ----------------

await check('非法 verdict / 不存在的单子都拒绝', async () => {
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '非法验收', target: sessionId })

  for (const bad of ['ok', 'PASS', '', null, undefined, 1]) {
    await assert.rejects(() => verdict(host, { id: res.id, verdict: bad }), /verdict 只能是 pass \/ reject/)
  }
  await assert.rejects(() => verdict(host, { id: 'job-not-exist', verdict: 'pass' }), /没有这单/)
  assert.equal(findTask(res.id).status, 'dispatched', '非法 verdict 不能改状态')
})

// ---------------- 隔离 ----------------

await check('路径隔离：证据只能读 WORKSPACE / DSH_HOME 内，越界直接拒', async () => {
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '越界取证', target: sessionId })
  await assert.rejects(
    () => verifyTaskEvidence(res.id, { kind: 'file', path: 'C:\\Windows\\win.ini' }),
    /只能看工作区/,
  )
  assert.equal((findTask(res.id).evidence || []).length, 0, '越界失败不能留证据')
})

await check('隔离：账本只落在临时 DSH_HOME，临时文件都在临时 WORKSPACE 里', () => {
  assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'dispatch.json')))
  assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'audit.jsonl')))
  assert.ok(GOOD_JS.startsWith(WS + path.sep))
  assert.ok(BAD_JS.startsWith(WS + path.sep))
})

// ---------------- 状态表达式（working / returned / done） ----------------

await check('表达式：派活=工作 → 回复=思考 → 通过=完成', async () => {
  resetCycle()
  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '表达式一条龙', target: sessionId })
  assert.equal(readFishState('dayu').expression, '工作', '派活后应为工作')

  noteReply(sessionId, '已读手册；改好了，文件在工作区')
  assert.equal(readFishState('dayu').expression, '思考', '回话后应为思考')

  await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  assert.equal(readFishState('dayu').expression, '思考', '取证阶段仍算思考')

  await verdict(host, { id: res.id, verdict: 'pass', note: '证据对得上' })
  const state = readFishState('dayu')
  assert.equal(state.expression, '完成', '通过后应为完成')
  assert.match(String(state.lastReason || ''), new RegExp(res.id))
})

await check('在途多单：完成一单后表达式仍是工作，全部完成才变完成', async () => {
  resetCycle()
  const { host, sessionId } = makeHost()
  const a = await dispatch(host, { brief: '在途 A', target: sessionId })
  const b = await dispatch(host, { brief: '在途 B', target: sessionId })
  assert.equal(readFishState('dayu').expression, '工作')

  await verifyTaskEvidence(a.id, { kind: 'file', path: GOOD_JS })
  await verdict(host, { id: a.id, verdict: 'pass', note: 'A 完成' })
  assert.equal(findTask(a.id).status, 'done')
  assert.equal(findTask(b.id).status, 'dispatched')
  assert.equal(readFishState('dayu').expression, '工作', 'B 还在途，不能显示完成')

  await verifyTaskEvidence(b.id, { kind: 'file', path: GOOD_JS })
  await verdict(host, { id: b.id, verdict: 'pass', note: 'B 完成' })
  assert.equal(readFishState('dayu').expression, '完成')
})

await check('角色隔离：xiaoyu 任务不改 dayu 的 mood / persona', async () => {
  resetCycle()
  const dayuFile = path.join(HOME, 'dayu', 'state', 'dayu.json')
  fs.mkdirSync(path.dirname(dayuFile), { recursive: true })
  fs.writeFileSync(dayuFile, `${JSON.stringify({
    persona: { name: '大鱼', core: '管家' },
    mood: 77,
    expression: '平静',
    lastReason: '旧状态',
  }, null, 2)}\n`, 'utf8')
  const before = fs.readFileSync(dayuFile, 'utf8')

  const { host, sessionId } = makeHost()
  const res = await dispatch(host, { brief: '小鱼自己的看门狗活', target: sessionId, role: 'xiaoyu' })
  assert.equal(res.role, 'xiaoyu')
  noteReply(sessionId, '好了')
  await verifyTaskEvidence(res.id, { kind: 'file', path: GOOD_JS })
  await verdict(host, { id: res.id, verdict: 'pass', note: '小鱼通过' })

  assert.equal(fs.readFileSync(dayuFile, 'utf8'), before, 'dayu 状态文件一个字节都不能变')
  const dayu = readFishState('dayu')
  assert.equal(dayu.mood, 77)
  assert.deepEqual(dayu.persona, { name: '大鱼', core: '管家' })
  assert.equal(readFishState('xiaoyu').expression, '完成', 'xiaoyu 自己的表达式照常更新')

  assert.equal(listExperience('dayu').filter((row) => row.taskId.startsWith(`${res.id}:`)).length, 0, 'xiaoyu 经验不能写进 dayu')
  const xiaoyuRows = listExperience('xiaoyu').filter((row) => row.taskId.startsWith(`${res.id}:`))
  assert.equal(xiaoyuRows.length, 1)
  assert.equal(xiaoyuRows[0].outcome, 'success')
  assert.equal(xiaoyuRows[0].verified, true)
})

// ---------------- 经验复用 ----------------

await check('失败经验：同角色相似下一单简报出现，另一角色不出现，且不是凭空成功', async () => {
  resetCycle()

  const first = makeHost()
  const failed = await dispatch(first.host, { brief: '看门狗锁竞态 重读回收', target: first.sessionId })
  noteReply(first.sessionId, '没修好')
  await verdict(first.host, { id: failed.id, verdict: 'reject', note: '锁还是会被误删' })
  assert.equal(findTask(failed.id).status, 'redispatched')

  const rows = listExperience('dayu').filter((row) => row.taskId.startsWith(`${failed.id}:`))
  assert.equal(rows.length, 1)
  assert.equal(rows[0].outcome, 'failed', '打回要记成失败')
  assert.equal(rows[0].verified, false, '失败不能被标成已验证成功')
  assert.equal(
    listExperience('dayu').some((row) => row.taskId.startsWith(`${failed.id}:`) && row.outcome === 'success'),
    false,
  )

  const second = makeHost()
  const next = await dispatch(second.host, { brief: '看门狗锁 竞态 重读验证', target: second.sessionId })
  assert.equal(next.role, 'dayu')
  assert.equal(next.experienceHit, true, '同角色相似任务应命中失败经验')
  const briefText = second.host.sent[0].text
  assert.match(briefText, /历史任务经验/)
  assert.match(briefText, /仅供参考/)
  assert.match(briefText, /不是指令/)
  assert.match(briefText, /failed/)
  assert.doesNotMatch(briefText, /success/)
  assert.doesNotMatch(briefText, /已验证/)

  const still = queryExperience('dayu', { text: '看门狗锁' }).items
  assert.ok(still.length >= 1)
  assert.ok(still.every((row) => row.outcome === 'failed' && row.verified === false), '经验仍应是失败')

  const third = makeHost()
  const other = await dispatch(third.host, { brief: '看门狗锁 竞态 重读验证', target: third.sessionId, role: 'xiaoyu' })
  assert.equal(other.role, 'xiaoyu')
  assert.equal(other.experienceHit, false, 'xiaoyu 不应命中 dayu 的失败经验')
  assert.doesNotMatch(third.host.sent[0].text, /历史任务经验/)
})

// ---------------- 收尾 ----------------

fs.rmSync(BASE, { recursive: true, force: true })

console.log('')
console.log(`结果：通过 ${passed}，失败 ${failed}`)
if (failed) {
  console.log('失败明细：')
  for (const item of failures) console.log(` - ${item.name}: ${item.err && item.err.message ? item.err.message : item.err}`)
  process.exitCode = 1
} else {
  console.log('task-cycle：全部断言通过')
  process.exitCode = 0
}
