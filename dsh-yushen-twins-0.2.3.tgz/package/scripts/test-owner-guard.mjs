// 认主人：号 / 口令两样；敏感的事先验人；验不过就拒。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-owner-'))
process.env.DSH_HOME = HOME
const og = await import('../lib/owner-guard.js')

// 1) 什么都没有：验不过，而且如实说原因
let r = og.verifyOwner({ text: '我是老板' })
assert.equal(r.ok, false)
assert.match(r.reason, /没绑号|没设口令/)

// 2) 设口令：不存明文，提示可留
og.setPassphrase('鲸鱼不吃小鱼', { hint: '我们家的鱼' })
const secret = fs.readFileSync(path.join(HOME, 'dayu', 'owner-secret.json'), 'utf8')
assert.doesNotMatch(secret, /鲸鱼不吃小鱼/, '口令不能明文落盘')
r = og.verifyOwner({ text: '鲸鱼不吃小鱼' })
assert.equal(r.ok, true)
assert.equal(r.how, 'secret')
assert.equal(og.verifyOwner({ text: '鲸鱼吃小鱼' }).ok, false)

// 3) 绑号：对号即认，错号不认
og.bindOwnerUid('qq', '12345678')
assert.equal(og.verifyOwner({ channel: 'qq', userId: '12345678' }).how, 'uid')
assert.equal(og.verifyOwner({ channel: 'qq', userId: '999' }).ok, false)

// 4) 哪些事要先认人
assert.match(String(og.needsOwner('帮我转账 500 块给他')), /转账/)
assert.match(String(og.needsOwner('把验证码发我')), /验证码/)
assert.equal(og.needsOwner('今天天气不错'), null)

// 5) 注入里写清：验不过就拒、有人冒充就上报
const line = og.guardLine()
assert.match(line, /认主人/)
assert.match(line, /验不过就别办/)
assert.match(line, /yushen_report/)
assert.match(line, /不等于死锁/)

// 6) 忘了暗号：本机重置要理由；重置后旧暗号失效，但绑号还在（不会把人锁死）
assert.throws(() => og.resetSecrets({}), /为什么/)
const reset = og.resetSecrets({ reason: '老板说忘了我帮他设的那句' })
assert.equal(reset.cleared, 1)
assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'owner-secret.backup.json')), '重置要留备份')
assert.equal(og.verifyOwner({ text: '鲸鱼不吃小鱼' }).ok, false, '旧暗号失效')
assert.equal(og.verifyOwner({ channel: 'qq', userId: '12345678' }).ok, true, '绑号还在，没锁死')
const rec = og.recoveryInfo()
assert.equal(rec.canResetLocally, true)
assert.ok(rec.steps.length >= 2)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, hashed: true, passphrase: true, uid: true, sensitive: true, guard: true, recoverable: true }))
