// 身份：小鱼只有一个；通道只是她坐的地方。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-id-'))
process.env.DSH_HOME = HOME
const id = await import('../lib/identity.js')

// 1) 同一个她：工作台和 QQ 都是小鱼，不是两个人
const wb = id.resolveIdentity({ role: 'xiaoyu', channel: 'workbench' })
const qq = id.resolveIdentity({ role: 'xiaoyu', channel: 'qq' })
assert.equal(wb.name, '小鱼（阿鲤）')
assert.equal(qq.name, '小鱼（阿鲤）')
assert.equal(wb.one, true)
assert.equal(qq.one, true)

// 2) 通道的显示名只是称呼
id.setChannelName('qq', '大肥鱼')
const qq2 = id.resolveIdentity({ role: 'xiaoyu', channel: 'qq' })
assert.equal(qq2.name, '小鱼（阿鲤）')
assert.equal(qq2.displayNameThere, '大肥鱼')
assert.match(id.identityLine({ role: 'xiaoyu', channel: 'qq' }), /小鱼（阿鲤） @QQ（那边显示：大肥鱼）/)

// 3) 别的角色也一样
assert.match(id.identityLine({ role: 'dayu', channel: 'workbench' }), /大鱼（阿鲲） @工作台/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, oneBody: true, channelNameIsLabel: true, otherRole: true }))
