import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-goal-'))
process.env.DSH_HOME = home
const { readConversationGoal, writeConversationGoal, goalFile } = await import('../lib/conversation-goal.js')
assert.equal(readConversationGoal(), null)
const a = writeConversationGoal({ text: '完成鱼窝拖入收编流程', nextStep: '补扫描中状态', sourceSessionId: 'old-session' })
assert.equal(a.status, 'active')
assert.equal(readConversationGoal().text, '完成鱼窝拖入收编流程')
assert.equal(readConversationGoal().nextStep, '补扫描中状态')
assert.equal(fs.existsSync(goalFile()), true)
const b = writeConversationGoal({ text: '  新窗口继续  ', status: 'paused', nextStep: '读取交接' })
assert.equal(b.goalId, a.goalId === b.goalId ? b.goalId : b.goalId)
assert.equal(readConversationGoal().status, 'paused')
assert.equal(writeConversationGoal({ text: '', nextStep: '无效' }).text, '新窗口继续')
fs.rmSync(home, { recursive: true, force: true })
console.log('跨窗口目标：持久化、读取、状态和空目标保护，全部通过')
