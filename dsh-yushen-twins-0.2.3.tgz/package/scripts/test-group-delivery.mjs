import fs from 'node:fs'
import assert from 'node:assert/strict'
const src = fs.readFileSync(new URL('../dayu/index.js', import.meta.url), 'utf8')
const block = src.slice(src.indexOf("        if (req.method === 'POST' && route === '/group-chat')"), src.indexOf("        if (req.method === 'GET' && route === '/chat')"))
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor
const names = ['req','res','route','readJsonBody','extractBiliVideo','appendConversationEvent','withCreativeMemory','residentRoles','ensureRole','residenceDeps','groupReplies','promptRpc','sendJson']
const run = new AsyncFunction(...names, block)
for (const fail of [false, true]) {
  const pending = new Map(), calls = []
  const tracker = { register(sid, entry) { pending.set(sid, [entry]); return entry }, cancel(sid) { pending.delete(sid) } }
  const response = await run({method:'POST'}, {}, '/group-chat', async () => ({text:'test', messageId:'test-1'}), () => null, x => x, x => x, () => ['xiaoyu'], async (role,deps) => { assert.equal(deps.connected,true); return {sessionId:'s1'} }, () => ({connected:true}), tracker, async args => { assert.equal(pending.get('s1').length,1); calls.push(args); if(fail) throw Error('offline'); return {ok:true,value:{accepted:true}} }, (_,status,value) => ({status,...value}))
  assert.equal(response.delivered, fail ? 0 : 1)
  assert.equal(response.deliveries[0].status, fail ? 'failed' : 'accepted')
  assert.equal(pending.has('s1'), !fail)
  assert.match(calls[0].text,/发言者：老板/)
  assert.match(calls[0].text,/不转述其他私聊内容/)
}
const client = fs.readFileSync(new URL('../client.js', import.meta.url),'utf8')
assert.ok(client.includes("m.direction === 'incoming' ? '老板' : (labels[m.role] || m.role)"))
console.log('group delivery: dependencies, handle-free RPC, pre-dispatch correlation, failure cleanup, owner label passed')
