import fs from 'node:fs'

const file = 'C:/Users/Administrator/AppData/Local/Programs/DeepSeek Harness/resources/app.asar'
const fd = fs.openSync(file, 'r')
const head = Buffer.alloc(16)
fs.readSync(fd, head, 0, 16, 0)
const jsonLen = head.readUInt32LE(12)
const buf = Buffer.alloc(jsonLen)
fs.readSync(fd, buf, 0, jsonLen, 16)
const root = JSON.parse(buf.toString('utf8'))

const node = root.files.dsh.files.node_modules.files['@deepseek-ai'].files['dsh-agent-loop'].files['package.json']
console.log('entry:', JSON.stringify(node).slice(0, 120))

for (const base of [8 + head.readUInt32LE(4) - 4, 16 + jsonLen, 8 + head.readUInt32LE(4)]) {
  try {
    const b = Buffer.alloc(Number(node.size))
    fs.readSync(fd, b, 0, Number(node.size), base + Number(node.offset))
    const s = b.toString('utf8')
    console.log('base', base, '->', s.slice(0, 40).replace(/\n/g, ' '))
  } catch (e) { console.log('base', base, 'ERR', e.message) }
}
fs.closeSync(fd)
