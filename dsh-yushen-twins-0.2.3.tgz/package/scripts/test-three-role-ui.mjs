// 鱼窝三个站位：点开 / Enter / 长按 / 右键 / 拖图，都是真实组件处理器模拟。
// 只模拟 React 元素与事件，不等于浏览器像素验收；浏览器验收见 scripts/nest-ui-check.mjs。
import fs from 'node:fs'
import vm from 'node:vm'
import assert from 'node:assert/strict'

const text = fs.readFileSync(new URL('../client.js', import.meta.url), 'utf8')
const start = text.indexOf('    function NestFigure(')
const end = text.indexOf('    function Nest({')
assert.ok(start > 0 && end > start, 'client.js 里找不到 NestFigure / Nest')
const code = text.slice(start, end)

let tested = 0
for (const role of ['dayu', 'xiaoyu', 'dragon']) {
  const picked = []
  const adopted = []
  const renamed = []
  const restored = []
  const zoomed = []
  const menus = []
  const timers = []
  const refs = []
  const h = (tag, props, ...children) => ({ tag, props: props || {}, children })
  const React = {
    Fragment: 'fragment',
    useRef(value) { const r = { current: value }; refs.push(r); return r },
    useState(init) { return [typeof init === 'function' ? init() : init, () => {}] },
    useEffect(fn) { const cleanup = fn(); return cleanup },
    // client.js 里用了 useCallback / useMemo（2026-10-30 加进 mock，之前这两个缺了这份脚本一直在红）
    useCallback(fn) { return fn },
    useMemo(fn) { return typeof fn === 'function' ? fn() : fn },
    useLayoutEffect(fn) { return fn() },
  }
  const env = {
    React,
    h,
    Date,
    setTimeout(fn) { timers.push(fn); return timers.length },
    clearTimeout() {},
    pickImage() {},
    dropImageSrc() { return '' },
    NEST_LABELS: { dayu: '大鱼', xiaoyu: '小鱼', dragon: '照微' },
    NEST_HALO_STAGE: { dayu: 3, xiaoyu: 2, dragon: 5 },
    HALO_FALLBACK: { dayu: 'data:image/svg+xml;base64,', xiaoyu: 'data:image/svg+xml;base64,', dragon: 'data:image/svg+xml;base64,' },
    orgOf: (r) => ({ dayu: { post: '副总裁', rank: '阶位3' }, xiaoyu: { post: '秘书', rank: '阶位2' }, dragon: { post: '顾问', rank: '五境' } }[r] || { post: '', rank: '' }),
  }
  vm.createContext(env)
  vm.runInContext(code + '\nglobalThis.component=NestFigure', env)

  const slot = { role, label: 'label-' + role, name: 'name-' + role, url: '/test.png', pos: { x: 0, y: 0 } }
  const tree = env.component({
    slot, role, scale: 1, menuOpen: false,
    setMenuOpen: (next) => menus.push(next),
    onPick: (r) => picked.push(r),
    onAdopt: (r, file) => adopted.push([r, file]),
    onAdoptSrc: () => {},
    onMissing: () => {},
    onRename: (r) => renamed.push(r),
    onRestore: (r) => restored.push(r),
  })
  const slotDiv = tree
  const fig = slotDiv.children[0]
  assert.equal(slotDiv.props.className.startsWith('ysn-slot'), true)
  assert.equal(fig.tag, 'button')
  assert.ok(String(fig.props['aria-label']).includes(slot.name), 'aria-label 要带名字')
  assert.ok(String(fig.props['aria-label']).includes('长按'))

  // 1. 单击进她的页面
  fig.props.onClick({ preventDefault() {} })
  assert.deepEqual(picked, [role])

  // 2. Enter / 空格也能进
  fig.props.onKeyDown({ key: 'Enter', preventDefault() {} })
  fig.props.onKeyDown({ key: ' ', preventDefault() {} })
  assert.deepEqual(picked, [role, role, role])

  // 3. 长按：只开菜单，不跳页面
  const pointer = (x = 120, y = 120) => ({ button: 0, clientX: x, clientY: y, pointerId: 1, preventDefault() {} })
  fig.props.onPointerDown(pointer())
  const longTimer = timers.at(-1)
  longTimer()
  fig.props.onPointerUp(pointer())
  fig.props.onClick({ preventDefault() {} })
  assert.equal(picked.length, 3, '长按抬手不能跳页面')
  const openTimer = timers.at(-1)
  openTimer()
  assert.equal(menus.at(-1), role, '长按要打开这个角色的小菜单')

  // 4. 右键 / 键盘菜单键
  fig.props.onContextMenu({ preventDefault() {} })
  assert.equal(menus.at(-1), role)
  fig.props.onKeyDown({ key: 'ContextMenu', preventDefault() {} })
  assert.equal(menus.at(-1), role)

  // 5. 指针取消不残留（长按后的 450ms 抑制窗在真实时间里会过去，这里直接清掉）
  refs[0].current.suppressUntil = 0
  fig.props.onPointerDown(pointer())
  fig.props.onPointerCancel()
  fig.props.onClick({ preventDefault() {} })
  assert.equal(picked.length, 4)

  // 6. 拖图进来是换形象
  fig.props.onDrop({ preventDefault() {}, stopPropagation() {}, dataTransfer: { files: [{ name: 'x.png' }] } })
  assert.equal(adopted.length, 1)
  assert.equal(adopted[0][0], role)

  // 7. 菜单项接到对应动作
  const withMenu = env.component({
    slot, role, scale: 1, menuOpen: true,
    setMenuOpen: (next) => menus.push(next),
    onPick: () => {},
    onAdopt: (r, file) => adopted.push([r, file]),
    onAdoptSrc: () => {},
    onMissing: () => {},
    onRename: (r) => renamed.push(r),
    onRestore: (r) => restored.push(r),
    onZoom: (r, d) => zoomed.push([r, d]),
  })
  const frag = withMenu.children.find((c) => c && c.tag === 'fragment')
  const items = frag && frag.children.find((c) => c && c.props && c.props.role === 'menu')
  assert.ok(items, '菜单要渲染出来')
  const buttons = items.children.filter((c) => c.tag === 'button')
  const byText = (text) => buttons.find((b) => (b.children || []).includes(text))
  assert.ok(byText('单独放大') && byText('单独缩小'), '菜单要有单只缩放')
  byText('改名字').props.onClick()
  byText('恢复默认').props.onClick()
  byText('单独放大').props.onClick()
  byText('恢复本人大小').props.onClick()
  assert.deepEqual(renamed, [role])
  assert.deepEqual(restored, [role])
  assert.deepEqual(zoomed, [[role, 0.1], [role, 0]])

  tested++
}

assert.ok(text.includes("view === 'dragon'"))
assert.ok(text.includes('/residence/say'), 'dragon page must call the shared residence endpoint')
assert.ok(text.includes('叫醒她'), 'dragon page must offer to wake her own body')
assert.ok(!text.includes('alphaAt('), '透明像素判定已移除：整张卡都可点，不再吞点击')
console.log('PASS ' + tested + ' actual NestFigure handler simulations: click, Enter/Space, long-press menu without navigation, context menu, pointer cancel, image drop, menu actions; dragon route and residence chat wiring')
console.log('Simulated React element handlers only; browser DOM/pixel acceptance: node scripts/nest-ui-check.mjs')
