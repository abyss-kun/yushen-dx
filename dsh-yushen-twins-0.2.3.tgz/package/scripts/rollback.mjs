// 一键回滚：把 dist 退回到上一个能跑的版本。
// 只退代码，不动数据（记忆、卡、账本一律不碰）。
//
// 用法：
//   node scripts/rollback.mjs            # 看有哪些快照
//   node scripts/rollback.mjs --to 0.2.1-2026-10-30T10-00-00   # 退到指定快照
//   node scripts/rollback.mjs --last     # 退到最近一个快照
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const SNAPS = path.join(ROOT, '.snapshots')
const DIST = path.join(ROOT, 'dist', 'dsh-yushen-twins')

function list() {
  if (!fs.existsSync(SNAPS)) return []
  return fs.readdirSync(SNAPS)
    .filter((n) => fs.existsSync(path.join(SNAPS, n, 'dsh-yushen-twins', 'package.json')))
    .sort()
}

const snaps = list()
if (!snaps.length) {
  console.error('还没有任何快照。先跑一次 `node scripts/build-release.mjs`（它会在打包前自动留一份）。')
  process.exit(1)
}

const arg = (name) => {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 ? String(process.argv[i + 1] || '') : ''
}

const want = process.argv.includes('--last') ? snaps[snaps.length - 1] : arg('to')
if (!want) {
  console.log('可用快照（旧 → 新）：')
  for (const s of snaps) {
    let meta = {}
    try { meta = JSON.parse(fs.readFileSync(path.join(SNAPS, s, 'SNAPSHOT.json'), 'utf8')) } catch { /* 没有元数据 */ }
    console.log(`- ${s}   ${meta.version ? `版本 ${meta.version}` : ''}`)
  }
  console.log('\n用法：node scripts/rollback.mjs --last   或   --to <上面的名字>')
  process.exit(0)
}

const hit = snaps.find((s) => s === want || s.startsWith(want))
if (!hit) {
  console.error(`没有这个快照：${want}`)
  process.exit(1)
}

// 先把当前状态也留一份，万一退错了还能回来
try {
  execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'pack-release.mjs')], { stdio: 'pipe' })
} catch { /* 打不出来就算了，下面照样退 */ }

fs.rmSync(DIST, { recursive: true, force: true })
fs.cpSync(path.join(SNAPS, hit, 'dsh-yushen-twins'), DIST, { recursive: true })
console.log(`已回滚到：${hit}`)
console.log('下一步：重启 DSH（界面和宿主都会用回退后的版本）。')
console.log('数据（记忆/卡/账本）没有被碰过。')
