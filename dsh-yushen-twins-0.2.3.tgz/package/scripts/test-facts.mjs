import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const base = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-facts-'))
process.env.DSH_HOME = base
const { facts, answerFacts } = await import('../lib/facts.js')
const data = path.join(base, 'dayu')
fs.mkdirSync(data, { recursive: true })

let out = answerFacts('dayu', '你刚才做了什么')
assert.equal(out.certainty, 'unknown')
assert.match(out.answer, /查不到.*记录/)

fs.writeFileSync(path.join(data, 'dispatch.json'), JSON.stringify([
  { id: 'job-real', role: 'dayu', brief: '检查事实账', status: 'returned', attempts: 1, replyCount: 1, evidence: [], result: '已回话但未验收', returnedAt: '2026-01-01T00:00:00.000Z' },
  { id: 'job-other', role: 'xiaoyu', brief: '不应出现', status: 'done', attempts: 1, evidence: [], completedAt: '2026-01-01T00:00:01.000Z' },
], null, 2))
fs.writeFileSync(path.join(data, 'audit.jsonl'), `${JSON.stringify({ at: '2026-01-01T00:00:02.000Z', kind: 'reply', id: 'job-real', sessionId: 's1' })}\n`)
const before = fs.readFileSync(path.join(data, 'dispatch.json'), 'utf8')
out = answerFacts('dayu', '刚才做了什么')
assert.equal(out.certainty, 'recorded')
assert.match(out.answer, /job-real/)
assert.match(out.answer, /尚未完成证据验收/)
assert.doesNotMatch(out.answer, /job-other/)
assert.equal(out.facts.modelCalled, false)
assert.equal(fs.readFileSync(path.join(data, 'dispatch.json'), 'utf8'), before)
assert.equal(facts('xiaoyu').taskCount, 1)
assert.equal(facts('xiaoyu').recentTasks[0].id, 'job-other')
assert.throws(() => facts('bad'), /未知角色/)
fs.rmSync(base, { recursive: true, force: true })
console.log('事实问答：空账本说不知道、只引用真实记录、角色隔离、不改账本，全部通过')
