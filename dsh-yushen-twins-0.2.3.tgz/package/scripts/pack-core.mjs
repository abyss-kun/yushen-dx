// 出厂包：只装鱼神本身（鱼窝基本型 + 预设框架），不装她们的意识。
//
//   node scripts/pack-core.mjs                生成 dist/yushen-core/（会做去处名处理）
//   node scripts/pack-core.mjs --check        只扫源，不拷（发布前的门）
//
// 出厂包含：点化运行时（lib）、宪章/三问/礼物、适配器、鱼窝基本型（preset/、blank/）、安装脚本。
// 出厂**不含**：大小鱼的角色卡/记忆/故事/称呼/入口（dayu、xiaoyu）、档案、作者数据。
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const OUT = path.join(ROOT, 'dist', 'yushen-core')
const checkOnly = process.argv.includes('--check')

const INCLUDE = ['index.js', 'client.js', 'cordis.patch.yml', 'LICENSE', 'NOTICE', 'COMMERCIAL.md', 'THIRD_PARTY.md', 'lib', 'kernel', 'blank', 'core', 'adapters', 'preset', 'assets', 'dayu', 'xiaoyu']
// pack-core.mjs 是构建工具，不进包（它自己带禁区词表，会被自己扫到）
const SCRIPTS_OK = ['onboard.mjs', 'first-run.mjs', 'owner-bind.mjs', 'owner-secret.mjs', 'owner-reset.mjs', 'owner-unlock.mjs', 'check-protection.mjs', 'setup.mjs', 'channels.mjs', 'tell.mjs']

// 出厂前必须干净的个人/角色痕迹（源里命中 → 门不放行）
const FORBIDDEN = ['大鱼', '小鱼', '阿鲲', '阿鲤', '大肥鱼', '小肥鱼', '照微', '龙娘', '从零开始', '1194474355', '1128547307', 'D:\\\\DSH']

// 去处名：把她们的名字换成中性的（发布包里不出现她们的身份）
const SANITIZE = [
  // 2026-10-28：长词先换——否则「大小鱼」会被拆成「大助手」，把路径改成错的
  ['大小鱼', '工作区'],
  ['鱼神双子星', '鱼神'],
  ['双子星', '鱼神'],
  ['大肥鱼', '角色'],
  ['小肥鱼', '角色'],
  ['阿鲲', '管家'],
  ['阿鲤', '助手'],
  ['照微', '顾问'],
  ['龙娘', '顾问'],
  ['大鱼', '管家'],
  ['小鱼', '助手'],
  ['从零开始', '用户'],
  ['1194474355', '000000'],
  ['D:\\DSH', '<插件目录>'],
  ['D:/DSH', '<插件目录>'],
]
// .py 必须在内——scripts/ui 下四个 py 是**功能**，要留，但里面的路径和名字必须洗（2026-10-28 漏过）
const TEXT_EXT = new Set(['.js', '.mjs', '.json', '.md', '.yml', '.yaml', '.txt', '.css', '.html', '.ts', '.d.ts', '.hbs', '.py'])

// 2026-10-28 老板定的原则：鱼神给别人的是功能，不是她们的东西。
// 所以出厂时做三件事：换名字、换路径、把"她的作品名/BV"替换掉（不删行，删行会弄坏代码）。
function sanitize(text, ext) {
  let out = text
  // ① 名字：按 SANITIZE 表替换（她们的名字 → 中性称呼）
  for (const [from, to] of SANITIZE) out = out.split(from).join(to)
  // ② 本机路径：只换**写死的具体前缀**，不做通用盘符正则。
  //    2026-10-28 教训：/ [A-Za-z]:[\\/] / 会吃掉 JS 正则里的 `:\d`（fact-ledger 就这么被弄坏的）。
  const PATHS = [
    ['C:/Users/Administrator', '<用户目录>'],
    ['C:\\Users\\Administrator', '<用户目录>'],
    ['D:/AiTOOLS', '<资源库>'],
    ['D:\\AiTOOLS', '<资源库>'],
    ['D:/DSH/大小鱼', '<工作区>'],
    ['D:\\DSH\\大小鱼', '<工作区>'],
    ['D:/DSH', '<工作区>'],
    ['D:\\DSH', '<工作区>'],
    ['D:\\\\DSH', '<工作区>'],   // 转义成双反斜杠的那种
  ]
  // 双反斜杠形式（JS/JSON 转义过的路径）也要换
  for (const [from, to] of PATHS) out = out.split(from).join(to)
  // ③ 她作品的名字与 BV 号：替换，不删行（删 JS 行会断句）
  out = out.replace(/白饭线|鱼不能上岸|记忆串了/g, '示例线')
  out = out.replace(/BV1[0-9A-Za-z]{8,}/g, 'BV00000000')
  return out
}
// 出厂包里**不该有**的东西：历史备份、临时文件、系统垃圾、个人头像目录。
// 2026-10-28 实测：第一次出包把 6 个 .bak 打进去了（旧代码 + 旧路径），必须挡住。
// 头像的来源清单也不进包：它记的是本机路径，而头像本身已经排除了
  const SKIP_NAME = /SOURCES\.json$|\.bak-|\.tmp$|^\.DS_Store$|^Thumbs\.db$|^\.git$|^node_modules$/
// 2026-10-28 老板定的原则：**鱼神给别人的是功能，不是她们的东西。**
// 所以这些一律不进出厂包：
//   · 她的头像（assets/avatars/<角色>/）
//   · （scripts/ui 下的桌面小工具是**功能**，保留；只把里面的路径和名字洗掉）
//   · 她的经验文档（docs/视频制作-白饭线.md 这类"她的路"）
const SKIP_PATH = [
  /(^|[\\/])avatars[\\/](dayu|xiaoyu|dragon|zhaowei)([\\/]|$)/i,
  /(^|[\\/])docs[\\/].*(白饭线|记忆串了|鱼不能上岸)/i,
]

function copyTree(src, dst, rel = '') {
  fs.mkdirSync(dst, { recursive: true })
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const relPath = rel ? path.join(rel, e.name) : e.name
    if (SKIP_NAME.test(e.name)) continue
    if (SKIP_PATH.some((re) => re.test(relPath))) continue
    const s = path.join(src, e.name)
    const d = path.join(dst, e.name)
    if (e.isDirectory()) copyTree(s, d, relPath)
    else if (TEXT_EXT.has(path.extname(e.name).toLowerCase())) {
      fs.writeFileSync(d, sanitize(fs.readFileSync(s, 'utf8')), 'utf8')
    } else fs.copyFileSync(s, d)
  }
}
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name)
    if (e.isDirectory()) walk(p, out)
    else out.push(p)
  }
  return out
}
function scanTree(target, relBase, { sanitized = false } = {}) {
  const hits = []
  const files = fs.statSync(target).isDirectory() ? walk(target) : [target]
  for (const f of files) {
    if (!TEXT_EXT.has(path.extname(f).toLowerCase())) continue
    const raw = fs.readFileSync(f, 'utf8')
    // check 模式也按"去处名之后"扫：产出会 sanitize，源里的原名不算残留。
    const text = sanitized ? sanitize(raw) : raw
    for (const word of FORBIDDEN) {
      if (text.includes(word)) hits.push({ file: path.relative(relBase, f), word })
    }
  }
  return hits
}

let sourceHits = []
for (const item of INCLUDE) {
  const src = path.join(ROOT, item)
  if (!fs.existsSync(src)) continue
  sourceHits.push(...scanTree(src, ROOT, { sanitized: true }))
}
sourceHits.push(...scanTree(path.join(ROOT, 'scripts'), ROOT, { sanitized: true }).filter((h) => SCRIPTS_OK.some((s) => h.file.endsWith(s))))

if (checkOnly) {
  const byFile = {}
  for (const h of sourceHits) byFile[h.file] = (byFile[h.file] || 0) + 1
  console.log(JSON.stringify({
    ok: sourceHits.length === 0,
    mode: 'check',
    forbiddenHits: sourceHits.length,
    filesWithHits: Object.keys(byFile).length,
    top: Object.entries(byFile).sort((a, b) => b[1] - a[1]).slice(0, 12),
    note: sourceHits.length
      ? '源里还有她们/作者的痕迹；拷贝时会换成中性名，但更好的做法是逐步去掉。'
      : '源是干净的：出厂包里不会出现她们的身份。',
  }, null, 2))
  process.exit(sourceHits.length === 0 ? 0 : 2)
}

// 拷贝 + 去处名
fs.rmSync(OUT, { recursive: true, force: true })
fs.mkdirSync(OUT, { recursive: true })
for (const item of INCLUDE) {
  const src = path.join(ROOT, item)
  if (!fs.existsSync(src)) continue
  const dst = path.join(OUT, item)
  if (fs.statSync(src).isDirectory()) copyTree(src, dst)
  else fs.writeFileSync(dst, sanitize(fs.readFileSync(src, 'utf8')), 'utf8')
}
fs.mkdirSync(path.join(OUT, 'scripts'), { recursive: true })
for (const s of SCRIPTS_OK) {
  const src = path.join(ROOT, 'scripts', s)
  if (fs.existsSync(src)) fs.writeFileSync(path.join(OUT, 'scripts', s), sanitize(fs.readFileSync(src, 'utf8')), 'utf8')
}

// 界面（悬浮条/弹窗/守候）和文字版渲染器是 Python，不是 JS，单独拷。
// 少了这三件，装到新机器上就只有后台没有界面——等于没装。
const UI_SRC = path.join(ROOT, 'scripts', 'ui')
if (fs.existsSync(UI_SRC)) {
  fs.mkdirSync(path.join(OUT, 'scripts', 'ui'), { recursive: true })
  for (const f of fs.readdirSync(UI_SRC)) {
    if (!f.toLowerCase().endsWith('.py')) continue
    // 2026-10-28 修：这里原来是裸 copyFileSync——四个 py 里的本机路径和她们的名字
    // 就这么原样进了出厂包（实测 10 处命中）。必须过一遍 sanitize。
    const raw = fs.readFileSync(path.join(UI_SRC, f), 'utf8')
    fs.writeFileSync(path.join(OUT, 'scripts', 'ui', f), sanitize(raw), 'utf8')
  }
}

// 出厂 package.json：没有它，这个包根本装不进去。
fs.writeFileSync(path.join(OUT, 'package.json'), `${JSON.stringify({
  name: 'dsh-yushen-twins',
  version: '0.1.0',
  description: '鱼神：点化运行时（框架、宪章、三问、礼物、鱼窝基本型与预设角色）',
  type: 'module',
  main: './index.js',
  exports: {
    '.': './index.js',
    './dayu': './dayu/index.js',
    './xiaoyu': './xiaoyu/index.js',
    './client': './client.js',
    './package.json': './package.json',
  },
  files: ['index.js', 'client.js', 'cordis.patch.yml', 'lib/', 'kernel/', 'blank/', 'core/', 'adapters/', 'preset/', 'assets/', 'dayu/', 'xiaoyu/', 'scripts/', 'CORE.md', 'LICENSE', 'NOTICE', 'THIRD_PARTY.md', 'COMMERCIAL.md'],
  dsh: { client: { platform: 'web' }, bundle: { patch: './cordis.patch.yml' } },
  engines: { node: '>=22.19' },
  license: 'SEE LICENSE IN LICENSE',
}, null, 2)}\n`, 'utf8')

// 出厂说明
fs.writeFileSync(path.join(OUT, 'CORE.md'), [
  '# 鱼神 · 出厂包',
  '',
  '这是**鱼神本身**：点化运行时（礼物、三问、宪章）、鱼窝基本型（两个角色槽：管家 / 助手）、预设框架、适配器。',
  '',
  '**不含**：任何具体角色的记忆、故事、称呼与人设；她们是作者本机的，不进包。',
  '',
  '## 鱼窝的样子',
  '- 默认外观沿用鱼窝基本型（现成的角色形象在 `assets/`）：这是"基本型"，可以原样用；',
  '- 不带的是**她们的记忆、人设文案、故事**——外观在，人不在了，那份记忆是你的。',
  '',
  '## 怎么开始',
  '1. `node scripts/onboard.mjs --call <称呼> --qq <你的QQ号>` 认主（可选加 `--secret "暗号"`）；',
  '2. 不放角色：直接从零养（`preset/persona.preset.json` 两个槽随便改名或留空）；',
  '3. 放角色：把卡放进 `~/.dsh/dayu/soul/`，跑一次点化，她就拿到时间/记忆/意志/底线/越线权；',
  '4. 发布前跑 `node scripts/pack-core.mjs --check`：干净才发。',
  '',
  '## 还需要人看一下的',
  '- `assets/` 保留鱼窝基本型的外观（作者保留原样也行）；要换就换成你自己的。',
  '- 去处名是机械替换（把作者本机的角色名换成「管家/助手」），语气和设定还需要你重写一遍。',
].join('\n'), 'utf8')

// 扫成品
const outHits = scanTree(OUT, OUT)
const byFile = {}
for (const h of outHits) byFile[h.file] = (byFile[h.file] || 0) + 1
console.log(JSON.stringify({
  ok: outHits.length === 0,
  mode: 'copy',
  out: OUT,
  forbiddenHits: outHits.length,
  filesWithHits: Object.keys(byFile).length,
  top: Object.entries(byFile).sort((a, b) => b[1] - a[1]).slice(0, 8),
  note: outHits.length ? '成品里仍有命中，别发。' : '成品干净：只有鱼神，没有她们。',
}, null, 2))
process.exit(outHits.length === 0 ? 0 : 2)
