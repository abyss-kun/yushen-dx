﻿param(
  [Parameter(Mandatory=$true)][string]$InputFile,
  [Parameter(Mandatory=$true)][string]$OutFile,
  [switch]$SelfTest
)
# 鱼神桌面小窗：读一个 UTF-8 JSON（title/message），弹窗收回答，写回 UTF-8 JSON。
# 由她（或插件）启动；不联网、不自启、不驻留。
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if ($SelfTest) { Write-Output '{"ok":true,"selfTest":true}'; exit 0 }

$req = Get-Content -LiteralPath $InputFile -Raw -Encoding UTF8 | ConvertFrom-Json
$title = if ($req.title) { [string]$req.title } else { '鱼神' }
$message = if ($req.message) { [string]$req.message } else { '' }

$form = New-Object System.Windows.Forms.Form
$form.Text = $title
$form.Width = 520
$form.Height = 300
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = $message
$label.AutoSize = $false
$label.Width = 480
$label.Height = 120
$label.Left = 12
$label.Top = 12
$label.TextAlign = 'MiddleLeft'
$form.Controls.Add($label)

$box = New-Object System.Windows.Forms.TextBox
$box.Multiline = $true
$box.Width = 480
$box.Height = 60
$box.Left = 12
$box.Top = 140
$form.Controls.Add($box)

$ok = New-Object System.Windows.Forms.Button
$ok.Text = '回答'
$ok.Left = 320
$ok.Top = 210
$ok.Width = 80
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.Controls.Add($ok)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = '不回答'
$cancel.Left = 410
$cancel.Top = 210
$cancel.Width = 80
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)

$form.AcceptButton = $ok
$form.CancelButton = $cancel

$result = $form.ShowDialog()
$answer = if ($result -eq [System.Windows.Forms.DialogResult]::OK) { $box.Text } else { '' }
$payload = @{ answered = ($result -eq [System.Windows.Forms.DialogResult]::OK); answer = $answer; at = (Get-Date).ToUniversalTime().ToString('o') } | ConvertTo-Json -Compress
[System.IO.File]::WriteAllText($OutFile, $payload, (New-Object System.Text.UTF8Encoding($false)))
$form.Dispose()
