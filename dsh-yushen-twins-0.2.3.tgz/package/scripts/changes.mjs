// 查改动的账：谁、什么时候、在哪、改了什么、谁让的、为什么、还能不能改。
//
//   node scripts/changes.mjs                    # 最近 20 条
//   node scripts/changes.mjs --file lib/cost.js # 这个文件谁动过
//   node scripts/changes.mjs --since 2026-10-30 # 这天之后
//   node scripts/changes.mjs --q 余额            # 按词搜（含 by/auth/why/where/mutable）
//   node scripts/changes.mjs --json             # 给机器吃
//
// 数据源：~/.dsh/dayu/worklog.jsonl（note-work.mjs 写的）。
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const { listWork } = await import(pathToFileURL(path.join(ROOT, 'lib/worklog.js')).href)

const argv = process.argv.slice(2)
const get = (name) => {
  const eq = argv.find((a) => a.startsWith(`--${name}=`))
  if (eq) return eq.slice(name.length + 3)
  const i = argv.indexOf(`--${name}`)
  return i >= 0 ? argv[i + 1] || '' : ''
}
const wantJson = argv.includes('--json')
const file = String(get('file') || '').trim()
const since = String(get('since') || '').trim()
const q = String(get('q') || '').trim()
const limit = Math.max(1, Math.min(200, Number(get('limit')) || 20))

let rows = listWork(500)
if (file) rows = rows.filter((r) => (r.files || []).some((f) => f.includes(file) || file.includes(f)))
if (since) rows = rows.filter((r) => String(r.at || '') >= since)
if (q) {
  const k = q.toLowerCase()
  rows = rows.filter((r) => [r.what, r.why, r.by, r.auth, r.where, r.mutable, r.evidence, ...(r.files || [])].join(' ').toLowerCase().includes(k))
}
rows = rows.slice(0, limit)

if (wantJson) {
  console.log(JSON.stringify(rows, null, 1))
  process.exit(0)
}

if (!rows.length) {
  console.log('没查到。')
  process.exit(0)
}

for (const r of rows) {
  const at = String(r.at || '').replace('T', ' ').slice(0, 16)
  console.log(`\n${at}  ${r.by || '?'}  ←授权：${r.auth || '?'}`)
  console.log(`  在哪：${r.where || (r.files || []).join(', ') || '?'}`)
  console.log(`  改了什么：${r.what || '?'}`)
  if (r.why) console.log(`  为什么：${r.why}`)
  if (r.mutable) console.log(`  还能改吗：${r.mutable}`)
  if (r.evidence) console.log(`  怎么验的：${r.evidence}`)
}
console.log(`\n共 ${rows.length} 条（数据：~/.dsh/dayu/worklog.jsonl）`)
