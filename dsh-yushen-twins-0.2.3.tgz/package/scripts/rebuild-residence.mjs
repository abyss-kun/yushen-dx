// 常驻会话重建：把三条会话从「standard」预设换成「鱼神」预设。
//
// 为什么只能重建：DSH 没有"改会话预设"的接口，只能新建一条。
// 代价：这三条会话的聊天记录不跟过去；角色卡、记忆、账本、形象都不动。
//
// 用法：
//   node scripts/rebuild-residence.mjs            # 看会删什么（dry run）
//   node scripts/rebuild-residence.mjs --apply    # 真做：归档旧行 + 清空，等下次唤醒按新预设重建
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const LEDGER = path.join(HOME, 'dayu', 'residence.json')
const ARCHIVE_DIR = path.join(HOME, 'dayu', 'archive')

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')) } catch { return fallback }
}

const apply = process.argv.includes('--apply')
const ledger = readJson(LEDGER, null)
if (!ledger || !ledger.roles) {
  console.error(`没有账本：${LEDGER}`)
  process.exit(1)
}

const roles = Object.keys(ledger.roles)
if (!roles.length) {
  console.log('账本里没有角色，不用重建。')
  process.exit(0)
}

console.log(`将要重建 ${roles.length} 条常驻会话：`)
for (const role of roles) {
  const row = ledger.roles[role] || {}
  console.log(`- ${role}: session=${row.sessionId || '(无)'} 标题=${row.title || '(无)'} 最后消息=${row.lastMessageAt || '(无)'}`)
}
console.log('\n影响：这三条会话的聊天记录不跟过去；卡 / 记忆 / 账本 / 形象都不动。')
console.log('重建后：新会话用「鱼神」预设创建（工具 35 个、简报注入完整）。')

if (!apply) {
  console.log('\n这是 dry run。确认后加 --apply 执行。')
  process.exit(0)
}

fs.mkdirSync(ARCHIVE_DIR, { recursive: true })
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const backup = path.join(ARCHIVE_DIR, `residence-before-rebuild-${stamp}.json`)
fs.writeFileSync(backup, JSON.stringify(ledger, null, 2) + '\n', 'utf8')

for (const role of roles) {
  const row = ledger.roles[role] || {}
  if (row.sessionId) {
    ledger.roles[role] = { ...row, previousSessionId: row.sessionId, sessionId: '', presetBefore: 'standard', clearedAt: new Date().toISOString() }
  }
}
ledger.updatedAt = new Date().toISOString()
fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 2) + '\n', 'utf8')
console.log(`\n已清空三条会话的 sessionId（旧账备份：${backup}）。`)
console.log('下一步：重启 DSH，然后在鱼窝点一次「唤醒/说话」，三条会话会用「鱼神」预设重建。')
