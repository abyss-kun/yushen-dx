// 装 / 卸「鱼神岗位预设」：改的是 profile 的 cordis.patch.yml，先备份、可回退。
//
//   node scripts/presets.mjs status     看现在装没装
//   node scripts/presets.mjs install    装进去（备份 → 写 → 校验结构）
//   node scripts/presets.mjs revert     回退到备份
//
// 为什么要这么小心：这份文件坏掉，宿主可能整个插件都挂不上（2026-10-21 就踩过）。
// 所以：只追加一段带标记的内容、写前备份、写后做结构检查、一条命令可退。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const PROFILE = process.env.YUSHEN_PROFILE || path.join(HOME, 'profiles', 'desktop')
const PATCH = path.join(PROFILE, 'cordis.patch.yml')
const HERE = path.dirname(fileURLToPath(import.meta.url))
const BLOCK = path.resolve(HERE, '..', 'preset', 'yushen-posts.patch.yml')
const BEGIN = '# === yushen-posts BEGIN ==='
const END = '# === yushen-posts END ==='

function readBlock() {
  const text = fs.readFileSync(BLOCK, 'utf8')
  const i = text.indexOf(BEGIN)
  const j = text.indexOf(END)
  if (i < 0 || j < 0) throw new Error(`预设文件里找不到标记：${BLOCK}`)
  return text.slice(i + BEGIN.length, j).replace(/^\r?\n/, '').replace(/\s+$/, '')
}

/** 结构检查：不许 tab、缩进必须是 2 的倍数、preset id 不能重复、每行都像 YAML 的键或值。 */
function checkStructure(block) {
  const problems = []
  const ids = []
  for (const [n, raw] of block.split(/\r?\n/).entries()) {
    const line = raw.replace(/\s+$/, '')
    if (!line.trim()) continue
    if (line.includes('\t')) problems.push(`第 ${n + 1} 行有 tab`)
    const indent = line.length - line.trimStart().length
    if (indent % 2 !== 0) problems.push(`第 ${n + 1} 行缩进 ${indent} 不是 2 的倍数`)
    const m = line.match(/^\s+id:\s*(\S+)/)
    if (m) ids.push(m[1])
  }
  // preset 的 config.id 必须唯一（重复会导致声明加载失败）
  const cfgIds = [...block.matchAll(/^\s{6,}id:\s*(yushen-[a-z-]+)\s*$/gm)].map((m) => m[1])
  const dup = cfgIds.filter((x, i) => cfgIds.indexOf(x) !== i)
  if (dup.length) problems.push(`preset id 重复：${[...new Set(dup)].join(', ')}`)
  return { ok: problems.length === 0, problems }
}

function stripExisting(text) {
  const i = text.indexOf(BEGIN)
  const j = text.indexOf(END)
  if (i < 0 || j < 0) return text
  return `${text.slice(0, i).replace(/\s+$/, '')}\n${text.slice(j + END.length).replace(/^\s*\n/, '')}`
}

const cmd = String(process.argv[2] || 'status')
const has = (text) => text.includes(BEGIN) && text.includes(END)

try {
  if (cmd === 'status') {
    const text = fs.readFileSync(PATCH, 'utf8')
    console.log(`配置文件：${PATCH}`)
    console.log(`鱼神预设：${has(text) ? '已装' : '没装（行为跟现在一样）'}`)
    const block = readBlock()
    const chk = checkStructure(block)
    console.log(`预设内容检查：${chk.ok ? '通过' : chk.problems.join('；')}`)
    const ids = [...block.matchAll(/^\s{6,}id:\s*(yushen-[a-z-]+)\s*$/gm)].map((m) => m[1])
    console.log(`会加进去的预设：${ids.join('、') || '（无）'}`)
  } else if (cmd === 'install') {
    const block = readBlock()
    const chk = checkStructure(block)
    if (!chk.ok) throw new Error(`预设内容有问题，没装：${chk.problems.join('；')}`)
    const text = fs.readFileSync(PATCH, 'utf8')
    if (has(text)) {
      console.log('已经装过了，先卸掉旧的再加新的')
    }
    const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)
    const bak = `${PATCH}.bak-presets-${stamp}`
    fs.copyFileSync(PATCH, bak)
    const base = stripExisting(text)
    const next = `${base}\n${BEGIN}\n${block}\n${END}\n`
    const tmp = `${PATCH}.tmp`
    fs.writeFileSync(tmp, next, 'utf8')
    fs.renameSync(tmp, PATCH)
    console.log(`装好了。备份：${bak}`)
    console.log('要重启宿主才生效；不想装了就跑：node scripts/presets.mjs revert')
  } else if (cmd === 'revert') {
    const dir = path.dirname(PATCH)
    const baks = fs.readdirSync(dir).filter((n) => n.startsWith('cordis.patch.yml.bak-presets-')).sort()
    if (!baks.length) throw new Error('找不到备份，没东西可回退')
    const last = path.join(dir, baks[baks.length - 1])
    fs.copyFileSync(last, PATCH)
    console.log(`已回退到：${last}`)
    console.log('重启宿主后恢复原样。')
  } else {
    console.log('用法：status | install | revert')
    process.exit(1)
  }
} catch (error) {
  console.error(`出错：${error?.message || error}`)
  process.exit(1)
}
