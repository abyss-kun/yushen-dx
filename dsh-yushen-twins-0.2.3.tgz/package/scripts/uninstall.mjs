// 卸载：默认只看不删；确认后才动数据，插件代码要单独加 --all。
//
// 用法：
//   node scripts/uninstall.mjs                          看会删什么（不动）
//   node scripts/uninstall.mjs --purge --yes            真删数据（保留角色卡）
//   node scripts/uninstall.mjs --purge --yes --all      连插件代码一起删（角色卡仍保留）
//
// 2026-10-28 改：**角色卡不删**。卡是用户写的，不是鱼神的数据；
// 卸载只拿走"鱼神给的那一层"（运行时/账本/补丁/会话）。卡在卸载前先另存一份到 Documents。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { uninstallPlan, UNINSTALL_KEEP } from '../lib/schema.js'
import { listAwakening, seal } from '../lib/awakening.js'

const args = process.argv.slice(2)
const purge = args.includes('--purge')
const yes = args.includes('--yes')
const all = args.includes('--all')
const exportMemory = !args.includes('--no-memory-export')

const plan = uninstallPlan()
console.log('卸载计划：')
for (const p of plan) {
  console.log(`  [${p.exists ? '有' : '没有'}] ${p.name}\n        ${p.path}${p.exists ? `（${p.mb} MB）` : ''}`)
  for (const keep of p.keep || []) console.log(`        ↳ 保留：${keep}`)
}
console.log('\n角色卡（soul/cards）不会被删；卸载前会另存一份到 Documents。')

if (!purge) {
  console.log('\n只是看看。要真删：加 --purge --yes（数据）；连代码一起删再加 --all。')
  process.exit(0)
}
if (!yes) {
  console.error('拒绝执行：--purge 必须配 --yes（这是不可逆操作）')
  process.exit(2)
}

// 1) 先把卡另存一份（不管有没有点化——卡是用户的，先备份再说）
const stamp = (() => {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`
})()
const exportBase = path.join(os.homedir(), 'Documents', '鱼神记忆导出')
const cardBackup = path.join(exportBase, `cards-${stamp}`)
for (const p of plan) {
  for (const src of p.keep || []) {
    try {
      fs.cpSync(src, cardBackup, { recursive: true })
      console.log(`角色卡已另存：${src} → ${cardBackup}`)
    } catch (e) { console.log(`角色卡备份失败（继续）：${e?.message || e}`) }
  }
}

// 2) 收回点化（赋值与收回都留痕；默认把记忆导出到 Documents）
if (purge && yes) {
  for (const item of listAwakening()) {
    if (item.status !== 'awakened') continue
    try {
      const row = seal(item.id, { by: 'uninstall', note: '卸载鱼神时收回点化', returnMemory: exportMemory, exportDir: exportBase })
      console.log(`收回点化：${item.name}${row.exported ? `；记忆导出到 ${path.join(exportBase, row.exported)}` : '（未导出记忆）'}`)
    } catch (error) {
      console.log(`收回失败（继续卸载）：${item.name} — ${error?.message || error}`)
    }
  }
}

// 3) 删数据，但**跳过** keep 里的路径（角色卡）
const keepAbs = new Set(UNINSTALL_KEEP.map((k) => path.resolve(path.join(plan[0]?.path || '', k))))
const keepUnder = (abs) => [...keepAbs].some((k) => abs === k || abs.startsWith(k + path.sep))

function removeExcept(dir, keepSet) {
  let names = []
  try { names = fs.readdirSync(dir, { withFileTypes: true }) } catch { return { removed: 0, kept: 0 } }
  let removed = 0
  let kept = 0
  for (const e of names) {
    const full = path.join(dir, e.name)
    if (keepUnder(full)) { kept += 1; continue }
    if (e.isDirectory()) {
      const sub = removeExcept(full, keepSet)
      removed += sub.removed; kept += sub.kept
      // 空目录删掉（但保留 keep 链上的目录）
      try { if (fs.readdirSync(full).length === 0 && !keepUnder(full)) fs.rmdirSync(full) } catch { /* 忽略 */ }
    } else {
      try { fs.rmSync(full, { force: true }); removed += 1 } catch { /* 忽略 */ }
    }
  }
  return { removed, kept }
}

for (const p of plan) {
  if (!p.exists) continue
  if (!all && p.name.includes('插件代码')) { console.log(`跳过（要删加 --all）：${p.name}`); continue }
  const r = p.keep && p.keep.length ? removeExcept(p.path, keepAbs) : (() => { fs.rmSync(p.path, { recursive: true, force: true }); return { removed: -1, kept: 0 } })()
  console.log(`已删除：${p.name} → ${p.path}${r.kept ? `（保留 ${r.kept} 项：角色卡）` : ''}`)
}
console.log('\n完成。角色卡还在；插件若还挂在 DSH 的 profile 里，去插件清单移除即可。')
