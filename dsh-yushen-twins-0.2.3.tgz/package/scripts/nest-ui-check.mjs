// 鱼窝浏览器验收：打开真实 DSH GUI，量几何、走交互、截图。
// 用法：先启动 DSH（GUI 跑起来），再
//   node scripts/nest-ui-check.mjs
// 可用环境变量：
//   YUSHEN_GUI=http://127.0.0.1:29895   宿主地址（默认）
//   YUSHEN_EDGE=.../msedge.exe          浏览器路径（默认找 Edge，再找 Chrome）
//   DSH_HOME=...                        凭证位置（默认 ~/.dsh）
// 只在临时浏览器 profile 里跑，不写鱼窝数据；截图落到系统临时目录，失败时打印路径。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import cp from 'node:child_process'
import crypto from 'node:crypto'

const BASE = process.env.YUSHEN_GUI || 'http://127.0.0.1:29895'
const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const OUT = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-nest-ui-'))
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const results = []
const record = (name, ok, detail) => {
  results.push({ name, ok, detail })
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}  ${detail}`)
}

function findBrowser() {
  const candidates = [
    process.env.YUSHEN_EDGE,
    'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
    '/usr/bin/microsoft-edge',
    '/usr/bin/google-chrome',
  ].filter(Boolean)
  return candidates.find((file) => { try { return fs.statSync(file).isFile() } catch { return false } }) || ''
}

function readSecret() {
  const file = path.join(HOME, '.credentials.yaml')
  const text = fs.readFileSync(file, 'utf8')
  const m = text.match(/client-connection\/browser-session:[\s\S]{0,300}?secret:\s*([A-Za-z0-9_-]+)/)
  if (!m) throw new Error(`没在 ${file} 里找到 browser-session 密钥`)
  return Buffer.from(m[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64')
}

function authCookie() {
  const host = new URL(BASE).host
  const issuedAt = Date.now()
  const payload = Buffer.from(JSON.stringify({ version: 1, authority: host, issuedAt, expiresAt: issuedAt + 3600_000 })).toString('base64url')
  const sig = crypto.createHmac('sha256', readSecret()).update(payload).digest('base64url')
  return {
    name: 'dsh-auth-' + crypto.createHash('sha256').update(host).digest('base64url'),
    value: 'v1.' + payload + '.' + sig,
  }
}

let ws
let seq = 0
const pending = new Map()
const events = []
function cmd(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++seq
    pending.set(id, { resolve, reject })
    ws.send(JSON.stringify({ id, method, params }))
  })
}
async function ev(expression) {
  const r = await cmd('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true })
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text)
  return r.result?.value
}
async function shot(name) {
  const r = await cmd('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync(path.join(OUT, name), Buffer.from(r.data, 'base64'))
}
async function clickText(text, selector = 'button') {
  return ev(`(() => {
    const hit = [...document.querySelectorAll(${JSON.stringify(selector)})]
      .find((e) => (e.innerText || '').trim() === ${JSON.stringify(text)} && e.offsetParent !== null)
    if (!hit) return false
    hit.click()
    return true
  })()`)
}
async function clickAny(text) {
  return ev(`(() => {
    const hit = [...document.querySelectorAll('button,[role="button"],a,div,span')]
      .find((e) => (e.innerText || '').trim() === ${JSON.stringify(text)} && e.offsetParent !== null)
    if (!hit) return false
    hit.click()
    return true
  })()`)
}
async function mouse(type, x, y) {
  await cmd('Input.dispatchMouseEvent', {
    type, x, y, button: 'left', clickCount: 1,
    buttons: type === 'mouseReleased' ? 0 : 1,
  })
}
async function setSize(width, height) {
  await cmd('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: width < 500 })
  await sleep(650)
}

function measure() {
  return ev(`JSON.stringify((() => {
    const rect = (e) => { if (!e) return null; const r = e.getBoundingClientRect(); return { x: +r.x.toFixed(1), y: +r.y.toFixed(1), w: +r.width.toFixed(1), h: +r.height.toFixed(1) } }
    const root = document.querySelector('.ysn-root')
    const stage = document.querySelector('.ysn-stage')
    const foot = document.querySelector('.ysn-foot')
    const slots = [...document.querySelectorAll('.ysn-slot')]
    const roles = slots.map((s) => s.getAttribute('data-role') || '')
    const names = slots.map((s) => s.querySelector('.ysn-name'))
    const imgs = slots.map((s) => s.querySelector('.ysn-art .ysn-character'))
    const halos = slots.map((s) => s.querySelector('.ysn-halo'))
    const crowns = slots.map((s) => s.querySelector('.ysn-crown'))
    const pet = document.querySelector('.dshwv-root')
    const petZ = pet ? getComputedStyle(pet).zIndex : ''
    const nameHits = names.map((n) => {
      if (!n) return ''
      const r = n.getBoundingClientRect()
      const hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2)
      return hit ? (hit.closest('.ysn-slot') ? 'own' : String(hit.className || hit.tagName)) : 'none'
    })
    return {
      viewport: [innerWidth, innerHeight],
      root: rect(root), stage: rect(stage), foot: rect(foot),
      roles,
      slots: slots.map((s) => rect(s)),
      names: names.map((n) => ({ text: n ? n.textContent : '', rect: rect(n) })),
      imgs: imgs.map((img) => ({ src: img ? img.getAttribute('src') : '', rect: rect(img), natural: img ? [img.naturalWidth, img.naturalHeight] : null })),
      halos: halos.map((img) => ({ src: img ? (img.currentSrc || img.src) : '', visible: img ? (() => { const s = getComputedStyle(img); const r = img.getBoundingClientRect(); return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity) > 0 && r.width > 0 && r.height > 0 })() : false, natural: img ? [img.naturalWidth, img.naturalHeight] : null })),
      crowns: crowns.map((c) => ({
        text: c ? c.innerText : '',
        rings: c ? c.querySelectorAll('.ysn-head-halo i').length : 0,
        fill: c?.querySelector('.ysn-xp-fill')?.style.width || '',
      })),
      nameHits, petZ,
      overflow: root ? { sw: root.scrollWidth, cw: root.clientWidth, sh: root.scrollHeight, ch: root.clientHeight } : null,
      docOverflow: { sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth },
    }
  })())`)
}

async function boot(browserPath) {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-nest-browser-'))
  const browser = cp.spawn(browserPath, [
    '--headless=new', '--disable-gpu', '--no-sandbox', '--hide-scrollbars', '--mute-audio',
    '--window-size=1440,960', '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank',
  ], { stdio: 'ignore' })
  let port = ''
  for (let i = 0; i < 250; i++) {
    try { port = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]; break } catch { /* 还没起来 */ }
    await sleep(100)
  }
  if (!port) throw new Error('浏览器没起来（DevToolsActivePort 没出现）')
  const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
  ws = new WebSocket(list.find((t) => t.type === 'page').webSocketDebuggerUrl)
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject })
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data)
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id)
      m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result)
    } else if (m.method) events.push(m)
  }
  await cmd('Page.enable'); await cmd('Runtime.enable'); await cmd('Network.enable'); await cmd('Console.enable')
  const cookie = authCookie()
  await cmd('Network.setCookie', { name: cookie.name, value: cookie.value, domain: '127.0.0.1', path: '/', httpOnly: true })
  await cmd('Page.navigate', { url: BASE + '/' })
  await sleep(3200)
  for (let i = 0; i < 24; i++) {
    if (await clickAny('点击画面跳过')) { await sleep(900); break }
    await sleep(350)
  }
  for (let i = 0; i < 12; i++) {
    const a = await clickText('继续')
    const b = await clickText('知道了')
    if (!a && !b) break
    await sleep(400)
  }
  await clickAny('鱼神双子星')
  await sleep(1400)
  for (let i = 0; i < 5; i++) { if (!(await clickText('知道了'))) break; await sleep(250) }
  for (let i = 0; i < 40; i++) {
    if (await ev(`Boolean(document.querySelector('.ysn-root'))`)) break
    await sleep(250)
  }
  await ev(`(()=>{const b=[...document.querySelectorAll('button')].find((x)=>x.textContent.trim()==='关' && x.offsetParent); if(b){b.click();return true} return false})()`)
  await sleep(300)
  await sleep(400)
  return { browser, profile }
}

async function main() {
  let browserPath = findBrowser()
  if (!browserPath) {
    console.log('SKIP 没找到 Edge/Chrome；鱼窝浏览器验收跳过')
    return
  }
  try {
    const health = await fetch(BASE + '/', { method: 'GET' })
    if (!health.ok && health.status !== 401) throw new Error(`HTTP ${health.status}`)
  } catch (e) {
    console.log(`SKIP 连不上 ${BASE}：${e.message}`)
    return
  }

  const { browser, profile } = await boot(browserPath)
  try {
    await setSize(1440, 960)
    const wide = JSON.parse(await measure())
    record('三只都在窝里', wide.slots.length === 3 && wide.names.every((n) => n.text.trim()),
      `slots=${wide.slots.length} names=${wide.names.map((n) => n.text).join('/')}`)
    record('三张形象都出图', wide.imgs.every((img) => img.src && img.natural && img.natural[0] > 0 && img.rect && img.rect.h > 80),
      wide.imgs.map((img) => `${img.natural?.[0]}x${img.natural?.[1]} → ${Math.round(img.rect?.w || 0)}x${Math.round(img.rect?.h || 0)}`).join(' / '))
    record('身后没有可见光环/特效', wide.halos.filter((h) => h.visible).length === 0,
      `halos=${wide.halos.length} visible=${wide.halos.filter((h) => h.visible).length}`)
    record('头顶位阶/经验条（无圈）', wide.crowns.every((c) => c.rings === 0 && c.fill && c.text.includes('经验')),
      wide.crowns.map((c) => `${c.rings}环 ${c.text.replace(/\s+/g, ' ')}`).join(' / '))
    record('站位都在舞台内', wide.imgs.every((img) => img.rect && img.rect.x >= wide.stage.x - 2 && img.rect.x + img.rect.w <= wide.stage.x + wide.stage.w + 2),
      wide.imgs.map((img) => `${Math.round(img.rect?.x || 0)}..${Math.round((img.rect?.x || 0) + (img.rect?.w || 0))}`).join(' / '))
    record('名字没被浮层盖住', wide.nameHits.every((hit) => hit === 'own'), `hits=${wide.nameHits.join('/')}`)
    {
      const at = (role) => wide.roles.indexOf(role)
      const mid = (i) => wide.imgs[i].rect.x + wide.imgs[i].rect.w / 2
      const h = (role) => wide.imgs[at(role)]?.rect.h || 0
      const y = (role) => wide.imgs[at(role)]?.rect.y || 0
      const txt = (role) => wide.names[at(role)]?.text || ''
      // 2026-10-30 老板定「先改平」：三个人一样高、一样大，不排主次；只换位置和颜色。
      record('三人一样高：没有主次（改平），左→中→右是大鱼/照微/小鱼',
        at('dragon') >= 0 && at('dayu') >= 0 && at('xiaoyu') >= 0
        && Math.abs(h('dragon') - h('dayu')) / Math.max(1, h('dayu')) < 0.03
        && Math.abs(h('xiaoyu') - h('dayu')) / Math.max(1, h('dayu')) < 0.03
        && Math.abs(y('dragon') - y('dayu')) < 4
        && Math.abs(y('xiaoyu') - y('dayu')) < 4
        && mid(at('dayu')) < mid(at('dragon')) && mid(at('dragon')) < mid(at('xiaoyu'))
        && txt('dragon').includes('顾问') && txt('dragon').includes('五境')
        && txt('dayu').includes('副总裁') && txt('dayu').includes('阶位3')
        && txt('xiaoyu').includes('秘书') && txt('xiaoyu').includes('阶位2'),
        `${wide.roles.map((r) => `${r}:${Math.round(h(r))}@${Math.round(y(r))}`).join(' ')} · ${txt('dragon')} / ${txt('dayu')} / ${txt('xiaoyu')}`)
    }
  // 2026-10-28 改口径：浮层**不许被压下去**（压下去就看不见，别人没法拖）
  record('桌面浮层没被压下去（可以拖）', !wide.petZ || Number(wide.petZ) >= 9000, `petZ=`)
    record('页面没有横向溢出', wide.overflow.sw <= wide.overflow.cw + 2, `${wide.overflow.sw}/${wide.overflow.cw}`)
    record('底栏在视口内', wide.foot.y + wide.foot.h <= wide.viewport[1] + 1, `foot=${wide.foot.y}+${wide.foot.h} viewport=${wide.viewport[1]}`)
    {
      const charH = () => ev(`document.querySelector('.ysn-character').getBoundingClientRect().height`)
      const h0 = await charH()
      await ev(`document.querySelectorAll('.ysn-zoom-btn')[2].click()`)
      await sleep(300)
      const h1 = await charH()
      await ev(`document.querySelectorAll('.ysn-zoom-btn')[1].click()`)
      await sleep(300)
      const h2 = await charH()
      await cmd('Input.dispatchMouseEvent', { type: 'mouseWheel', x: 700, y: 400, deltaX: 0, deltaY: -120 })
      await sleep(300)
      const h3 = await charH()
      await ev(`document.querySelectorAll('.ysn-zoom-btn')[1].click()`)
      await sleep(350)
      record('能放大缩小（按钮 + 滚轮）', h1 > h0 + 8 && Math.abs(h2 - h0) < 4 && h3 > h2 + 4,
        `${Math.round(h0)} → ${Math.round(h1)} → ${Math.round(h2)} → ${Math.round(h3)}`)
    }
    {
      // Alt+滚轮只放大光标下那一只，另外两只不动
      const sizes = () => ev(`[...document.querySelectorAll('.ysn-character')].map((e) => Math.round(e.getBoundingClientRect().height))`)
      const center = await ev(`(() => { const e=document.querySelectorAll('.ysn-fig')[0].getBoundingClientRect(); return {x:e.x+e.width/2,y:e.y+e.height*0.5} })()`)
      const before = await sizes()
      await cmd('Input.dispatchMouseEvent', { type: 'mouseWheel', x: center.x, y: center.y, deltaX: 0, deltaY: -120, modifiers: 1 })
      await sleep(300)
      const after = await sizes()
      record('单只缩放只动她（Alt+滚轮）',
        after[0] > before[0] + 5 && Math.abs(after[1] - before[1]) < 3 && Math.abs(after[2] - before[2]) < 3,
        `${before.join('/')} → ${after.join('/')}`)
      await cmd('Input.dispatchMouseEvent', { type: 'mouseWheel', x: center.x, y: center.y, deltaX: 0, deltaY: 120, modifiers: 1 })
      await sleep(250)
    }
    await shot('nest-1440x960.png')

    // 长按 → 小菜单
    const center = await ev(`(() => { const b=document.querySelectorAll('.ysn-fig')[1].getBoundingClientRect(); return {x:b.x+b.width/2,y:b.y+b.height*0.55} })()`)
    await mouse('mousePressed', center.x, center.y)
    await sleep(720)
    await mouse('mouseReleased', center.x, center.y)
    await sleep(350)
    record('长按能开小菜单', await ev(`Boolean(document.querySelector('.ysn-menu'))`), '第二只')
    await ev(`document.querySelector('.ysn-menu button')?.click()`)
    await sleep(250)

    // 齿轮 → 形象页
    await ev(`document.querySelector('.ysn-icon-btn').click()`)
    await sleep(250)
    record('齿轮菜单能开', await ev(`Boolean(document.querySelector('.ysn-gear'))`), '')
    await clickText('形象')
    await sleep(900)
    record('能进形象页', await ev(`Boolean(document.querySelector('.ysn-subpage')) && (document.body.innerText||'').includes('鱼窝 · 当前角色')`), '')
    await shot('look-page.png')
    await ev(`(() => { const b=[...document.querySelectorAll('button')].find(x=>(x.innerText||'').trim()==='←'); if(b)b.click() })()`)
    await sleep(700)

    // 收编模式开/关
    await clickText('收编桌宠')
    await sleep(200)
    const on = await ev(`document.querySelector('.ysn-catch')?.getAttribute('data-on')`)
    await ev(`document.querySelector('.ysn-catch').click()`)
    await sleep(200)
    const off = await ev(`document.querySelector('.ysn-catch')?.getAttribute('data-on')`)
    record('收编按钮能开也能取消', on === '1' && off === '0', `${on} -> ${off}`)

    // 窄屏
    await setSize(390, 844)
    const narrow = JSON.parse(await measure())
    record('窄屏三个人名都在', narrow.names.every((n) => n.text.trim()) && narrow.nameHits.every((hit) => hit === 'own'),
      `${narrow.names.map((n) => n.text).join('/')} hits=${narrow.nameHits.join('/')}`)
    record('窄屏底栏在视口内', narrow.foot.y + narrow.foot.h <= narrow.viewport[1] + 1, `${narrow.foot.y + narrow.foot.h}/${narrow.viewport[1]}`)
    record('窄屏无横向溢出', narrow.overflow.sw <= narrow.overflow.cw + 2, `${narrow.overflow.sw}/${narrow.overflow.cw}`)
    await shot('nest-390x844.png')

    const errors = events.filter((e) => e.method === 'Runtime.exceptionThrown' || (e.method === 'Runtime.consoleAPICalled' && e.params.type === 'error'))
    record('控制台没有报错', errors.length === 0, `${errors.length} 条`)
  } finally {
    try { browser.kill() } catch { /* 已经退了 */ }
    await sleep(300)
    try { fs.rmSync(profile, { recursive: true, force: true }) } catch { /* 临时目录清不掉也不影响 */ }
  }

  const fail = results.filter((r) => !r.ok)
  console.log(`\n==== ${results.length - fail.length}/${results.length} PASS ====`)
  console.log('截图：' + OUT)
  if (fail.length) {
    for (const f of fail) console.log(`- ${f.name}: ${f.detail}`)
    process.exitCode = 1
  }
}

main().catch((e) => {
  console.error('FAIL', e)
  process.exitCode = 1
})
