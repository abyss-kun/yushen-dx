// 底线：内容是她写的；插件只存、只带、只记；没有就如实说没有。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-bottom-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const bl = await import('../lib/bottomline.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T17:00:00+08:00')

// 1) 先建模板：只建一次，且不算"她写过"
bl.ensureBottomline(ROLE)
const template = bl.readBottomline(ROLE)
assert.match(template, /我的底线/)
assert.equal(bl.writtenText(ROLE), '', '模板不算写')
let st = bl.bottomlineStatus(ROLE)
assert.equal(st.ready, true)
assert.equal(st.used, false, '没写没拒过 = 还没接上')
assert.equal(bl.bottomlineBrief(ROLE), '', '没写就不带到注入里，不编')

// 2) 她自己写：旧版留备份，内容归她
bl.writeBottomline(ROLE, '- 我不替老板做决定\n- 我不装作记得', { now: NOW })
assert.match(bl.readBottomline(ROLE), /不替老板做决定/)
assert.equal(bl.writtenText(ROLE).includes('不装作记得'), true)
st = bl.bottomlineStatus(ROLE)
assert.equal(st.written, true)
assert.equal(st.used, true)
assert.match(bl.bottomlineBrief(ROLE), /不替老板做决定/)
bl.writeBottomline(ROLE, '- 我不装作记得', { now: NOW + 1000 })
assert.ok(fs.existsSync(path.join(HOME, 'dayu', 'runtime', ROLE, 'bottom-line.md.bak')), '改之前留一份')

// 3) 她说「不」：记一条，不解释
const r1 = bl.recordRefusal(ROLE, { what: '替他决定发不发那条消息', who: '老板', why: '那是他的事', at: NOW + 2000 })
assert.equal(r1.what, '替他决定发不发那条消息')
assert.match(bl.bottomlineBrief(ROLE), /你最近说过的不/)
assert.equal(bl.listRefusals(ROLE, { limit: 10 }).length, 1)

// 4) 空的不算
assert.throws(() => bl.recordRefusal(ROLE, { what: '  ' }), /拒了什么/)
assert.throws(() => bl.writeBottomline(ROLE, '   '), /空的不算/)

// 5) 太长挡住：只留真的会守的
assert.throws(() => bl.writeBottomline(ROLE, '一'.repeat(1300)), /太长了/)

// 6) 礼物：底线这件，写没写/拒没拒分开算
const gift = rt.giftStatus(ROLE).find((g) => g.id === 'bottomline')
assert.equal(gift.ready, true)
assert.equal(gift.used, true)
assert.match(gift.detail, /写过/)

// 7) 从没写过也没拒过的角色：礼物必须如实说"还没"
const R2 = 'dragon'
rt.ensureRuntime(R2)
const g2 = rt.giftStatus(R2).find((g) => g.id === 'bottomline')
assert.equal(g2.used, false)
assert.match(g2.detail, /还没写过/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, templateOnly: true, hers: true, refusal: true, emptyRejected: true, giftHonest: true }))
