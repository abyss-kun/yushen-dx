// 导入自检：把每个模块真的 import 一遍。
//
// 为什么要有（2026-10-27 的真实事故）：
//   lib/body-loop.js 用了 os.homedir() 却没 `import os`。`node --check` 只查语法，
//   查不出"未定义变量"——语法完全合法。结果插件 apply 时抛 ReferenceError，
//   **整个鱼神插件没起来**：她的工具全消失、所有 /api/dayu/* 都 401。
//   冒烟 12 条全过、回归 84 条全过，照样没发现。
//
// 这个脚本干的事：把 lib/*.js、dayu/*.js、index.js 全部 import 一遍，谁炸谁红。
// 用法：node scripts/import-check.mjs
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

function list(dir) {
  try {
    return fs.readdirSync(path.join(ROOT, dir))
      .filter((n) => n.endsWith('.js'))
      .map((n) => `${dir}/${n}`)
  } catch { return [] }
}

const files = [
  ...list('lib'),
  ...list('dayu'),
  ...['index.js'].filter((n) => { try { return fs.statSync(path.join(ROOT, n)).isFile() } catch { return false } }),
]

let pass = 0
const bad = []
for (const rel of files) {
  try {
    await import(pathToFileURL(path.join(ROOT, rel)).href)
    pass += 1
  } catch (e) {
    bad.push({ rel, message: String(e?.message || e) })
  }
}

if (bad.length) {
  console.error(`导入失败 ${bad.length} 个（共 ${files.length}）：`)
  for (const b of bad) console.error(`  ✗ ${b.rel} → ${b.message}`)
  process.exit(1)
}
console.log(`导入自检：${pass} 个模块全部能 import（未定义变量这类错会在这里红）`)
