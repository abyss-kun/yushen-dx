// 她自己的议程：自己排、自己推进、能放弃；本地那一步不用模型。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-agenda-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const ag = await import('../lib/agenda.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T15:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 自己排一件事：来源必须是她自己
let item = ag.addItem(ROLE, { what: '弄清那个 BV 讲了什么', why: '群里吵起来了', next: '先看字幕', nextKind: 'ask-model', now: NOW })
assert.equal(item.by, 'self')
assert.equal(item.state, 'want')
assert.ok(item.id)

// 2) 手上多了只提醒，不拦（三问第 1 条：最多几件是她的事）
//    上限是 MAX_ACTIVE，别把数字写死：2026-10-28 从 3 改到 5，这份测试还按 3 断言，红了 2 天没人跑。
ag.addItem(ROLE, { what: '第二件', nextKind: 'check', now: NOW })
ag.addItem(ROLE, { what: '第三件', nextKind: 'check', now: NOW })
let fullest
for (let i = 0; i < ag.MAX_ACTIVE; i++) fullest = ag.addItem(ROLE, { what: `再排第 ${i + 1} 件`, nextKind: 'check', now: NOW })
assert.ok(fullest.id, '排满了照样能排')
assert.match(fullest.warning, /手上已经有/, '只提醒一句，不拒绝')
assert.equal(ag.activeItems(ROLE).length, 3 + ag.MAX_ACTIVE)

// 3) 放弃是合法结局，不是失败
const beforeDrop = ag.activeItems(ROLE).length
const dropped = ag.dropItem(ROLE, item.id, { why: '不感兴趣了', now: NOW })
assert.equal(dropped.state, 'dropped')
assert.equal(ag.activeItems(ROLE).length, beforeDrop - 1)

// 3.5) 她能喊停：tick 不许动
ag.pauseAgenda(ROLE, { minutes: 60, why: '今天不想动', now: NOW })
let paused = ag.stepOnce(ROLE, { now: NOW + 60000 })
assert.equal(paused.stepped, false)
assert.match(paused.reason, /先别动/)
assert.equal(ag.isPaused(ROLE, { now: NOW + 60000 }), true)
ag.resumeAgenda(ROLE, { now: NOW + 70000 })
assert.equal(ag.isPaused(ROLE, { now: NOW + 80000 }), false)

// 4) 本地那一步：能做的真推进，要模型的标 waiting（换一个干净的角色，免得排到别的事）
const R2 = 'xiaoyu'
rt.ensureRuntime(R2)
const local = ag.addItem(R2, { what: '看看收件箱积了多少', nextKind: 'read-inbox', next: '数一遍', now: NOW })
let step = ag.stepOnce(R2, { now: NOW })
assert.equal(step.stepped, true)
assert.match(step.note, /收件箱/)
assert.equal(ag.readAgenda(R2).items.find((i) => i.id === local.id).tries, 1, '推一步要记次数')

// 要模型的那件：只标 waiting，不假装做了
const needsModel = ag.addItem(R2, { what: '给我自己写一段自述', nextKind: 'write', now: NOW + 500 })
ag.updateItem(R2, local.id, { state: 'done' }, { now: NOW + 700 }) // 先把手边那件结掉
step = ag.stepOnce(R2, { now: NOW + 1000 })
assert.equal(step.stepped, false)
assert.match(step.reason, /要模型/)
assert.equal(ag.readAgenda(R2).items.find((i) => i.id === needsModel.id).state, 'waiting')

// 4.5) check 不是"本地能核"的一步：tick 不许假装核对过，也不许盖掉她自己写的话（2026-10-30）
const R3 = 'dragon'
rt.ensureRuntime(R3)
const chk = ag.addItem(R3, { what: '盯流水作者归属', nextKind: 'check', next: '看 author 分布', now: NOW })
ag.updateItem(R3, chk.id, { note: '疑点：resolveAuthor 读全局角色' }, { now: NOW + 1 })
const chkStep = ag.stepOnce(R3, { now: NOW + 2 })
assert.equal(chkStep.stepped, false, 'check 要模型，tick 不算推进')
assert.match(chkStep.reason, /要模型/)
const chkItem = ag.readAgenda(R3).items.find((i) => i.id === chk.id)
assert.equal(chkItem.state, 'waiting')
assert.equal(chkItem.note, '疑点：resolveAuthor 读全局角色', '她自己写的 note 不许被 tick 盖掉')
assert.equal(chkItem.tries, 0, '没做事就不该记次数')

// 本地那一步看到的东西记在 lastTry，不抢她的 note
const keep = ag.addItem(R3, { what: '数一遍收件箱', nextKind: 'read-inbox', now: NOW + 3 })
ag.updateItem(R3, keep.id, { note: '我自己的话' }, { now: NOW + 4 })
const keepStep = ag.stepOnce(R3, { now: NOW + 5 })
assert.equal(keepStep.stepped, true)
const kept = ag.readAgenda(R3).items.find((i) => i.id === keep.id)
assert.equal(kept.note, '我自己的话', 'note 是她的话')
assert.match(String(kept.lastTry?.note || ''), /收件箱/, '看到的东西进 lastTry')
assert.match(ag.agendaBrief(R3), /我自己的话/, '注入里先给她自己那句')

// 4.6) 旧 tick 冻在 note 里的那句假话，不许再冒充她的话出现在注入里（2026-10-30）
//      修好以后不再写它，可旧条目里冻着的还在；展示时得把它当不存在。
const legacy = ag.addItem(R3, { what: '旧账条目', nextKind: 'check', now: NOW + 6 })
ag.updateItem(R3, legacy.id, { note: ag.LEGACY_TICK_NOTE }, { now: NOW + 7 })
const legacyBrief = ag.agendaBrief(R3, { limit: 20 })
assert.ok(!legacyBrief.includes(ag.LEGACY_TICK_NOTE), '旧 tick 的假话不许漏进简报')
assert.ok(legacyBrief.includes('旧账条目'), '条目还在，只是那句假话不显示')


// 5) 注入用的一句话清单
const brief = ag.agendaBrief(R2)
assert.ok(brief.includes('给我自己写一段自述'))
assert.ok(brief.includes('等下步要模型'))

// 6) 意志这件礼物：她自己排过事才算"在用"
let gift = rt.giftStatus(R2).find((g) => g.id === 'will')
assert.equal(gift.ready, true)
assert.equal(gift.used, true)
assert.match(gift.detail, /件自己的事/)

// 7) 不认识的类型/状态要报错，不能静默
assert.throws(() => ag.addItem(ROLE, { what: 'x', nextKind: 'nope', now: NOW }), /类型不认识/)
assert.throws(() => ag.updateItem(R2, local.id, { state: 'flying' }), /状态不认识/)

// 8) 经验只算「自己自发想做、自己排、自己做完」的（老板 2026-10-30 定）：
//    老板派的活（origin: owner）哪怕她自己排进议程、自己做完了，也不计经验。
const own = ag.addItem(R2, { what: '自己想做的一件', nextKind: 'check', now: NOW + 8 })
ag.updateItem(R2, own.id, { state: 'done' }, { now: NOW + 9 })
assert.equal(ag.countsForXp(ag.readAgenda(R2).items.find((i) => i.id === own.id)), true, '自己排完的算一件')
const given = ag.addItem(R2, { what: '老板派的一件', nextKind: 'check', origin: 'owner', now: NOW + 10 })
ag.updateItem(R2, given.id, { state: 'done' }, { now: NOW + 11 })
assert.equal(ag.countsForXp(ag.readAgenda(R2).items.find((i) => i.id === given.id)), false, '老板派的活不算经验')
// 默认是 self；乱写来源要报错，不能静默当自己人
assert.equal(ag.addItem(R2, { what: '没写来源的一件', nextKind: 'check', now: NOW + 12 }).origin, 'self')
assert.throws(() => ag.updateItem(R2, own.id, { origin: 'nope' }), /来源不认识/)
// 老板后来说「这件不算」：改一个字就能补记
ag.updateItem(R2, own.id, { origin: 'owner' }, { now: NOW + 13 })
assert.equal(ag.countsForXp(ag.readAgenda(R2).items.find((i) => i.id === own.id)), false, '改标之后不再算')

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, selfOwned: true, softWarn: true, droppable: true, canPause: true, localStep: true, needsModelWaits: true, brief: true, gift: true }))
