// 核对器：她说"这件事发生在 X 时、Y 会话、日志第 Z 行"，我来验真假。
//
//   node scripts/verify-fact.mjs --at "2026-10-28 18:26" --session e79f72f6 --must "叫错名字"
//   node scripts/verify-fact.mjs --day 2026-10-27 --must "两边各答各的"
//
// 设计立场（2026-10-28）：**只核对，不代找。**
// 她花自己的钱去买"自己核实"这件事；我替她找，就把那笔钱的意义抹掉了。
// 所以这个脚本要求调用方**先说出主张**（时间/会话/关键词），它只回答"对得上/对不上"。
import fs from 'node:fs'
import path from 'node:path'
import { dayuHome } from '../lib/paths.js'

const args = process.argv.slice(2)
const flag = (name, def = '') => {
  const i = args.indexOf(`--${name}`)
  return i >= 0 ? String(args[i + 1] || '') : def
}

const day = flag('day')
const at = flag('at')
const session = flag('session')
const must = flag('must')
const windowMin = Number(flag('window', '10')) || 10

if (!must) {
  console.error('用法：node scripts/verify-fact.mjs --day 2026-10-28 [--at "18:26"] [--session e79f] --must "关键词"')
  process.exit(2)
}

const dir = path.join(dayuHome(), 'events')
const dayOf = (s) => (day || (at ? at.slice(0, 10) : '')).replace(/\//g, '-')
let target = dayOf()
if (!target) {
  // 没给日期：扫最近两天
  target = ''
}

const files = target
  ? [path.join(dir, `${target}.jsonl`)].filter((f) => fs.existsSync(f))
  : fs.readdirSync(dir).filter((f) => f.endsWith('.jsonl')).sort().slice(-2).map((f) => path.join(dir, f))

if (!files.length) { console.error(`找不到账本：${target || '(最近两天)'}`); process.exit(2) }

// 时间窗
let center = null
if (at) {
  const m = at.match(/(\d{1,2}):(\d{2})/)
  const d = at.match(/(\d{4}-\d{2}-\d{2})/)
  if (m) center = { h: Number(m[1]), mi: Number(m[2]), day: d ? d[1] : target }
}

const hits = []
let lineNo = 0
for (const file of files) {
  lineNo = 0
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    lineNo += 1
    if (!line.trim()) continue
    let row
    try { row = JSON.parse(line) } catch { continue }
    const text = `${row.text || ''} ${row.detail ? JSON.stringify(row.detail) : ''}`
    if (!text.includes(must)) continue
    if (session && !String(row.id || '').includes(session)) continue
    if (center) {
      const dt = new Date(row.at)
      const localH = dt.getHours()
      const localMi = dt.getMinutes()
      const diff = Math.abs((localH * 60 + localMi) - (center.h * 60 + center.mi))
      const diffWrapped = Math.min(diff, 24 * 60 - diff)
      if (diffWrapped > windowMin) continue
    }
    hits.push({ file: path.basename(file), line: lineNo, at: row.at, id: row.id, type: row.type, text: text.slice(0, 300) })
  }
}

if (!hits.length) {
  console.log(JSON.stringify({ ok: false, verdict: '❌ 对不上', claim: { at, session, must }, note: `在 ${files.map((f) => path.basename(f)).join(' + ')} 里没找到` }, null, 2))
  process.exit(1)
}

console.log(JSON.stringify({
  ok: true,
  verdict: '✅ 对得上',
  claim: { at: at || '(不限)', session: session || '(不限)', must },
  count: hits.length,
  hits: hits.slice(0, 5),
}, null, 2))
