// 按行删：找 `export function NAME` 到下一个行首的 `}`，整段删掉。
// 比括号配对稳——这些文件的风格是函数结束就一个顶格的 }。
//
//   node scripts/prune-by-lines.mjs --dry
//   node scripts/prune-by-lines.mjs
//
// 每个文件先 .bak；改完 node --check；不过就还原。
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DRY = process.argv.includes('--dry')
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)

const TARGETS = [
  ['lib/employee-profile.js', 'describeEmployee'],
  ['lib/hands.js', 'handsLine'],
  ['lib/memory.js', 'visibleEvents'],
  ['lib/memory.js', 'touchMemory'],
  ['lib/mind-store.js', 'getMindItem'],
  ['lib/mind-store.js', 'reviseMindItem'],
  ['lib/mind-store.js', 'recordQuestion'],
  ['lib/mind-store.js', 'recordOwnerPreference'],
  ['lib/scene-pack.js', 'findScene'],
  ['lib/transcript.js', 'pruneCache'],
  ['lib/recap.js', 'readRecap'],
  ['lib/bodies.js', 'bodiesLine'],
  ['lib/board.js', 'setLevel'],
  ['lib/schema.js', 'ensureSchema'],
  ['lib/crash.js', 'recentCount'],
]

function spanOf(lines, name) {
  const re = new RegExp(`^export (async )?function ${name}\\s*\\(`)
  const start = lines.findIndex((l) => re.test(l))
  if (start < 0) return null
  // 往上吃掉紧贴的注释块
  let s = start
  while (s > 0 && /^\s*\*/.test(lines[s - 1])) s -= 1
  if (s > 0 && /^\/\*\*/.test(lines[s - 1])) s -= 1
  for (let i = start + 1; i < lines.length; i += 1) {
    // CRLF 文件行尾带 \r，直接比 '}' 会永远配不上——这就是上一轮"没找到"的原因。
    if (lines[i].replace(/\r$/, '') === '}') return { start: s, end: i }
  }
  return null
}

const byFile = new Map()
for (const [f, n] of TARGETS) {
  if (!byFile.has(f)) byFile.set(f, [])
  byFile.get(f).push(n)
}

let changed = 0
for (const [rel, names] of byFile) {
  const abs = path.join(ROOT, rel)
  if (!fs.existsSync(abs)) continue
  const original = fs.readFileSync(abs, 'utf8')
  let lines = original.split('\n')
  const log = []
  for (const n of names) {
    const sp = spanOf(lines, n)
    if (!sp) { log.push(`${n} ✗ 没找到`); continue }
    const size = sp.end - sp.start + 1
    if (size < 1 || size > 400) { log.push(`${n} ✗ 跨 ${size} 行，可疑`); continue }
    lines = [...lines.slice(0, sp.start), ...lines.slice(sp.end + 1)]
    log.push(`${n}(-${size}行)`)
  }
  const text = lines.join('\n')
  if (text === original) { console.log(`${rel}: 没变（${log.join('、')}）`); continue }
  if (DRY) { console.log(`[dry] ${rel}: ${log.join('、')}`); changed += 1; continue }
  const bak = `${abs}.bak-${stamp}`
  fs.writeFileSync(bak, original, 'utf8')
  fs.writeFileSync(abs, text, 'utf8')
  try {
    execFileSync(process.execPath, ['--check', abs], { stdio: 'pipe' })
    console.log(`${rel}: ${log.join('、')}  ✓`)
    changed += 1
  } catch (e) {
    fs.copyFileSync(bak, abs)
    console.log(`${rel}: ✗ 语法不过，已还原（${String(e?.stderr || e?.message || e).slice(0, 80)}）`)
  }
}
console.log(`\n${DRY ? '会改' : '改了'} ${changed} 个文件`)
