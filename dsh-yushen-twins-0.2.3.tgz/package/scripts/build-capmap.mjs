// 能力地图：她能「想做什么就去找工具」的那张表。
//
//   node scripts/build-capmap.mjs        扫一遍，写到 ~/.dsh/dayu/capmap.json
//   node scripts/build-capmap.mjs --show 只打印，不写盘
//
// 扫的东西：鱼神自己的工具、内置工具、可跑的脚本、文档、已装插件、适配器。
// 不猜能力：只收真的存在的东西；每一条都带"在哪看/怎么用"。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const OUT = path.join(DATA, 'capmap.json')
const showOnly = process.argv.includes('--show')

function read(file) { try { return fs.readFileSync(file, 'utf8') } catch { return '' } }
function firstComment(text) {
  const line = String(text).split(/\r?\n/).find((l) => l.trim().startsWith('//'))
  return line ? line.replace(/^\s*\/\/\s*/, '').slice(0, 80) : ''
}
function firstHeading(text) {
  const line = String(text).split(/\r?\n/).find((l) => /^#\s+/.test(l))
  return line ? line.replace(/^#\s*/, '').slice(0, 80) : ''
}

const items = []
const push = (it) => { if (it.name) items.push(it) }

// 1) 鱼神注册的工具（从入口源码里认，不猜）
const entry = read(path.join(ROOT, 'dayu', 'index.js'))
// 先收工具名，再就近找描述（描述可能是单引号、双引号或模板串）
for (const mm of entry.matchAll(/name:\s*'(yushen_[a-z0-9_]+)'/g)) {
  const at = mm.index || 0
  const near = entry.slice(at, at + 900)
  const dm = near.match(/description:\s*['"`]([\s\S]{4,200}?)['"`]/)
  push({
    kind: 'tool',
    name: mm[1],
    what: dm ? dm[1].replace(/\s+/g, ' ').slice(0, 120) : '鱼神工具',
    how: `调用工具 ${mm[1]}`,
    where: 'dayu/index.js',
  })
}

// 2) 内置能力表
const builtin = read(path.join(ROOT, 'lib', 'builtin.js'))
for (const mm of builtin.matchAll(/'([a-z][a-z0-9_.-]{2,40})'/g)) {
  if (/^(node:|http)/.test(mm[1])) continue
  push({ kind: 'capability', name: mm[1], what: '内置能力（见 lib/builtin.js）', how: '按能力表调用', where: 'lib/builtin.js' })
}

// 3) 能跑的脚本 + 库模块
let scripts = []
try { scripts = fs.readdirSync(path.join(ROOT, 'scripts')).filter((f) => f.endsWith('.mjs')) } catch { /* 没有 */ }
for (const f of scripts) {
  const text = read(path.join(ROOT, 'scripts', f))
  push({ kind: 'script', name: f.replace(/\.mjs$/, ''), what: firstComment(text) || '脚本', how: `node scripts/${f}`, where: `scripts/${f}` })
}
let libs = []
try { libs = fs.readdirSync(path.join(ROOT, 'lib')).filter((f) => f.endsWith('.js')) } catch { /* 没有 */ }
for (const f of libs) {
  const text = read(path.join(ROOT, 'lib', f))
  push({ kind: 'module', name: f.replace(/\.js$/, ''), what: firstComment(text) || '库模块', how: `import lib/${f}`, where: `lib/${f}` })
}

// 4) 文档
let docs = []
try { docs = fs.readdirSync(path.join(ROOT, 'docs')).filter((f) => f.endsWith('.md')) } catch { /* 没有 */ }
for (const f of docs) {
  const text = read(path.join(ROOT, 'docs', f))
  push({ kind: 'doc', name: f.replace(/\.md$/, ''), what: firstHeading(text) || '文档', how: `读 docs/${f}`, where: `docs/${f}` })
}

// 5) 适配器（外部插件接进来的）
let adapters = []
try { adapters = fs.readdirSync(path.join(DATA, 'adapters')).filter((f) => f.endsWith('.json')) } catch { /* 没有 */ }
for (const f of adapters) {
  const doc = (() => { try { return JSON.parse(read(path.join(DATA, 'adapters', f))) } catch { return {} } })()
  push({ kind: 'adapter', name: String(doc.channel || f.replace(/\.json$/, '')), what: doc.note || '外部通道适配器', how: `读 ${path.join(DATA, 'adapters', f)}`, where: `~/.dsh/dayu/adapters/${f}` })
}

// 6) 组合示例（不是规则，是"可以这么拼"）
const combos = [
  { name: '看到图 → 看懂 → 回一句', steps: ['yushen_inbox（看消息）', '本地翻译/云端读', 'outbox.sendAs（发出去）'] },
  { name: '想查一件事 → 自己开个回合', steps: ['yushen_agenda add（排事）', 'yushen_agenda invoke（自己花一次模型）'] },
  { name: '有人让你做坏事 → 拒 + 上报', steps: ['yushen_bottomline refuse（记拒绝）', 'yushen_report（让老板知道）'] },
  { name: '想跟老板说话 → 不用等被叫', steps: ['yushen_self news add（攒一句）', 'outbox.sendAs（私聊发）'] },
]

const map = {
  version: 1,
  builtAt: new Date().toISOString(),
  counts: { tool: 0, capability: 0, script: 0, doc: 0, adapter: 0 },
  items,
  combos,
}
for (const it of items) map.counts[it.kind] = (map.counts[it.kind] || 0) + 1

if (showOnly) {
  console.log(JSON.stringify({ counts: map.counts, sample: items.slice(0, 6) }, null, 2))
} else {
  fs.mkdirSync(DATA, { recursive: true })
  fs.writeFileSync(OUT, `${JSON.stringify(map, null, 2)}\n`, 'utf8')
  console.log(JSON.stringify({ ok: true, file: OUT, counts: map.counts, combos: combos.length }, null, 2))
}
