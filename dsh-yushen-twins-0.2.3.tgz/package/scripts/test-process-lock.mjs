// 鱼神双子星 · process-lock 自测
// 只在系统临时目录里造锁文件，跑完全部清掉；不启动 watchdog、不碰真实 ~/.dsh、不动任何进程。
// 覆盖：同进程多持有者 / 释放只删自己 / 真实子进程竞争 / 死 PID 回收 / 坏锁保守策略 /
//       重读验证（内容被换就不删）/ 重试上限 / EPERM 当存活 / 嵌套目录自动创建。
//
// 运行：C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe dsh-yushen-twins/scripts/test-process-lock.mjs

import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import {
  acquireLock,
  createLock,
  processAlive,
  readLock,
  releaseLock,
} from '../lib/process-lock.js'

const LIB = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'process-lock.js')
const LIB_URL = pathToFileURL(LIB).href
const BASE = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-process-lock-'))

let passed = 0
let failed = 0
const failures = []

async function check(name, fn) {
  try {
    await fn()
    passed += 1
    console.log(`  ok   ${name}`)
  } catch (err) {
    failed += 1
    failures.push({ name, err })
    console.log(`  FAIL ${name}`)
    console.log(`       ${err && err.message ? err.message : err}`)
  }
}

function lockPath(label) {
  return path.join(BASE, label, 'test.lock')
}

function writeText(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, text, 'utf8')
}

function writeLock(file, payload) {
  writeText(file, `${JSON.stringify(payload)}\n`)
}

function cleanup(file) {
  try { fs.rmSync(file, { force: true }) } catch { /* 收尾 */ }
}

function spawnExitedChild() {
  // 拉起一个立刻退出的子进程，拿它的 pid 当“确定已死的 PID”。
  const child = spawn(process.execPath, ['-e', 'process.exit(0)'], { stdio: 'ignore', windowsHide: true })
  const pid = child.pid
  return new Promise((resolve) => {
    child.on('exit', () => resolve(pid))
    child.on('error', () => resolve(pid))
  })
}

// 竞争对手：先写 ready 文件，等父进程放下 GO 文件后同时起跑，避免“谁先启动谁赢”的假竞争。
function startContender(id, lockFile) {
  const dir = path.join(BASE, 'race')
  fs.mkdirSync(dir, { recursive: true }) // 子进程要先写 ready 文件
  const resultFile = path.join(dir, `result-${id}.json`)
  const readyFile = path.join(dir, `ready-${id}.flag`)
  const goFile = path.join(dir, 'go.flag')
  const script = `
import fs from 'node:fs'
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
fs.writeFileSync(process.env.READY_FILE, '1', 'utf8')
let waited = 0
while (!fs.existsSync(process.env.GO_FILE)) {
  if (waited > 15000) process.exit(2)
  await sleep(10)
  waited += 10
}
const mod = await import(process.env.LOCK_LIB_URL)
const lock = mod.createLock(process.env.LOCK_FILE, { attempts: 2, retryDelayMs: 50, graceMs: 2000 })
const won = await lock.acquire()
let stillMine = null
if (won) {
  await new Promise((resolve) => setTimeout(resolve, 1200))
  const info = mod.readLock(process.env.LOCK_FILE)
  stillMine = Boolean(info.exists && info.parsed && info.parsed.token === lock.token)
  lock.release()
}
fs.writeFileSync(process.env.RESULT_FILE, JSON.stringify({ id: process.env.LOCK_ID, won, stillMine }), 'utf8')
process.exit(0)
`
  const done = new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', script], {
      stdio: 'ignore',
      windowsHide: true,
      env: {
        ...process.env,
        LOCK_LIB_URL: LIB_URL,
        LOCK_FILE: lockFile,
        RESULT_FILE: resultFile,
        READY_FILE: readyFile,
        GO_FILE: goFile,
        LOCK_ID: String(id),
      },
    })
    child.on('error', reject)
    child.on('exit', (code) => {
      if (code !== 0) return reject(new Error(`竞争者 ${id} 退出码 ${code}`))
      try {
        resolve(JSON.parse(fs.readFileSync(resultFile, 'utf8')))
      } catch (err) {
        reject(new Error(`竞争者 ${id} 没留下结果：${err.message}`))
      }
    })
  })
  return { id, readyFile, goFile, done }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function waitForFile(file, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs
  while (!fs.existsSync(file)) {
    if (Date.now() > deadline) throw new Error(`等待文件超时：${file}`)
    await sleep(20)
  }
}

// ---------------- 基本抢锁 / 同进程多持有者 ----------------

await check('抢锁：写入 pid/token，同进程第二个持有者被挡，释放后可再抢', async () => {
  const file = lockPath('basic')
  const a = createLock(file)
  assert.equal(a.held, false)
  assert.equal(await a.acquire(), true)
  assert.equal(a.held, true)

  const info = readLock(file)
  assert.equal(info.exists, true)
  assert.equal(info.parsed.pid, process.pid)
  assert.equal(info.parsed.token, a.token)
  assert.equal(typeof info.parsed.at, 'string')
  assert.equal(typeof info.parsed.host, 'string')

  const b = createLock(file)
  assert.equal(await b.acquire(), false, '同进程里活锁不能抢第二份')
  assert.equal(b.held, false)

  assert.equal(await a.acquire(), true, '已持有者重复 acquire 应幂等')

  assert.equal(a.release(), true)
  assert.equal(fs.existsSync(file), false)
  assert.equal(await b.acquire(), true)
  assert.equal(b.release(), true)
})

await check('抢锁：同进程并发两个句柄，只有一个能拿到', async () => {
  const file = lockPath('concurrent')
  const locks = [createLock(file, { attempts: 2 }), createLock(file, { attempts: 2 })]
  const results = await Promise.all(locks.map((lock) => lock.acquire()))
  assert.equal(results.filter(Boolean).length, 1)
  const winner = locks[results.indexOf(true)]
  assert.equal(winner.held, true)
  assert.equal(winner.release(), true)
  assert.equal(fs.existsSync(file), false)
})

await check('释放：只删自己的 token，别人换过的锁不动', async () => {
  const file = lockPath('release-own')
  const a = createLock(file)
  await a.acquire()

  const intruder = { pid: process.pid, token: 'intruder-token', at: new Date().toISOString() }
  writeLock(file, intruder)

  assert.equal(a.release(), false, 'token 对不上时不能删')
  assert.equal(fs.existsSync(file), true)
  assert.equal(readLock(file).parsed.token, 'intruder-token')

  // 文件已被别人删掉时，释放也不能抛错
  cleanup(file)
  assert.equal(a.release(), false)
  // 没持有时 release 直接 false
  assert.equal(createLock(lockPath('release-unheld')).release(), false)
})

await check('释放：releaseLock 包装不会误删别人的锁', async () => {
  const file = lockPath('release-helper')
  const a = await acquireLock(file)
  assert.ok(a)
  writeLock(file, { pid: process.pid, token: 'other', at: new Date().toISOString() })
  assert.equal(releaseLock(a), false)
  assert.equal(readLock(file).parsed.token, 'other')
  cleanup(file)
})

// ---------------- 存活判定 ----------------

await check('存活：自己活着、死 PID 判死、非法 PID 判死', async () => {
  assert.equal(processAlive(process.pid), true)
  const deadPid = await spawnExitedChild()
  assert.equal(processAlive(deadPid), false)
  assert.equal(processAlive(0), false)
  assert.equal(processAlive(-1), false)
  assert.equal(processAlive(Number.NaN), false)
  assert.equal(processAlive('abc'), false)
  assert.equal(processAlive(3.5), false)
})

await check('存活：EPERM 当存活，ESRCH 当死亡', () => {
  const original = process.kill
  try {
    process.kill = () => {
      const err = new Error('denied')
      err.code = 'EPERM'
      throw err
    }
    assert.equal(processAlive(424242), true, 'EPERM 说明进程存在但没权限，必须当活')

    process.kill = () => {
      const err = new Error('no such process')
      err.code = 'ESRCH'
      throw err
    }
    assert.equal(processAlive(424242), false)
  } finally {
    process.kill = original
  }
})

// ---------------- 失效锁回收 ----------------

await check('死 PID：回收失效锁后能抢到，锁内容换成自己的 token', async () => {
  const file = lockPath('dead-pid')
  const deadPid = await spawnExitedChild()
  writeLock(file, { pid: deadPid, token: 'dead-owner', at: new Date().toISOString() })
  assert.equal(processAlive(deadPid), false)

  const lock = createLock(file, { attempts: 2, retryDelayMs: 0 })
  assert.equal(await lock.acquire(), true)
  const info = readLock(file)
  assert.equal(info.parsed.pid, process.pid)
  assert.equal(info.parsed.token, lock.token)
  assert.equal(lock.release(), true)
})

await check('活 PID 但没 token（老格式）：保守当活锁，不删', async () => {
  const file = lockPath('old-format')
  writeLock(file, { pid: process.pid, at: new Date().toISOString() })

  const lock = createLock(file, { attempts: 2, graceMs: 0 })
  assert.equal(await lock.acquire(), false)
  assert.equal(fs.existsSync(file), true)
  assert.equal(readLock(file).parsed.pid, process.pid)
  cleanup(file)
})

await check('坏锁：默认宽限期内不删，graceMs=0 时才回收', async () => {
  const file = lockPath('broken')
  writeText(file, '这不是 JSON\n')

  const cautious = createLock(file, { attempts: 2 })
  assert.equal(await cautious.acquire(), false, '坏锁太新必须保守等待')
  assert.equal(fs.readFileSync(file, 'utf8'), '这不是 JSON\n', '保守期间一个字节都不能动')

  const forced = createLock(file, { attempts: 2, graceMs: 0 })
  assert.equal(await forced.acquire(), true)
  assert.equal(readLock(file).parsed.token, forced.token)
  assert.equal(forced.release(), true)
})

await check('坏锁：空文件按坏锁处理（宽限/回收都不抛错）', async () => {
  const file = lockPath('empty')
  writeText(file, '')
  assert.equal(await createLock(file, { attempts: 2 }).acquire(), false)
  assert.equal(fs.existsSync(file), true)
  const forced = createLock(file, { attempts: 2, graceMs: 0 })
  assert.equal(await forced.acquire(), true)
  assert.equal(forced.release(), true)
})

await check('回收验证：重读发现内容被换就不删，本次抢锁失败', async () => {
  const file = lockPath('race-reclaim')
  const deadPid = await spawnExitedChild()
  writeLock(file, { pid: deadPid, token: 'old-owner', at: new Date().toISOString() })

  let hijacked = false
  const lock = createLock(file, {
    attempts: 3,
    retryDelayMs: 0,
    hooks: {
      beforeReclaimVerify: ({ file: f }) => {
        if (hijacked) return
        hijacked = true
        writeLock(f, { pid: process.pid, token: 'new-owner', at: new Date().toISOString() })
      },
    },
  })

  assert.equal(await lock.acquire(), false, '内容变了就不能删、也不能硬抢')
  assert.equal(hijacked, true)
  assert.equal(readLock(file).parsed.token, 'new-owner', '别人刚接手的锁必须留着')
  cleanup(file)
})

await check('重试上限：活锁只尝试一次就放弃，文件原样', async () => {
  const file = lockPath('retry-limit')
  writeLock(file, { pid: process.pid, token: 'live-owner', at: new Date().toISOString() })

  let attempts = 0
  const lock = createLock(file, { attempts: 5, hooks: { onAttempt: () => { attempts += 1 } } })
  assert.equal(await lock.acquire(), false)
  assert.equal(attempts, 1, '活锁应立即让路，不该无脑重试')
  assert.equal(readLock(file).parsed.token, 'live-owner')
  cleanup(file)
})

await check('回收次数有上限：坏锁在每次都被改写的极端情况下不会无限重试', async () => {
  const file = lockPath('retry-bounded')
  writeText(file, 'garbage')

  let attempts = 0
  const lock = createLock(file, {
    attempts: 3,
    retryDelayMs: 0,
    graceMs: 0,
    hooks: {
      onAttempt: () => { attempts += 1 },
      // 每次回收前都把内容改掉 → reclaim 永远验证失败
      beforeReclaimVerify: ({ file: f }) => { writeText(f, `garbage-${attempts}`) },
    },
  })
  assert.equal(await lock.acquire(), false)
  assert.ok(attempts <= 3, `重试次数必须受限于 attempts，实际 ${attempts}`)
})

await check('死锁回收 + token 唯一：回收后锁内容不是旧 token', async () => {
  const file = lockPath('token-unique')
  const deadPid = await spawnExitedChild()
  writeLock(file, { pid: deadPid, token: 'stale-token', at: new Date().toISOString() })
  const lock = createLock(file, { attempts: 2, retryDelayMs: 0 })
  assert.equal(await lock.acquire(), true)
  assert.notEqual(readLock(file).parsed.token, 'stale-token')
  assert.equal(lock.release(), true)
})

// ---------------- 路径 / 结构 ----------------

await check('锁文件：父目录不存在会自动创建', async () => {
  const file = path.join(BASE, 'deep', 'a', 'b', 'nested.lock')
  const lock = createLock(file)
  assert.equal(await lock.acquire(), true)
  assert.equal(fs.existsSync(file), true)
  assert.equal(lock.release(), true)
  assert.equal(fs.existsSync(file), false)
})

await check('锁文件：token 可指定，内容带 version/at', async () => {
  const file = lockPath('custom-token')
  const lock = createLock(file, { token: 'fixed-token-123' })
  assert.equal(lock.token, 'fixed-token-123')
  assert.equal(await lock.acquire(), true)
  const info = readLock(file)
  assert.equal(info.parsed.token, 'fixed-token-123')
  assert.equal(info.parsed.version, 1)
  assert.equal(info.parsed.pid, process.pid)
  assert.equal(lock.release(), true)
})

// ---------------- 真实子进程竞争 ----------------

await check('真实子进程竞争：4 个进程同时抢，只有 1 个赢，赢家锁没被对手删', async () => {
  const file = lockPath('race')
  cleanup(file)

  const contenders = [1, 2, 3, 4].map((id) => startContender(id, file))
  // 等 4 个进程全部就位，再放 GO：真正同时起跑，不是“谁先启动谁赢”。
  for (const item of contenders) await waitForFile(item.readyFile)
  const goFile = contenders[0].goFile
  fs.writeFileSync(goFile, 'go', 'utf8')

  const results = await Promise.all(contenders.map((item) => item.done))

  assert.equal(results.length, 4)
  const winners = results.filter((row) => row.won)
  assert.equal(winners.length, 1, `应只有 1 个赢家，实际 ${winners.map((row) => row.id).join(',')}`)
  assert.equal(winners[0].stillMine, true, '赢家释放前锁必须还在它手里（说明输家没删）')
  assert.equal(results.filter((row) => !row.won).length, 3)
  assert.equal(fs.existsSync(file), false, '赢家退出后锁应释放')
})

// ---------------- 收尾 ----------------

fs.rmSync(BASE, { recursive: true, force: true })

console.log('')
console.log(`结果：通过 ${passed}，失败 ${failed}`)
if (failed) {
  console.log('失败明细：')
  for (const item of failures) console.log(` - ${item.name}: ${item.err && item.err.message ? item.err.message : item.err}`)
  process.exitCode = 1
} else {
  console.log('process-lock：全部断言通过')
  process.exitCode = 0
}
