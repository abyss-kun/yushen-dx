import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-creative-'))
process.env.DSH_HOME = home
const { creativeMemoryFile, creativeTopics, recallCreativeMemory, withCreativeMemory } = await import('../lib/creative-memory.js')
try {
  assert.equal(recallCreativeMemory('修复数据库连接'), '')
  const file = creativeMemoryFile()
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, JSON.stringify({schemaVersion:1,sections:[
    {topic:'boundaries',text:'二创不是官方事实，不预写角色感想'},
    {topic:'dragons',text:'白龙金贵高贵；青龙尊贵端庄威仪'},
    {topic:'dayu',text:'大鱼是姐姐'}, {topic:'xiaoyu',text:'小鱼是妹妹'},
    {topic:'ensemble',text:'Claude大小姐可偏心护短，不固定CP'},
    {topic:'sources',text:'BV1xJJo6sED6 第二集只有抽样画面'}]}))
  for (const query of ['你好','今天吃什么','大鱼帮我修bug','小鱼在吗','GPT写一个模型接口','发b站一个数据库教程','读取token预算']) {
    assert.deepEqual(creativeTopics(query), [], query)
    assert.equal(withCreativeMemory(query), query, query)
  }
  for (const query of ['给三个角色做立绘','照微建模','青龙的威仪怎么表现','大鱼小鱼的姐妹关系','她们做视频发b站','Claude大小姐与大肥鱼的关系','https://bilibili.com/video/BV1xJJo6sED6']) {
    const out = recallCreativeMemory(query)
    assert.ok(out.includes('二创不是官方事实'), query)
    assert.ok(out.length <= 3200)
  }
  assert.ok(recallCreativeMemory('给三个角色做立绘').includes('小鱼是妹妹'))
  assert.ok(!recallCreativeMemory('青龙立绘').includes('大鱼是姐姐'))
  const before = fs.readFileSync(file, 'utf8')
  recallCreativeMemory('大鱼小鱼的关系')
  assert.equal(fs.readFileSync(file, 'utf8'), before)
  const { composeBrief } = await import('../core/dispatch.js')
  assert.ok(composeBrief('test','给三个角色做立绘','清晰全身').includes('按需召回'))
  assert.ok(!composeBrief('test','修数据库连接','测试通过').includes('按需召回'))
  fs.writeFileSync(file, '{bad')
  assert.equal(recallCreativeMemory('照微立绘'), '')
  fs.writeFileSync(file, JSON.stringify({schemaVersion:999,sections:[]}))
  assert.equal(recallCreativeMemory('照微立绘'), '')
  console.log('PASS conditional creative recall: relevant, unrelated, bounded, fail-closed, read-only, dispatch')
} finally {
  // Exact temp directory created above, never user data.
  assert.ok(path.basename(home).startsWith('yushen-creative-'))
  fs.rmSync(home, {recursive:true,force:true})
}
