import fs from 'node:fs'

const p = 'C:/Users/Administrator/AppData/Local/Programs/DeepSeek Harness/resources/app.asar'
const fd = fs.openSync(p, 'r')
const h = Buffer.alloc(16)
fs.readSync(fd, h, 0, 16, 0)
const len = h.readUInt32LE(12)
const b = Buffer.alloc(len)
fs.readSync(fd, b, 0, len, 16)
const root = JSON.parse(b.toString('utf8'))
const start = 8 + h.readUInt32LE(4)

function at(mod, rel) {
  let cur = mod
  for (const part of rel.split('/').filter(Boolean)) {
    if (!cur?.files?.[part]) return null
    cur = cur.files[part]
  }
  return cur
}
function text(node) {
  const size = Number(node.size)
  const buf = Buffer.alloc(size)
  fs.readSync(fd, buf, 0, size, start + Number(node.offset))
  return buf.toString('utf8')
}

const nm = root.files.dsh.files.node_modules.files['@deepseek-ai'].files
const mod = nm['dsh-client-connection']
const t = text(at(mod, 'lib/index.js'))
fs.closeSync(fd)
const lines = t.split(/\n/)
const marks = []
for (let i = 0; i < lines.length; i += 1) {
  if (/dsh-auth-|createHmac|expiresAt/.test(lines[i])) marks.push(i)
}
for (const i of [...new Set(marks)].slice(0, 12)) {
  console.log(`--- ${i + 1}`)
  console.log(lines.slice(i, i + 10).join('\n').slice(0, 800))
}
