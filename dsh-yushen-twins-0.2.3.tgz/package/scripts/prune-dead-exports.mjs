// 删掉「只有定义、没人接」的函数导出（2026-10-30 去杂）。
// 只删明确没用到的；被 scripts/ 或 tests/ 用到的**不删**（那是接线，不是死码）。
//
//   node scripts/prune-dead-exports.mjs --dry     # 只报会删什么
//   node scripts/prune-dead-exports.mjs           # 真删（先备份 .bak-时间戳）
//
// 安全：逐个文件备份 → 改 → node --check 语法校验 → 失败就整文件还原。
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DRY = process.argv.includes('--dry')
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)

const TARGETS = [
  ['lib/awakening.js', 'awakeningState'],
  ['lib/employee-profile.js', 'describeEmployee'],
  ['lib/fact-ledger.js', 'factsFile'],
  ['lib/fact-ledger.js', 'supersedeMatter'],
  ['lib/hands.js', 'handsLine'],
  ['lib/inbox.js', 'inboxRoot'],
  ['lib/memory.js', 'visibleEvents'],
  ['lib/mind-store.js', 'getMindItem'],
  ['lib/mind-store.js', 'reviseMindItem'],
  ['lib/mind-store.js', 'revokeMindItem'],
  ['lib/miss.js', 'clearNews'],
  ['lib/owner-guard.js', 'removeSecret'],
  ['lib/perm.js', 'getApproval'],
  ['lib/pool.js', 'removeWorker'],
  ['lib/recap.js', 'readRecap'],
  ['lib/runtime.js', 'runtimeRoot'],
  ['lib/scene-pack.js', 'findScene'],
  ['lib/tastes.js', 'removeTaste'],
  ['lib/transcript.js', 'sessionsRoot'],
  ['lib/transcript.js', 'pruneCache'],
  ['lib/takeover.js', 'listTakeovers'],
  ['lib/backup.js', 'runBackup'],
]

/** 从 `export function NAME(` 起，按花括号配对找到结束位置。跳过字符串和注释。 */
function blockEnd(text, start) {
  let i = text.indexOf('(', start)
  let depth = 0
  let seenParen = false
  let inStr = null
  let inLineComment = false
  let inBlockComment = false
  for (; i < text.length; i += 1) {
    const c = text[i]
    const prev = text[i - 1]
    if (inLineComment) { if (c === '\n') inLineComment = false; continue }
    if (inBlockComment) { if (c === '*' && text[i + 1] === '/') { inBlockComment = false; i += 1 } continue }
    if (inStr) {
      if (c === '\\') { i += 1; continue }
      if (c === inStr) inStr = null
      continue
    }
    if (c === '/' && text[i + 1] === '/') { inLineComment = true; i += 1; continue }
    if (c === '/' && text[i + 1] === '*') { inBlockComment = true; i += 1; continue }
    if (c === '"' || c === "'" || c === '`') { inStr = c; continue }
    if (c === '(') { depth += 1; seenParen = true; continue }
    if (c === ')') { depth -= 1; continue }
    if (c === '{' && seenParen && depth === 0) {
      // 函数体开始：从这往下配平花括号
      let d = 0
      for (let j = i; j < text.length; j += 1) {
        const ch = text[j]
        if (ch === '/' && text[j + 1] === '/') { const nl = text.indexOf('\n', j); j = nl === -1 ? text.length : nl; continue }
        if (ch === '/' && text[j + 1] === '*') { const end = text.indexOf('*/', j + 2); j = end === -1 ? text.length : end + 1; continue }
        if (ch === '"' || ch === "'" || ch === '`') {
          const q = ch
          for (j += 1; j < text.length; j += 1) {
            if (text[j] === '\\') { j += 1; continue }
            if (text[j] === q) break
          }
          continue
        }
        if (ch === '{') d += 1
        else if (ch === '}') { d -= 1; if (d === 0) return j + 1 }
      }
      return -1
    }
  }
  return -1
}

function removeExport(text, name) {
  const re = new RegExp(`^export (async )?function ${name}\\s*\\(`, 'm')
  const m = re.exec(text)
  if (!m) return { ok: false, why: '没找到这个导出（也许不是 function）' }
  const start = m.index
  const end = blockEnd(text, start)
  if (end < 0) return { ok: false, why: '花括号没配平，没敢动' }
  // 连同上方的注释块一起去掉
  let s = start
  const before = text.slice(0, start)
  const cm = /\/\*\*[\s\S]*?\*\/\s*$/.exec(before)
  if (cm) s = cm.index
  let rest = text.slice(0, s).replace(/\s+$/, '') + '\n' + text.slice(end).replace(/^\s*\n/, '\n')
  rest = rest.replace(/\n{3,}/g, '\n\n')
  const removedText = text.slice(s, end)
  const removedLines = removedText.split('\n').length
  // 安全阀：一次删太多行，说明括号配对可能出了问题——宁可不动，交给人看。
  if (removedLines > 40) {
    return { ok: false, why: `这次要删 ${removedLines} 行，太多，可能是配对错了——人工看` }
  }
  if (!/^(\/\*\*[\s\S]*?\*\/\s*)?export (async )?function /.test(removedText)) {
    return { ok: false, why: '删的不是一整个 export function，跳过' }
  }
  return { ok: true, text: rest, removed: removedLines }
}

const byFile = new Map()
for (const [f, n] of TARGETS) {
  if (!byFile.has(f)) byFile.set(f, [])
  byFile.get(f).push(n)
}

let changed = 0
for (const [rel, names] of byFile) {
  const abs = path.join(ROOT, rel)
  if (!fs.existsSync(abs)) { console.log(`跳过（不存在）${rel}`); continue }
  const original = fs.readFileSync(abs, 'utf8')
  let text = original
  const log = []
  for (const n of names) {
    const r = removeExport(text, n)
    if (r.ok) { text = r.text; log.push(`${n}(-${r.removed}行)`) }
    else log.push(`${n} ✗ ${r.why}`)
  }
  if (text === original) { console.log(`${rel}: 没变`); continue }
  if (DRY) { console.log(`[dry] ${rel}: ${log.join('、')}`); changed += 1; continue }
  const bak = `${abs}.bak-${stamp}`
  fs.writeFileSync(bak, original, 'utf8')
  fs.writeFileSync(abs, text, 'utf8')
  try {
    execFileSync(process.execPath, ['--check', abs], { stdio: 'pipe' })
    console.log(`${rel}: ${log.join('、')}  ✓语法过`)
    changed += 1
  } catch (e) {
    fs.copyFileSync(bak, abs)
    console.log(`${rel}: ✗ 语法不过，已还原（${String(e?.stderr || e?.message || e).slice(0, 80)}）`)
  }
}
console.log(`\n${DRY ? '会改' : '改了'} ${changed} 个文件`)
