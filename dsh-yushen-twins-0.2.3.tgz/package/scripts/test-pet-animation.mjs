// 鱼神双子星 · Copyright (c) 2026 从零开始. All rights reserved.
// pet-animation 自测：正常 / 缺帧 / 路径穿越 / 越界符号链接 / 真实插件只读抽检。
// 全部在临时目录里造 fixture，跑完全部清掉；不碰真实插件以外的任何用户目录。
//
// 运行：C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe dsh-yushen-twins/scripts/test-pet-animation.mjs

import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { inspectPetAnimation, framePathRejectReason } from '../lib/pet-animation.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const REAL_PLUGIN = 'C:\\Users\\Administrator\\.dsh\\profiles\\desktop\\node_modules\\dsh-dafeiyu'

const tempRoots = []
let passed = 0
let failed = 0
let skipped = 0
const failures = []

function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true })
}

function writeText(file, text) {
  ensureDir(path.dirname(file))
  fs.writeFileSync(file, text, 'utf8')
}

function writeJson(file, data) {
  writeText(file, `${JSON.stringify(data, null, 2)}\n`)
}

function makeFixture(label) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `yushen-pet-test-${label}-`))
  tempRoots.push(root)
  const plugin = path.join(root, 'plugin')
  ensureDir(path.join(plugin, 'assets', 'pet'))
  return { root, plugin, petDir: path.join(plugin, 'assets', 'pet') }
}

function writeFrame(petDir, rel, content) {
  const file = path.join(petDir, ...rel.split('/'))
  ensureDir(path.dirname(file))
  fs.writeFileSync(file, content)
  return file
}

function clip(frames, { frameMs = 42, loop = false, source = {} } = {}) {
  return {
    frames,
    frameMs,
    loop,
    source: {
      file: 'fixture.webm',
      sha256: 'b'.repeat(64),
      startFrame: 0,
      endFrame: frames.length,
      frameCount: frames.length,
      ...source,
    },
  }
}

function buildManifest(clips, extra = {}) {
  return {
    formatVersion: 1,
    characterId: 'fixture-pet',
    baseSize: 412,
    maxFrameWidth: 412,
    maxFrameHeight: 344,
    assetSource: {
      repository: 'https://example.invalid/fixture-repo',
      commit: 'a'.repeat(40),
      directory: 'assets/webm',
      fps: 24,
      crop: [0, 0, 412, 344],
      webpQuality: 68,
    },
    clips,
    ...extra,
  }
}

function writeLicenseFiles(plugin) {
  writeText(path.join(plugin, 'LICENSE'), 'MIT License\n\nCopyright (c) 2026 fixture\n')
  writeText(
    path.join(plugin, 'ASSET_LICENSE.md'),
    '# Visual asset notice\n\nThe visual character assets under `assets/pet/` are MIT-licensed.\n',
  )
  writeText(path.join(plugin, 'assets', 'dsh-pet-LICENSE.txt'), 'MIT License\n\nPermission is hereby granted...\n')
}

async function test(name, fn) {
  try {
    const outcome = await fn()
    if (outcome === SKIP) return
    passed += 1
    console.log(`PASS ${name}`)
  } catch (error) {
    failed += 1
    failures.push({ name, message: error && error.message ? error.message : String(error) })
    console.log(`FAIL ${name}: ${error && error.message ? error.message : error}`)
  }
}

const SKIP = Symbol('skip')

function skip(name, reason) {
  skipped += 1
  console.log(`SKIP ${name}: ${reason}`)
  return SKIP
}

function assertInside(root, target, label) {
  const rel = path.relative(root, target)
  assert.ok(
    rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel)),
    `${label} 越界：${target} 不在 ${root} 之内`,
  )
}

// ---------- 1. 正常 fixture ----------
await test('normal: manifest/画布/每段帧路径与时长/许可证据', () => {
  const { plugin, petDir } = makeFixture('normal')
  // 陷阱：package.json 指了一个“一加载就写标记”的入口，证明体检没有执行插件代码。
  const marker = path.join(path.dirname(plugin), 'executed.marker')
  writeJson(path.join(plugin, 'package.json'), {
    name: 'dsh-fixture-pet',
    version: '9.9.9',
    license: 'MIT',
    main: 'boom.cjs',
  })
  writeText(
    path.join(plugin, 'boom.cjs'),
    `require('node:fs').writeFileSync(${JSON.stringify(marker)}, 'ran');\n`,
  )
  writeLicenseFiles(plugin)

  const idleBytes = Buffer.from('RIFF....WEBP-idle-000')
  const pokeBytes = Buffer.from('RIFF....WEBP-poke-000')
  writeFrame(petDir, 'idle/idle_001.webp', idleBytes)
  writeFrame(petDir, 'idle/idle_002.webp', Buffer.from('RIFF....WEBP-idle-001'))
  writeFrame(petDir, 'idle/idle_003.webp', Buffer.from('RIFF....WEBP-idle-002'))
  writeFrame(petDir, 'poke/poke_001.webp', pokeBytes)
  writeFrame(petDir, 'poke/poke_002.webp', Buffer.from('RIFF....WEBP-poke-001'))

  const manifest = buildManifest({
    idle: clip(['idle/idle_001.webp', 'idle/idle_002.webp', 'idle/idle_003.webp'], { frameMs: 42, loop: true }),
    poke: clip(['poke/poke_001.webp', 'poke/poke_002.webp'], { frameMs: 100, loop: false }),
  })
  const manifestPath = path.join(plugin, 'assets', 'pet-manifest.json')
  writeJson(manifestPath, manifest)

  const result = inspectPetAnimation(plugin)

  assert.equal(result.ok, true)
  assert.equal(result.valid, true, `应 valid，实际 missing=${JSON.stringify(result.missing)}`)
  assert.equal(result.plugin.name, 'dsh-fixture-pet')
  assert.equal(result.plugin.version, '9.9.9')
  assert.equal(result.plugin.evidence[0].sha256, sha256File(path.join(plugin, 'package.json')))
  assert.equal(result.manifest.sha256, sha256File(manifestPath))
  assert.equal(result.manifest.parsed, true)
  assert.equal(result.canvas.width, 412)
  assert.equal(result.canvas.height, 344)
  assert.equal(result.canvas.baseSize, 412)
  assert.equal(result.checked.clips, 2)
  assert.equal(result.checked.frames, 5)
  assert.equal(result.checked.missingFrames, 0)
  assert.equal(result.checked.rejectedFrames, 0)
  assert.deepEqual(result.missing, [])
  assert.deepEqual(result.violations, [])

  const idle = result.clips.find((c) => c.name === 'idle')
  assert.equal(idle.frameCount, 3)
  assert.equal(idle.durationMs, 126)
  assert.equal(idle.loop, true)
  assert.equal(idle.frames.length, 3)
  assert.equal(idle.frames[0].rel, 'idle/idle_001.webp')
  assert.equal(idle.frames[0].exists, true)
  assert.equal(idle.frames[0].bytes, idleBytes.length)
  assert.ok(path.isAbsolute(idle.frames[0].path))
  assertInside(path.join(plugin, 'assets', 'pet'), idle.frames[0].path, 'idle 帧')

  const poke = result.clips.find((c) => c.name === 'poke')
  assert.equal(poke.durationMs, 200)
  assert.equal(poke.loop, false)
  assert.equal(poke.frameMs, 100)

  assert.equal(result.license.mitMentioned, true)
  assert.equal(result.license.status, 'declared')
  const licenseRels = result.license.evidence.map((e) => e.rel)
  assert.ok(licenseRels.includes('ASSET_LICENSE.md'))
  assert.ok(licenseRels.includes('assets/dsh-pet-LICENSE.txt'))
  assert.ok(result.license.evidence.every((e) => /^[a-f0-9]{64}$/.test(e.sha256)))

  assert.equal(fs.existsSync(marker), false, '体检期间不应执行插件代码（标记文件不该出现）')
  assert.equal(result.safety.executedPluginCode, false)
  assert.equal(result.safety.copiedAssets, false)
  assert.equal(result.safety.autoBound, false)
  assert.equal(result.safety.readPersona, false)
})

// ---------- 2. 缺帧 ----------
await test('missing-frame: 缺帧判 invalid 并给出具体文件名', () => {
  const { plugin, petDir } = makeFixture('missing')
  writeJson(path.join(plugin, 'package.json'), { name: 'dsh-fixture-pet', version: '9.9.9', license: 'MIT' })
  writeLicenseFiles(plugin)
  writeFrame(petDir, 'idle/idle_001.webp', Buffer.from('a'))
  writeFrame(petDir, 'idle/idle_002.webp', Buffer.from('b'))
  const manifestPath = path.join(plugin, 'assets', 'pet-manifest.json')
  writeJson(manifestPath, buildManifest({
    idle: clip(['idle/idle_001.webp', 'idle/idle_002.webp', 'idle/idle_003.webp']),
  }))

  const result = inspectPetAnimation(plugin)
  assert.equal(result.ok, true)
  assert.equal(result.valid, false)
  assert.equal(result.checked.missingFrames, 1)
  assert.equal(result.checked.existingFrames, 2)
  assert.equal(result.checked.rejectedFrames, 0)
  assert.ok(
    result.missing.some((line) => line.includes('idle_003.webp')),
    `missing 应点名 idle_003.webp，实际 ${JSON.stringify(result.missing)}`,
  )
  const idle = result.clips[0]
  assert.deepEqual(idle.missing, ['idle/idle_003.webp'])
  assert.equal(idle.frames[2].exists, false)
})

// ---------- 3. 路径穿越 / 绝对路径 ----------
await test('traversal: 绝对路径、..、空段一律拒绝且不读根外文件', () => {
  const { root, plugin, petDir } = makeFixture('traversal')
  writeJson(path.join(plugin, 'package.json'), { name: 'dsh-fixture-pet', version: '9.9.9' })
  writeLicenseFiles(plugin)
  writeFrame(petDir, 'idle/ok.webp', Buffer.from('ok'))
  // 根外的“机密”文件：任何被错误接受的路径都可能把它带出来。
  const secret = path.join(root, 'secret-outside.webp')
  fs.writeFileSync(secret, 'SECRET')

  const frames = [
    'idle/ok.webp',
    '../secret-outside.webp',
    'C:/Windows/win.ini',
    '/etc/passwd',
    'idle/../../escape.webp',
    'idle//double.webp',
    'idle\\..\\x.webp',
  ]
  writeJson(path.join(plugin, 'assets', 'pet-manifest.json'), buildManifest({
    idle: clip(frames),
  }))

  const result = inspectPetAnimation(plugin)
  assert.equal(result.ok, true)
  assert.equal(result.valid, false)
  assert.equal(result.checked.frames, 1, '只应接受 idle/ok.webp')
  assert.equal(result.checked.rejectedFrames, 6)
  assert.equal(result.checked.missingFrames, 0)

  const reasons = result.violations.map((v) => v.reason)
  for (const expected of ['parent-traversal', 'absolute-drive-path', 'absolute-path', 'empty-segment']) {
    assert.ok(reasons.includes(expected), `应记录 ${expected}，实际 ${JSON.stringify(reasons)}`)
  }
  const accepted = result.clips[0].frames
  assert.equal(accepted.length, 1)
  assertInside(path.join(plugin, 'assets', 'pet'), accepted[0].path, 'accepted 帧')
  const acceptedSerialized = JSON.stringify(accepted)
  assert.equal(acceptedSerialized.includes('secret-outside'), false, '根外文件名不该出现在已接受帧里')
  assert.equal(acceptedSerialized.includes('win.ini'), false)
  assert.equal(acceptedSerialized.includes('/etc/passwd'), false)
  const rejectedRels = result.clips[0].rejected.map((r) => r.rel)
  assert.ok(rejectedRels.some((rel) => rel.includes('secret-outside')))
  assert.equal(framePathRejectReason('idle/ok.webp'), null)
  assert.equal(framePathRejectReason('C:\\Windows\\x.webp'), 'absolute-drive-path')
})

// ---------- 4. 越界符号链接 ----------
await test('symlink: 越界符号链接拒绝，指向根内的符号链接放行', () => {
  const { root, plugin, petDir } = makeFixture('symlink')
  writeJson(path.join(plugin, 'package.json'), { name: 'dsh-fixture-pet', version: '9.9.9' })
  writeLicenseFiles(plugin)
  writeFrame(petDir, 'idle/in_001.webp', Buffer.from('inside'))
  const outsideTarget = path.join(root, 'outside-target.webp')
  fs.writeFileSync(outsideTarget, 'OUTSIDE')

  const linkInside = path.join(petDir, 'idle', 'link_inside.webp')
  const linkOutside = path.join(petDir, 'idle', 'link_outside.webp')
  try {
    fs.symlinkSync(path.join(petDir, 'idle', 'in_001.webp'), linkInside, 'file')
    fs.symlinkSync(outsideTarget, linkOutside, 'file')
  } catch (error) {
    const code = error && error.code ? error.code : 'UNKNOWN'
    if (['EPERM', 'EACCES', 'ENOTSUP', 'UNKNOWN', 'ENOSYS'].includes(code)) {
      return skip('symlink-escape', `当前账户没有创建符号链接的权限（${code}）：无法构造越界 symlink 用例`)
    }
    throw error
  }

  writeJson(path.join(plugin, 'assets', 'pet-manifest.json'), buildManifest({
    idle: clip(['idle/in_001.webp', 'idle/link_inside.webp', 'idle/link_outside.webp']),
  }))

  const result = inspectPetAnimation(plugin)
  assert.equal(result.valid, false)
  const escape = result.violations.find((v) => v.reason === 'symlink-escape')
  assert.ok(escape, `应记录 symlink-escape，实际 ${JSON.stringify(result.violations)}`)
  assert.equal(escape.rel, 'idle/link_outside.webp')

  const inside = result.clips[0].frames.find((f) => f.rel === 'idle/link_inside.webp')
  assert.ok(inside, '根内符号链接应被接受')
  assert.equal(inside.exists, true)
  assert.equal(inside.symlink, true)
  assertInside(fs.realpathSync(path.join(plugin, 'assets', 'pet')), inside.path, '根内链接')

  const serialized = JSON.stringify({ frames: result.clips[0].frames })
  assert.equal(serialized.includes('link_outside.webp'), false, '越界链接不该进入已接受帧')
  assert.ok(result.clips[0].rejected.some((r) => r.rel === 'idle/link_outside.webp'))
})

// ---------- 4b. 越界 junction（Windows 不需要管理员权限，必跑） ----------
await test('junction: 越界目录 junction 拒绝（不依赖管理员权限）', () => {
  const { root, plugin, petDir } = makeFixture('junction')
  writeJson(path.join(plugin, 'package.json'), { name: 'dsh-fixture-pet', version: '9.9.9' })
  writeLicenseFiles(plugin)
  writeFrame(petDir, 'idle/in_001.webp', Buffer.from('inside'))

  const outsideDir = path.join(root, 'outside-dir')
  ensureDir(outsideDir)
  fs.writeFileSync(path.join(outsideDir, 'evil.webp'), 'OUTSIDE')

  const junction = path.join(petDir, 'linkdir')
  try {
    fs.symlinkSync(outsideDir, junction, 'junction')
  } catch (error) {
    const code = error && error.code ? error.code : 'UNKNOWN'
    if (['EPERM', 'EACCES', 'ENOTSUP', 'UNKNOWN', 'ENOSYS'].includes(code)) {
      return skip('junction-escape', `无法创建 junction（${code}）`)
    }
    throw error
  }

  writeJson(path.join(plugin, 'assets', 'pet-manifest.json'), buildManifest({
    idle: clip(['idle/in_001.webp', 'linkdir/evil.webp']),
  }))

  const result = inspectPetAnimation(plugin)
  assert.equal(result.valid, false)
  const escape = result.violations.find((v) => v.reason === 'symlink-escape')
  assert.ok(escape, `应记录 symlink-escape，实际 ${JSON.stringify(result.violations)}`)
  assert.equal(escape.rel, 'linkdir/evil.webp')
  assert.equal(result.checked.rejectedFrames, 1)
  assert.equal(result.clips[0].rejected[0].rel, 'linkdir/evil.webp')
  // 体检不能删/改根外目标：junction 指向的目录和文件还在（只读证据）。
  assert.equal(fs.existsSync(path.join(outsideDir, 'evil.webp')), true)
  assert.equal(fs.readFileSync(path.join(outsideDir, 'evil.webp'), 'utf8'), 'OUTSIDE')
  const accepted = result.clips[0].frames
  assert.equal(accepted.length, 1)
  assertInside(path.join(plugin, 'assets', 'pet'), accepted[0].path, 'junction 用例 accepted 帧')
})

// ---------- 5. 参数守护 ----------
await test('guard: 非目录 / 含 .. 的 pluginDir 直接拒绝', () => {
  const bad1 = inspectPetAnimation(undefined)
  assert.equal(bad1.ok, false)
  assert.equal(bad1.valid, false)
  assert.ok(bad1.missing.length > 0)

  const bad2 = inspectPetAnimation('..\\..\\windows')
  assert.equal(bad2.ok, false)
  assert.ok(bad2.missing.some((m) => m.includes('..')))

  const bad3 = inspectPetAnimation(path.join(os.tmpdir(), 'definitely-not-here-yushen-pet'))
  assert.equal(bad3.ok, false)
})

// ---------- 6. 真实插件只读抽检（有就验，没有就跳过） ----------
await test('real: dsh-dafeiyu 只读抽检（不写它）', () => {
  if (!fs.existsSync(REAL_PLUGIN)) {
    return skip('real-plugin', `未安装：${REAL_PLUGIN}`)
  }
  const pkgBefore = sha256File(path.join(REAL_PLUGIN, 'package.json'))
  const manifestPath = path.join(REAL_PLUGIN, 'assets', 'pet-manifest.json')
  const manifestBefore = sha256File(manifestPath)

  const result = inspectPetAnimation(REAL_PLUGIN)
  assert.equal(result.ok, true)
  assert.equal(result.valid, true, `真实插件应 valid，missing=${JSON.stringify(result.missing.slice(0, 5))}`)
  assert.equal(result.plugin.name, 'dsh-dafeiyu')
  assert.match(result.plugin.version, /^\d+\.\d+\.\d+/)
  assert.equal(result.manifest.sha256, manifestBefore)
  assert.ok(result.checked.clips >= 10)
  assert.ok(result.checked.frames > 1000)
  assert.equal(result.checked.missingFrames, 0)
  assert.equal(result.checked.rejectedFrames, 0)
  assert.deepEqual(result.violations, [])
  assert.equal(result.canvas.width > 0 && result.canvas.height > 0, true)
  assert.equal(result.license.mitMentioned, true)
  for (const c of result.clips) {
    assert.ok(c.frames.length > 0, `clip ${c.name} 应有帧`)
    assert.ok(typeof c.durationMs === 'number' && c.durationMs > 0)
    assert.equal(typeof c.loop, 'boolean')
    for (const f of c.frames) assertInside(path.join(REAL_PLUGIN, 'assets', 'pet'), f.path, `real ${c.name}`)
  }

  // 只读校验：两次抓取指纹一致，说明没被改写。
  assert.equal(sha256File(path.join(REAL_PLUGIN, 'package.json')), pkgBefore)
  assert.equal(sha256File(manifestPath), manifestBefore)
})

// ---------- 收尾：安全清理 ----------
function cleanup() {
  for (const root of tempRoots) {
    try {
      fs.rmSync(root, { recursive: true, force: true, maxRetries: 3 })
    } catch (error) {
      console.log(`WARN 清理失败：${root}（${error && error.code ? error.code : error}）`)
    }
  }
  for (const root of tempRoots) {
    assert.equal(fs.existsSync(root), false, `临时目录未清干净：${root}`)
  }
}

let cleanupError = null
try {
  cleanup()
} catch (error) {
  cleanupError = error
}

if (cleanupError) {
  failed += 1
  failures.push({ name: 'cleanup', message: cleanupError.message })
  console.log(`FAIL cleanup: ${cleanupError.message}`)
} else {
  passed += 1
  console.log(`PASS cleanup: 临时目录已删除（${tempRoots.length} 个）`)
}

console.log(`\n${passed} passed, ${failed} failed, ${skipped} skipped`)
if (failures.length > 0) {
  for (const f of failures) console.log(`  · ${f.name}: ${f.message}`)
  process.exitCode = 1
}
