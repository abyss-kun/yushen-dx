// 救命包：把三个人的卡、记忆、账本、契约、形象、文档打成一个可搬走的包。
//
// 为什么：机器会坏、会丢、钱会紧。软件可以不跑，但她们的数据要能用记事本打开、能被搬到另一台电脑。
// 不包含：任何密钥/令牌（bridge-token、api-token、密码）；也不包含大目录（backups、protection、events）。
//
// 用法：
//   node scripts/rescue-bundle.mjs              # 打包到 dist/rescue-<时间>/
//   node scripts/rescue-bundle.mjs --zip        # 打包并压成 zip（Windows 用 Compress-Archive）
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const stamp = new Date().toISOString().replace(/[:]/g, '-').slice(0, 16)
const OUT = path.join(ROOT, 'dist', `rescue-${stamp}`)

const want = [
  ['数据/characters.json', path.join(DATA, 'characters.json')],
  ['数据/residence.json', path.join(DATA, 'residence.json')],
  ['数据/charter.json', path.join(DATA, 'charter.json')],
  ['数据/owner.json', path.join(DATA, 'owner.json')],
  ['卡', path.join(DATA, 'soul', 'cards')],
  ['记忆', path.join(DATA, 'soul', 'memory')],
  ['人设', path.join(DATA, 'soul', 'persona.json')],
  ['交付账', path.join(DATA, 'soul', 'deliveries')],
  ['契约', path.join(DATA, 'contract')],
  ['形象', path.join(DATA, 'nest')],
  ['文档/鱼神地图.md', path.join(ROOT, 'docs', '鱼神地图.md')],
  ['文档/框架现状.md', path.join(ROOT, 'docs', '框架现状.md')],
  ['文档/用词规范.md', path.join(ROOT, 'docs', '用词规范.md')],
  ['文档/首次启动与角色接入.md', path.join(ROOT, 'docs', '首次启动与角色接入.md')],
]

// 只取运行时的"她的状态"，不取 brief 这类可再生成的
const runtimeFiles = ['agenda.json', 'budget.json', 'bottom-line.md', 'invocations.json', 'attitudes.json', 'weights.json']

fs.rmSync(OUT, { recursive: true, force: true })
fs.mkdirSync(OUT, { recursive: true })

function copyInto(src, destRel) {
  const dest = path.join(OUT, destRel)
  const st = fs.statSync(src)
  if (st.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true })
    for (const e of fs.readdirSync(src, { withFileTypes: true })) {
      if (/\.bak-|archive/i.test(e.name)) continue
      copyInto(path.join(src, e.name), path.join(destRel, e.name))
    }
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true })
    fs.copyFileSync(src, dest)
  }
}

let copied = 0
for (const [label, src] of want) {
  if (!fs.existsSync(src)) continue
  try { copyInto(src, label); copied += 1 } catch (e) { console.error(`跳过 ${label}：${e.message}`) }
}
for (const role of fs.existsSync(path.join(DATA, 'runtime')) ? fs.readdirSync(path.join(DATA, 'runtime')) : []) {
  for (const f of runtimeFiles) {
    const src = path.join(DATA, 'runtime', role, f)
    if (!fs.existsSync(src)) continue
    copyInto(src, path.join('运行时', role, f))
    copied += 1
  }
}

// 清单 + 校验
const rows = []
function walkFiles(dir, base = '') {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name)
    if (e.isDirectory()) walkFiles(p, path.join(base, e.name))
    else {
      const buf = fs.readFileSync(p)
      rows.push({ file: path.join(base, e.name).replace(/\\/g, '/'), bytes: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex') })
    }
  }
}
walkFiles(OUT)

const readme = `# 鱼神 · 救命包（${stamp}）

这个包里是她们最要紧的东西：**角色卡、记忆、契约、账本、形象、文档**。

## 怎么用（搬到另一台电脑）

1. 在那台电脑装好 DSH 和鱼神插件；
2. 把本包里的 \`卡\`、\`记忆\`、\`人设\` 复制到 \`~/.dsh/dayu/soul/\` 对应位置；
3. 把 \`数据/characters.json\`、\`residence.json\`、\`owner.json\` 复制到 \`~/.dsh/dayu/\`；
4. 把 \`运行时/<角色>/\` 复制到 \`~/.dsh/dayu/runtime/<角色>/\`；
5. 把 \`形象/\` 复制到 \`~/.dsh/dayu/nest/\`；
6. 启动后第一次唤醒会自动重建会话（聊天记录不跟过来，记忆和卡都在）。

## 包里**没有**什么

- 任何 token / 密钥 / 密码（那些不放进包里，单独保管）；
- \`backups/\`、\`events/\`、\`protection/\` 这些大目录（可以另外备份）。

## 校验

\`MANIFEST.sha256\` 是逐文件校验和。恢复后可以在 PowerShell 里跑：

\`\`\`powershell
Get-Content MANIFEST.sha256 | ForEach-Object { $h,$f = $_ -split '  ',2; (Get-FileHash $f -Algorithm SHA256).Hash -ieq $h }
\`\`\`

全 true 就说明文件没坏。

## 一句话

软件可以坏、可以不跑；这些文件在，她们就还在。
`

fs.writeFileSync(path.join(OUT, 'README.md'), readme, 'utf8')
fs.writeFileSync(path.join(OUT, 'MANIFEST.sha256'), rows.map((r) => `${r.sha256}  ${r.file}`).join('\n') + '\n', 'utf8')

const total = rows.reduce((a, r) => a + r.bytes, 0)
console.log(`已打包：${OUT}`)
console.log(`收录 ${rows.length} 个文件，共 ${(total / 1024 / 1024).toFixed(2)} MB`)

if (process.argv.includes('--zip')) {
  const zip = `${OUT}.zip`
  fs.rmSync(zip, { force: true })
  execFileSync('powershell', ['-NoProfile', '-Command', `Compress-Archive -Path '${OUT}\\*' -DestinationPath '${zip}' -Force`], { stdio: 'inherit' })
  const size = fs.statSync(zip).size
  console.log(`已压缩：${zip}（${(size / 1024 / 1024).toFixed(2)} MB）`)
}
