// 第三批：最后 3 个真没人接的（名字太通用，前两轮人工确认过）。
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
const TARGETS = [
  ['lib/decay.js', 'rank'],
  ['lib/takeover.js', 'snapshot'],
  ['lib/whiteboard.js', 'post'],
]

function spanOf(lines, name) {
  const re = new RegExp(`^export (async )?function ${name}\\s*\\(`)
  const start = lines.findIndex((l) => re.test(l))
  if (start < 0) return null
  let s = start
  while (s > 0 && /^\s*\*/.test(lines[s - 1])) s -= 1
  if (s > 0 && /^\/\*\*/.test(lines[s - 1])) s -= 1
  for (let i = start + 1; i < lines.length; i += 1) {
    if (lines[i].replace(/\r$/, '') === '}') return { start: s, end: i }
  }
  return null
}

for (const [rel, name] of TARGETS) {
  const abs = path.join(ROOT, rel)
  const original = fs.readFileSync(abs, 'utf8')
  const lines = original.split('\n')
  const sp = spanOf(lines, name)
  if (!sp) { console.log(`${rel} ${name}: 没找到`); continue }
  const next = [...lines.slice(0, sp.start), ...lines.slice(sp.end + 1)].join('\n')
  const bak = `${abs}.bak-${stamp}`
  fs.writeFileSync(bak, original, 'utf8')
  fs.writeFileSync(abs, next, 'utf8')
  try {
    execFileSync(process.execPath, ['--check', abs], { stdio: 'pipe' })
    console.log(`${rel} ${name}: -${sp.end - sp.start + 1} 行 ✓`)
  } catch {
    fs.copyFileSync(bak, abs)
    console.log(`${rel} ${name}: ✗ 已还原`)
  }
}
