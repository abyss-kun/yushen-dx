﻿# 重启桥：杀干净旧进程，只留一个隐藏窗口。
# 用法：powershell -ExecutionPolicy Bypass -File scripts\restart-bridge.ps1
# 为什么：以前每次 `cmd /c start start.bat` 都开一个新窗口，旧窗口不死，攒了一屏 cmd。

$ErrorActionPreference = 'SilentlyContinue'
$Port = 3100

# 1) 杀旧 bridge node
$nodes = Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*bridge.js*' }
foreach ($p in $nodes) { Stop-Process -Id $p.ProcessId -Force }

# 2) 杀残留 cmd（qq-bridge 的 start.bat）
$cmds = Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" | Where-Object { $_.CommandLine -like '*qq-bridge*' -or $_.CommandLine -like '*start.bat*' }
foreach ($c in $cmds) { Stop-Process -Id $c.ProcessId -Force }

Start-Sleep -Seconds 2

# 3) 起一个隐藏的（不新开窗口）
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c','D:\deepseekTools\qq-bridge\start.bat' -WindowStyle Hidden

# 4) 等端口，报结果
$ok = $false
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  $l = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
  if ($l) { $ok = $true; break }
}
if ($ok) {
  $alive = (Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -like '*bridge.js*' } | Measure-Object).Count
  $wins = (Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" | Where-Object { $_.CommandLine -like '*qq-bridge*' } | Measure-Object).Count
  "OK：3100 由 pid $($l.OwningProcess) 监听；bridge 进程 $alive 个；cmd 窗口 $wins 个"
} else {
  "FAIL：30 秒内 3100 没起来，看 state\bridge.log"
  exit 1
}
