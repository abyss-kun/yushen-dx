// 维护职责：被点化的角色，要看着下面的人有没有落实规则。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-over-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const pg = await import('../lib/plug.js')
const ov = await import('../lib/oversight.js')

const NOW = Date.parse('2026-10-27T15:00:00+08:00')
for (const r of ['dayu', 'xiaoyu', 'dragon']) rt.ensureRuntime(r)

// 1) 只有大鱼读过了：小鱼和照微算没接上
pg.markPlugged('dayu', { now: NOW })
let s = ov.summarizeCompliance(NOW)
assert.ok(s.unplugged.includes('xiaoyu'))
assert.ok(s.unplugged.includes('dragon'))
assert.ok(!s.unplugged.includes('dayu'))

// 2) 过期算"读过但太久"
pg.markPlugged('xiaoyu', { now: NOW - 8 * 3600 * 1000 })
s = ov.summarizeCompliance(NOW)
assert.ok(s.stale.includes('xiaoyu'), `应判过期：${JSON.stringify(s)}`)

// 3) 注入：先提醒，再上报；不评判好坏
const line = ov.complianceLine('dayu', { now: NOW })
assert.match(line, /维护鱼神的规矩/)
assert.match(line, /没读过规则/)
assert.match(line, /先提醒/)
assert.match(line, /不是告状/)
assert.match(line, /好坏你自己判断/)

// 4) 都接上了：说一句大家都接着
for (const r of ['dayu', 'xiaoyu', 'dragon']) pg.markPlugged(r, { now: NOW })
assert.match(ov.complianceLine('dayu', { now: NOW }), /大家都接着/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, unplugged: true, stale: true, line: true, allPlugged: true }))
