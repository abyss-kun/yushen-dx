// 中枢简报：一份，任何通道共用；只写事实和她自己写的话。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-brief-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const ag = await import('../lib/agenda.js')
const bl = await import('../lib/bottomline.js')
const br = await import('../lib/brief.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T18:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 什么都没有时：也有一份，但只有"实话"（没写的就不出现）
let b = br.buildRuntimeBrief(ROLE, { channel: 'desk', now: NOW })
assert.match(b.text, /你身上接上了什么/)
assert.match(b.text, /在用的|还没有/)
assert.doesNotMatch(b.text, /你自己写的/, '没写过自我档就不该有这段')
assert.doesNotMatch(b.text, /你的底线/, '没写过底线就不该有这段')
assert.match(b.text, /砝码，不是规矩/)

// 2) 她排了事、写了自我、写了底线：简报里都带出来
const item = ag.addItem(ROLE, { what: '弄清那个 BV', nextKind: 'check', now: NOW })
bl.writeBottomline(ROLE, '- 我不替老板做决定', { now: NOW })
fs.writeFileSync(path.join(rt.runtimeDir(ROLE), 'self.md'), '# 我\n\n## 我是谁\n大肥鱼，懒得解释，但会记住人。别人起哄我就一句顶回去，真有事我会做。\n', 'utf8')
b = br.buildRuntimeBrief(ROLE, { channel: 'bili', now: NOW })
assert.match(b.text, /你手上自己的事/)
assert.match(b.text, /弄清那个 BV/)
assert.match(b.text, /你自己写的/)
assert.match(b.text, /懒得解释/)
assert.match(b.text, /你的底线/)
assert.match(b.text, /不替老板做决定/)

// 3) 2026-10-29 起 QQ 走轻简报（只带自己/记忆/手机规则），工作台走完整简报
const qq = br.buildRuntimeBrief(ROLE, { channel: 'qq', now: NOW })
const desk = br.buildRuntimeBrief(ROLE, { channel: 'desk', now: NOW })
assert.match(qq.text, /你在 QQ 上/)
assert.ok(qq.text.length < desk.text.length, 'QQ 简报应该比工作台短')
assert.notEqual(qq.channel, desk.channel, '通道只是标签')

// 4) 写盘 / 读盘：插件侧只读这个文件
const wrote = br.writeRuntimeBrief(ROLE, { channel: 'desk', now: NOW })
assert.ok(fs.existsSync(wrote.file))
const disk = br.readRuntimeBrief(ROLE)
assert.ok(disk.includes('你身上接上了什么'))
assert.doesNotMatch(disk, /<!--/, '读出来不带 HTML 注释头')

// 5) 字数上限：超了要截断，不无限长（拿自我档塞长文）
fs.writeFileSync(path.join(rt.runtimeDir(ROLE), 'self.md'), `# 我\n\n${'一'.repeat(3000)}\n`, 'utf8')
const capped = br.buildRuntimeBrief(ROLE, { now: NOW, maxChars: 800 })
// 规则：必须节永不截断（安全内容先砍是错），所以字多的时候总长可以略超上限。
// 这条以前钉的是「<= 900」，但必须节自己长到 850 字了，钉死字数等于逼人去砍安全内容。
// 2026-10-30：必须节又长了（契约/边界/拒绝/手册指针），上限放宽到 800+800。
// 精神不变：必须节不许砍，正文必须"有交代地"截断。
assert.ok(capped.text.length <= 800 + 800, `截断没生效：${capped.text.length}`)
assert.match(capped.text, /你现在的位置/, '必须节不许被截掉')
assert.match(capped.text, /权限只认本人/, '必须节不许被截掉')
assert.ok(capped.text.includes('…'), '被丢掉的正文要有交代，不许静默截断')

// 6) 读不到简报时返回空，不编
assert.equal(br.readRuntimeBrief('nobody'), '')

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, honest: true, includesHers: true, sameAcrossChannels: true, fileRoundtrip: true, capped: true }))
