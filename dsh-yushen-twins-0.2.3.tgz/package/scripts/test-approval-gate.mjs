import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const home = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-approval-'))
process.env.DSH_HOME = home
const { setCap, has } = await import('../lib/authz.js')
const { requestApproval, decideApproval, consumeApproval, listApprovals } = await import('../lib/perm.js')

setCap('exec.run', false, 'test')
assert.equal(has('exec.run'), false)
const command = 'capability exec.run'
const first = requestApproval({ command, reason: '测试缺权申请', who: '大鱼' })
assert.equal(first.status, 'pending')
assert.equal(listApprovals().length, 1)
assert.equal(consumeApproval(first.id, command).ok, false)
decideApproval(first.id, true)
assert.equal(consumeApproval(first.id, command).ok, true)
assert.equal(consumeApproval(first.id, command).ok, false)
assert.equal(fs.existsSync(path.join(home, 'dayu', 'approvals.json')), true)
fs.rmSync(home, { recursive: true, force: true })
console.log('授权闸门：缺权申请、批准一次性消费、重复使用拒绝，全部通过')
