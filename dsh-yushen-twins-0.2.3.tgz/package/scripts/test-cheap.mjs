// 便宜那条路：本地不在就交云端，不假装；决定要留痕；她可以选不回。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-cheap-'))
process.env.DSH_HOME = HOME
process.env.YUSHEN_LOCAL_PORT = '9' // 死端口：模拟本地没起来

const rt = await import('../lib/runtime.js')
const cr = await import('../lib/cheap-reply.js')

const ROLE = 'dayu'
rt.ensureRuntime(ROLE)

const msg = { id: 'g#9', at: new Date().toISOString(), name: '甲', text: '在吗', atMe: false }
const row = await cr.decideCheap(ROLE, msg, { now: Date.now() })

assert.equal(row.mode, 'cloud', '本地不在就交云端')
assert.match(row.why, /本地没接上/)
assert.equal(row.local, false, '不许假装本地判过')

const file = path.join(HOME, 'dayu', 'runtime', ROLE, 'cheap', new Date().toISOString().slice(0, 10) + '.jsonl')
assert.ok(fs.existsSync(file), '决定要留痕')
const logged = fs.readFileSync(file, 'utf8').trim().split(/\r?\n/).map((l) => JSON.parse(l))
assert.equal(logged.length, 1)
assert.equal(logged[0].mode, 'cloud')

const tally = cr.cheapTally(ROLE)
assert.equal(tally.cloud, 1)
assert.equal(tally.total, 1)

// 模式只有三种：不回 / 本地 / 云端——"不回"是她合法的选择
assert.deepEqual([...cr.MODES], ['silent', 'local', 'cloud'])

// 4) 不设字数上限：她想说多长就多长（2026-10-26 三问打回后删掉了「8 字闸」）
const long = cr.localReplyAsIs({ mode: 'local', reply: '这句话明显超过八个字，但那是她想说的', why: '想说' })
assert.equal(long.mode, 'local', '本地也能说长句')
assert.match(long.reply, /超过八个字/)
assert.equal(cr.localReplyAsIs({ mode: 'cloud', reply: '随便' }).mode, 'cloud')
assert.equal(cr.localReplyAsIs({ mode: 'silent', reply: '' }).mode, 'silent')

// 5) 口吻样例：只取她真实说过的短句，去重，长的和 [图片] 不要
const inboxFile = path.join(HOME, 'dayu', 'inbox', 'qq', new Date().toISOString().slice(0, 10) + '.jsonl')
fs.mkdirSync(path.dirname(inboxFile), { recursive: true })
const lines = [
  { id: 'a', at: new Date().toISOString(), isSelf: true, text: '不扯' },
  { id: 'b', at: new Date().toISOString(), isSelf: true, text: '不导' },
  { id: 'c', at: new Date().toISOString(), isSelf: true, text: '不扯' },
  { id: 'd', at: new Date().toISOString(), isSelf: true, text: '这是一句明显超过十二个字的长话不应该被选中' },
  { id: 'e', at: new Date().toISOString(), isSelf: true, text: '[图片]' },
  { id: 'f', at: new Date().toISOString(), isSelf: false, text: '别人的话' },
]
fs.writeFileSync(inboxFile, lines.map((x) => JSON.stringify(x)).join('\n') + '\n', 'utf8')
const samples = cr.voiceSamples(ROLE, { limit: 5 })
assert.deepEqual(samples, ['不扯', '不导'], `样例不对：${JSON.stringify(samples)}`)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, fallsBackToCloud: true, neverFakes: true, logged: true, silentAllowed: true, noLengthCap: true, samples: true }))
