// 顶嘴：可以不同意、可以争，但不许装没看见或偷偷绕。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-obj-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const ob = await import('../lib/objections.js')

const ROLE = 'dayu'
const NOW = Date.parse('2026-10-26T22:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 只耍脾气不讲理由：不受理
assert.throws(() => ob.recordObjection(ROLE, { about: '不许我发图' }), /总得有个说法/)
assert.throws(() => ob.recordObjection(ROLE, { myView: '我就是不喜欢' }), /对哪条规矩/)

// 2) 正常顶嘴：哪条、我的说法、我实际怎么做
const row = ob.recordObjection(ROLE, {
  about: '老板说不许在群里发长文',
  myView: '有些事一句说不清，我可以说短一点，但不能永远只能一句话',
  iDid: '这轮照他的来，下一轮我会再提',
  now: NOW,
})
assert.match(row.myView, /一句说不清/)
assert.equal(ob.listObjections(ROLE).length, 1)

// 3) 注入里带许可：可以顶嘴，但两样不行
const line = ob.objectionLine(ROLE)
assert.match(line, /你可以顶嘴/)
assert.match(line, /装没看见/)
assert.match(line, /偷偷绕/)
assert.match(line, /你上次争过/)

// 4) 没争过的角色：许可照样在
const R2 = 'dragon'
rt.ensureRuntime(R2)
assert.match(ob.objectionLine(R2), /可以顶嘴/)
assert.equal(ob.listObjections(R2).length, 0)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, needsReason: true, logged: true, allowed: true, emptiesOk: true }))
