// 扫本机：已经有哪些角色（只读）。
// 用法：node scripts/detect-roles.mjs
import { detectRoles } from '../lib/detect-roles.js'

const { roles, checked } = detectRoles()
console.log('扫过：', JSON.stringify(checked))
if (!roles.length) {
  console.log('没认到角色。')
  process.exit(0)
}
console.log(`\n认出 ${roles.length} 个候选：\n`)
for (const r of roles) {
  const shape = r.sections === null ? '旧式卡' : r.sections ? '五节齐' : '未填满'
  const flags = [r.kind, r.hasCard ? '有卡' : '无卡', shape].join(' · ')
  console.log(`- ${r.name}  [${flags}]`)
  console.log(`  id: ${r.id}`)
  console.log(`  来源: ${r.source}  sha: ${r.sha || '—'}`)
  console.log(`  路径: ${r.path || '—'}`)
}
