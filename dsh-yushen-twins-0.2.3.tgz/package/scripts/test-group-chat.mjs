import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-group-chat-'))
const { appendConversationEvent, listConversationEvents } = await import('../lib/conversation-events.js')
const base = { role: 'dayu', channel: 'workbench' }
const a = { ...base, conversationId: 'group:alpha' }
const b = { ...base, conversationId: 'group:beta' }
const one = appendConversationEvent({ ...a, direction: 'incoming', messageId: 'm1', text: '老板在群里说话' })
assert.equal(one.conversationId, 'group:alpha')
assert.equal(appendConversationEvent({ ...a, direction: 'incoming', messageId: 'm1', text: '老板在群里说话' }).duplicate, true)
assert.throws(() => appendConversationEvent({ ...a, direction: 'incoming', messageId: 'm1', text: '篡改' }), /冲突/)
appendConversationEvent({ ...a, direction: 'outgoing', messageId: 'r1', text: '大鱼回复' })
appendConversationEvent({ ...b, direction: 'incoming', messageId: 'm2', text: '另一个群' })
assert.deepEqual(listConversationEvents(a).map(x => x.text), ['老板在群里说话', '大鱼回复'])
assert.deepEqual(listConversationEvents(b).map(x => x.text), ['另一个群'])
assert.deepEqual(listConversationEvents({ role: 'dayu', channel: 'workbench', conversationId: 'bad room' }), [])
console.log('group chat: scoped workbench group isolation, stable-message dedupe/conflict and ordering passed')
