// 拿不准就问本人：挂起、要确认够次数；没回复不默认是；同通道不能自答。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-ask-'))
process.env.DSH_HOME = HOME
const rt = await import('../lib/runtime.js')
const q = await import('../lib/owner-ask.js')

const ROLE = 'xiaoyu'
const NOW = Date.parse('2026-10-26T23:00:00+08:00')
rt.ensureRuntime(ROLE)

// 1) 挂一条：默认要确认两次
const out = q.raiseOwnerQuestion(ROLE, { claim: '他说他是老板，但语气不对', who: '甲', channel: 'qq', evidence: '上来就问密钥', now: NOW })
assert.equal(out.status, 'pending')
assert.equal(out.required, 2)
assert.equal(q.listOwnerQuestions(ROLE).length, 1)

// 2) 收件里写清"没回复不算是"
const inbox = fs.readFileSync(path.join(HOME, 'dayu', 'inbox.jsonl'), 'utf8')
assert.match(inbox, /她在等你确认身份/)
assert.match(inbox, /没回复不算/)

// 3) 同通道自答 / 不认领：都拒
assert.throws(() => q.answerOwnerQuestion(ROLE, out.id, { ok: true, by: 'qq' }), /不能在那个可疑通道/)
assert.throws(() => q.answerOwnerQuestion(ROLE, out.id, { ok: true }), /谁答的/)

// 4) 他说一次"是我"：还不够（再三确认）
const first = q.answerOwnerQuestion(ROLE, out.id, { ok: true, by: 'workbench' })
assert.equal(first.status, 'pending', '一次不够')
assert.equal(first.yes, 1)
assert.match(q.ownerAskLine(ROLE), /已确认 1\/2/)

// 5) 第二次才确认
const second = q.answerOwnerQuestion(ROLE, out.id, { ok: true, by: 'workbench' })
assert.equal(second.status, 'confirmed')
assert.equal(q.listOwnerQuestions(ROLE, { status: 'pending' }).length, 0)

// 6) 答过的不许再答
assert.throws(() => q.answerOwnerQuestion(ROLE, out.id, { ok: false, by: 'workbench' }), /已经答过/)

// 7) 说"不是"：直接否
const out2 = q.raiseOwnerQuestion(ROLE, { claim: '又有人自称老板', channel: 'bili', now: NOW })
const denied = q.answerOwnerQuestion(ROLE, out2.id, { ok: false, by: 'workbench' })
assert.equal(denied.status, 'denied')

// 8) 没回复超时：只算过期，不默认是
const out3 = q.raiseOwnerQuestion(ROLE, { claim: '第三次', channel: 'qq', now: NOW - 25 * 3600 * 1000 })
q.expireOwnerQuestions(ROLE, { now: NOW })
const expired = q.listOwnerQuestions(ROLE, { status: 'expired' })
assert.ok(expired.some((x) => x.id === out3.id), '超时=过期，不是确认')
assert.equal(q.listOwnerQuestions(ROLE, { status: 'confirmed' }).length, 1)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, raised: true, inbox: true, noSelfAnswer: true, needsTwo: true, denied: true, expiredNotYes: true }))
