// 账：只报数、只提醒"主人不是富翁"；不设闸。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-cost-'))
const QQ = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-qq-'))
process.env.DSH_HOME = HOME
process.env.YUSHEN_QQ_DIR = QQ

const now = Date.now()
const rows = [
  { k: 'turn', t: now - 3600_000, b: { cacheMiss: 1500, cacheHit: 25000, cacheWrite: 0, output: 400 } },
  { k: 'turn', t: now - 600_000, b: { cacheMiss: 2000, cacheHit: 30000, cacheWrite: 0, output: 600 } },
]
fs.mkdirSync(path.join(QQ, 'state'), { recursive: true })
fs.writeFileSync(path.join(QQ, 'state', 'token-usage.jsonl'), rows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')

const cost = await import('../lib/cost.js')

const s = cost.spendToday({ now })
assert.equal(s.turns, 2, '今天两次回合')
assert.ok(s.yuan > 0 && s.yuan < 1, `钱要算得出来：${s.yuan}`)
const per = cost.perTurnEstimate({ now })
assert.ok(per > 0 && per < 0.05, `单回合单价：${per}`)

const line = cost.costLine({ now })
assert.match(line, /今天云端花了/)
assert.match(line, /本地回是 0 元/)
assert.match(line, /主人不是富翁/)
assert.match(line, /你自己定/, '只报价，不下命令')

// 没有账本也不炸：给 0
fs.rmSync(path.join(QQ, 'state', 'token-usage.jsonl'), { force: true })
const empty = cost.spendToday({ now })
assert.equal(empty.turns, 0)
assert.equal(empty.yuan, 0)

fs.rmSync(HOME, { recursive: true, force: true })
fs.rmSync(QQ, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, spend: true, perTurn: true, advisesNotGates: true, emptySafe: true }))
