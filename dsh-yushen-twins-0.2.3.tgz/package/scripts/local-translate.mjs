// 本地翻译：起 llama-server，把一批消息翻成「观察」。
//
//   node scripts/local-translate.mjs --batch 20       取收件箱最近 20 条，翻译并打印
//   node scripts/local-translate.mjs --text "在吗"     翻一条
//   node scripts/local-translate.mjs --stop           停掉本地服务
//
// 纪律：只许写**观察**（他说了什么、有没有点名、是不是问句），
// 不许写结论（他在挑衅你 / 他对你有意思）——翻译不是判断。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { execFileSync, spawn } from 'node:child_process'
import { probeLocal, observe } from '../lib/translator.js'
import { readInbox } from '../lib/inbox.js'

const PORT = Number(process.env.YUSHEN_LOCAL_PORT || 8088)
const BASE = `http://127.0.0.1:${PORT}`
const LOCAL = probeLocal()
const PID_FILE = path.join(path.dirname(LOCAL.engine || 'D:/deepseekTools/local-llm/bin/x'), 'llama-server.pid')

const argv = process.argv.slice(2)
const arg = (name, fallback = '') => {
  const i = argv.indexOf(`--${name}`)
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : fallback
}

async function health() {
  try { const r = await fetch(`${BASE}/health`, { signal: AbortSignal.timeout(1500) }); return r.ok } catch { return false }
}

async function startServer() {
  if (await health()) return { started: false, note: '已经在跑' }
  if (!LOCAL.ready) throw new Error(`本地引擎没装好：${LOCAL.note}`)
  const args = [
    '-m', LOCAL.model,
    '-c', '4096',
    '--host', '127.0.0.1',
    '--port', String(PORT),
    '-t', String(Math.max(2, Math.min(8, os.cpus().length - 2))),
    '--no-webui',
  ]
  const child = spawn(LOCAL.engine, args, { detached: true, stdio: 'ignore' })
  child.unref()
  try { fs.writeFileSync(PID_FILE, String(child.pid), 'utf8') } catch { /* 记不下也能跑 */ }
  for (let i = 0; i < 90; i += 1) {
    await new Promise((r) => setTimeout(r, 1000))
    if (await health()) return { started: true, pid: child.pid, note: '刚起来' }
  }
  throw new Error('本地服务 90 秒没起来（看 models/bin 是否完整）')
}

function stopServer() {
  try {
    const pid = Number(fs.readFileSync(PID_FILE, 'utf8').trim())
    if (pid) execFileSync('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' })
    fs.rmSync(PID_FILE, { force: true })
    return { ok: true, killed: pid }
  } catch { return { ok: false, note: '没找到 pid 文件，可能已经停了' } }
}

const SYSTEM = [
  '你是「翻译」，不是评论员。',
  '任务：把一批聊天消息翻成观察，给另一个读者看。',
  '只许写事实：谁在说、说了什么（一句话概括）、有没有点名、是不是问句、有没有重复、标点重不重、带没带图。',
  '禁止：推断动机（他在挑衅/他喜欢你）、评价（没营养/很烦）、建议（别理他/回一句）、编造原文没有的信息。',
  '输出：只输出 JSON 数组，不要解释。每项：{"i":序号,"who":"谁","gist":"一句话说他在说什么（≤20字）","marks":["事实标签"]}',
].join('\n')

function stripFence(text) {
  return String(text || '').replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim()
}

export async function translateWithLocal(messages, { timeoutMs = 300000 } = {}) {
  await startServer()
  const lines = messages.map((m, i) => `${i}. ${m.name || m.userId || '谁'}：${String(m.text || '').slice(0, 200)}${m.atMe ? '（点名了她）' : ''}`).join('\n')
  const body = {
    model: 'local',
    temperature: 0.2,
    max_tokens: 500,
    messages: [
      { role: 'system', content: SYSTEM },
      { role: 'user', content: `把下面这些消息翻成观察：\n${lines}` },
    ],
  }
  const r = await fetch(`${BASE}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs),
  })
  if (!r.ok) throw new Error(`本地服务返回 ${r.status}`)
  const data = await r.json()
  const text = data?.choices?.[0]?.message?.content || ''
  let rows = []
  try { rows = JSON.parse(stripFence(text)) } catch { rows = [] }
  if (!Array.isArray(rows) || !rows.length) throw new Error(`本地输出不是 JSON 数组：${String(text).slice(0, 120)}`)
  return rows.map((row) => ({
    i: Number(row.i),
    who: String(row.who || ''),
    gist: String(row.gist || '').slice(0, 60),
    marks: Array.isArray(row.marks) ? row.marks.map(String).slice(0, 6) : [],
    text: String(messages[Number(row.i)]?.text || ''),
  }))
}

async function main() {
  if (argv.includes('--stop')) { console.log(JSON.stringify(stopServer())); return }
  if (argv.includes('--health')) { console.log(JSON.stringify({ health: await health(), local: LOCAL })); return }

  const single = arg('text')
  let messages = []
  if (single) messages = [{ id: 'one', name: '某人', text: single, at: new Date().toISOString(), media: 0 }]
  else messages = readInbox({ limit: Number(arg('batch', '20')) || 20 }).rows

  if (!messages.length) { console.log(JSON.stringify({ ok: false, note: '收件箱没有消息' })); return }
  for (const m of messages) if (m.atMe === undefined) m.atMe = false
  try {
    const translated = await translateWithLocal(messages)
    console.log(JSON.stringify({ ok: true, backend: 'local', mode: 'translate', count: translated.length, items: translated }, null, 2))
  } catch (e) {
    // 翻不动就退回观察（不假装翻译过）
    console.log(JSON.stringify({ ok: false, error: String(e?.message || e), fallback: messages.map((m) => observe(m)) }, null, 2))
  }
}

if (import.meta.url === `file://${process.argv[1].replace(/\\/g, '/')}`) main()
