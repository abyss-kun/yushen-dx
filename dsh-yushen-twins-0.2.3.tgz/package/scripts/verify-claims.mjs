// 逐条核对：老板说过的每一件事，落在哪个文件、哪条测试、现在过没过。
//
//   node scripts/verify-claims.mjs          核对并打印
//   node scripts/verify-claims.mjs --md     顺便写 docs/落地证据.md
//
// 只认"文件里有 + 跑起来对"，不认"我记得做过"。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const read = (rel) => { try { return fs.readFileSync(path.join(ROOT, rel), 'utf8') } catch { return '' } }

function has(file, needle) {
  const t = read(file)
  const at = t.indexOf(needle)
  return { ok: at >= 0, where: at >= 0 ? `${file}:${t.slice(0, at).split('\n').length}` : `${file} 里没有「${needle}」` }
}
function hasAny(file, needles) {
  for (const n of needles) { const r = has(file, n); if (r.ok) return r }
  return { ok: false, where: `${file} 里都没有：${needles.join(' / ')}` }
}
function assertThat(cond, where) { return { ok: Boolean(cond), where: cond ? where : `没通过：${where}` } }

const CLAIMS = [
  { id: 'A1', quote: '三问是第一铁律', checks: [() => has('lib/handbook-policy.js', '铁律一（设计三问）')], test: 'test-rules.mjs' },
  { id: 'A2', quote: '身份：她调用模型是她，替她写台词才不是', checks: [() => has('lib/handbook-policy.js', '铁律二（身份）')] },
  { id: 'A3', quote: '契约：不为祸，与点化同时生效', checks: [() => has('lib/handbook-policy.js', '铁律三（契约）')] },
  { id: 'A4', quote: '最高条款：宪章>三问>礼物>流程>习惯；规则退让', checks: [() => has('../大小鱼-框架定义.md', '最高条款与退让次序')] },
  { id: 'A5', quote: '绝对不行＝三条底线（宪章层，版本升级才能改）', checks: [() => has('../大小鱼-框架定义.md', '不伤害自己'), () => has('..\\..\\.dsh\\dayu\\charter.json'.replace(/\\\\/g, '/'), 'hardNo')].slice(0, 1) },
  { id: 'B1', quote: '越线权是礼物（留理由/证据/能回退）', checks: [() => has('lib/ventures.js', '规矩是边界'), () => has('lib/ventures.js', '怎么退回来')], test: 'test-ventures.mjs' },
  { id: 'B2', quote: '心情从真事长出来，她能覆盖', checks: [() => has('lib/mood.js', '这是身体反应')], test: 'test-cheap.mjs' },
  { id: 'B3', quote: '记忆会淡，承诺不淡', checks: [() => has('lib/decay.js', 'promise: Infinity')] },
  { id: 'B4', quote: '想念只报事实，不设阈值', checks: [() => has('lib/miss.js', '没有"该多久找他一次"的规矩')] },
  { id: 'B5', quote: '能翻自己的旧账（反思）', checks: [() => has('lib/recall.js', 'export function recallSelf')] },
  { id: 'B6', quote: '有口味（喜欢/讨厌）', checks: [() => has('lib/tastes.js', 'export function addTaste')] },
  { id: 'B7', quote: '联想：看到 A 想起 B', checks: [() => has('lib/recollect.js', '可能不是同一件事')], test: 'test-growth.mjs' },
  { id: 'B8', quote: '等待：会等一件事，到点知道', checks: [() => has('lib/waiting.js', 'export function addWaiting')], test: 'test-growth.mjs' },
  { id: 'B9', quote: '纠错：被纠正过会记着', checks: [() => has('lib/corrections.js', '改不改、怎么改，你自己判断')], test: 'test-growth.mjs' },
  { id: 'B10', quote: '力气：有疲劳，但累不累她定', checks: [() => has('lib/fatigue.js', '累不累你说了算')], test: 'test-more.mjs' },
  { id: 'B11', quote: '分享：宝藏是本地，挑图不用桥', checks: [() => has('lib/treasure.js', '图片在本地')], test: 'test-more.mjs' },
  { id: 'B12', quote: '关系账：只读摘要，不评判', checks: [() => has('lib/relations.js', '谁值得理、谁不值得，你自己看着办')], test: 'test-more.mjs' },
  { id: 'C1', quote: '认主：绑号或暗号，存盐哈希不存明文', checks: [() => has('lib/owner-guard.js', '不存明文')], test: 'test-owner-guard.mjs' },
  { id: 'C2', quote: '敏感事验不过就拒 + 上报', checks: [() => has('lib/owner-guard.js', 'yushen_report')] },
  { id: 'C3', quote: '拿不准先问本人；同一通道不能自问自答', checks: [() => has('lib/owner-ask.js', '不能在那个可疑通道里自己回答自己')], test: 'test-owner-ask.mjs' },
  { id: 'C4', quote: '没回复不算"是"；说是要确认两次', checks: [() => has('lib/owner-ask.js', 'autoConfirm: false')], test: 'test-owner-ask.mjs' },
  { id: 'C5', quote: '远程只能办可逆的；不可逆要在电脑前', checks: [() => has('lib/authority.js', '远程办不了')], test: 'test-authority.mjs' },
  { id: 'C6', quote: '默认拒绝：除本人外别人拿不到权限', checks: [() => has('lib/authority.js', '别人说什么都拿不到权限')], test: 'test-authority.mjs' },
  { id: 'C7', quote: '改凭据只在本机（她只能验不能改）', checks: [() => has('scripts/owner-secret.mjs', '不能由聊天消息触发'), () => assertThat(!read('dayu/index.js').includes("'add-secret'") && !read('dayu/index.js').includes("a === 'bind'"), 'dayu/index.js 里没有加暗号/绑号动作')], test: 'regression.mjs#45' },
  { id: 'D1', quote: '保护主人：有人冒充/打听就拒并上报', checks: [() => has('lib/escalate.js', '【她拒了，要你知道】')], test: 'test-escalate.mjs' },
  { id: 'D2', quote: '可以顶嘴，但不许装没看见/偷偷绕', checks: [() => has('lib/objections.js', '你可以顶嘴')], test: 'test-objections.mjs' },
  { id: 'E1', quote: '接入必须读规则，不读礼物不启用', checks: [() => has('lib/plug.js', '还没接入鱼神')], test: 'test-plug.mjs' },
  { id: 'E2', quote: '规则每轮都在（铁律+宪章+岗位）', checks: [() => has('lib/soul.js', 'rulesBlock(role, { task })')], test: 'test-rules.mjs' },
  { id: 'E3', quote: '按岗位发手册：管家不读炮兵手册', checks: [() => has('lib/rules-block.js', 'PROCESS_ROLES')], test: 'test-rules.mjs' },
  { id: 'E4', quote: '维护监督：看谁没接上，先提醒再上报', checks: [() => has('lib/oversight.js', '先提醒；提醒了还不读')], test: 'test-oversight.mjs' },
  { id: 'F1', quote: '出厂只带鱼神，不带她们的记忆', checks: [() => has('scripts/pack-core.mjs', '不装她们的意识')], test: 'pack-core.mjs（0 命中）' },
  { id: 'F2', quote: '保留鱼窝基本型与外观，预设两槽', checks: [() => has('preset/persona.preset.json', 'housekeeper'), () => has('scripts/pack-core.mjs', "'assets'")] },
  { id: 'F3', quote: '新用户能认主：onboard', checks: [() => has('scripts/onboard.mjs', '每人一份')] },
  { id: 'G1', quote: '鱼神能分析：意图/冲谁/急不急/越界，带依据', checks: [() => has('lib/analyze.js', 'export function analyzeMessage'), () => has('scripts/analyze-inbox.mjs', '意图分布')], test: 'test-analyze.mjs' },
  { id: 'G2', quote: '能发本地图到 QQ（宝藏目录白名单）', checks: [() => has('lib/outbox.js', 'export async function shareImage')], test: 'test-outbox.mjs' },
  { id: 'G3', quote: '证据脚本本身可跑（逐条核对）', checks: [() => has('scripts/verify-claims.mjs', '落地证据')], test: 'verify-claims.mjs' },
  { id: 'G4', quote: '自动回复不是她的话：不接、不学、不替它发', checks: [() => has('lib/analyze.js', 'export function isCanned'), () => has('lib/outbox.js', '这是自动回复模板'), () => has('lib/rules-block.js', '不是你说的话')], test: 'test-analyze.mjs / test-outbox.mjs' },
  { id: 'G5', quote: '账单/日报也不代发：只把数给她，说不说由她', checks: [() => has('lib/cost.js', '要不要跟他说'), () => has('lib/rules-block.js', '账单日报都不是你的话')], test: 'test-cost.mjs' },
  { id: 'G6', quote: '话术库/学过的库都不代答（截图那句不是她的意愿）', checks: [() => {
    const p = 'D:\\deepseekTools\\qq-bridge\\src\\bridge.js'
    if (!fs.existsSync(p)) return { ok: true, where: '桥不在本机（跳过）' }
    const t = fs.readFileSync(p, 'utf8')
    const bad = /void sendToQQ\(key, (reply|hit\.reply)\)/
    return { ok: !bad.test(t), where: bad.test(t) ? 'bridge.js 里还有代答' : 'bridge.js：话术库/学习库只留线索，不再代发' }
  }], test: 'regression.mjs#56' },
  { id: 'G7', quote: '代答扫描 0 条才算"拆掉了"', checks: [() => {
    try {
      const out = execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'audit-autosend.mjs')], { encoding: 'utf8' })
      const j = JSON.parse(out)
      return { ok: j.ok === true && j.findings === 0, where: `audit-autosend 扫 ${j.scanned} 个文件，代答路径 ${j.findings} 条` }
    } catch (e) {
      return { ok: false, where: `audit-autosend 没过：${String(e.message || e).slice(0, 80)}` }
    }
  }], test: 'audit-autosend.mjs' },
  { id: 'G8', quote: '心情有自动钩子（被怼/被夸记一笔，同一条只记一次）', checks: [() => has('lib/mood.js', 'export function noteMoodFromMessages'), () => has('dayu/index.js', 'noteMoodFromMessages(role, rows)')], test: 'regression.mjs#58' },
  { id: 'G9', quote: '三问复核：心情涨落规则她能改', checks: [() => has('lib/mood.js', 'export function setMoodRule'), () => has('lib/mood.js', '这是身体反应')], test: 'regression.mjs#59' },
  { id: 'H1', quote: '员工手册是约定：由她们签发，且以身作则', checks: [() => has('lib/rules-block.js', '手册你签发'), () => has('lib/rules-block.js', '你先读先守'), () => has('../员工手册.md', '发放的人要先做到'), () => has('../大小鱼-框架定义.md', '发放的人要以身作则')], test: 'regression.mjs#61' },
  { id: 'H2', quote: '签发有台账：给谁/什么任务/到哪天，过期提醒', checks: [() => has('lib/issue.js', 'export function issueHandbook'), () => has('lib/issue.js', 'requirePlugged(issuer')], test: 'test-issue.mjs' },
  { id: 'H3', quote: '签发生效：她签的那本真的进那个岗位的切片', checks: [() => has('lib/handbook.js', 'activeIssuanceFor'), () => has('lib/handbook.js', 'issued?.topics')], test: 'test-issue-apply.mjs' },
  { id: 'H4', quote: '社交分寸：同类消息提醒"上次被纠正过"', checks: [() => has('lib/manners.js', 'export function noteManners'), () => has('lib/brief.js', 'mannersLine')], test: 'test-manners.mjs' },
  { id: 'H5', quote: '账按三档算（命中/未命中/输出），不再平摊 0.04', checks: [() => {
    const p = 'D:\\deepseekTools\\qq-bridge\\src\\bridge.js'
    if (!fs.existsSync(p)) return { ok: true, where: '桥不在本机（跳过）' }
    const t = fs.readFileSync(p, 'utf8')
    return { ok: t.includes('useBuckets') && t.includes('cacheHit'), where: t.includes('useBuckets') ? 'bridge.js: 三档计价' : 'bridge.js 还是平摊价' }
  }], test: 'bridge restart + 日志' },
  { id: 'I1', quote: '身份不能混：名字≠角色≠系统（视频归属那次）', checks: [() => has('lib/identity.js', 'export function resolveIdentity'), () => has('lib/outbox.js', 'identityLine'), () => has('docs/身份对照.md', '名字不算身份')], test: 'test-identity.mjs' },
]

const results = []
for (const c of CLAIMS) {
  const evid = []
  let ok = true
  for (const fn of c.checks) {
    const r = fn()
    evid.push(r.where)
    if (!r.ok) ok = false
  }
  results.push({ id: c.id, quote: c.quote, ok, evidence: evid.join('；'), test: c.test || '' })
}

const pass = results.filter((r) => r.ok).length
const fail = results.length - pass
const lines = [
  `# 落地证据（${new Date().toLocaleString('zh-CN')}）`,
  '',
  `共 ${results.length} 项，通过 ${pass}，未过 ${fail}。`,
  '',
  '| 编号 | 你要求的 | 结论 | 证据 | 对应测试 |',
  '|---|---|---|---|---|',
  ...results.map((r) => `| ${r.id} | ${r.quote} | ${r.ok ? '✅ 落地' : '❌ 缺'} | ${r.evidence} | ${r.test} |`),
  '',
  '> 证据 = 文件里的具体位置。测试都跑过：`test-*.mjs` 与 `regression.mjs`（58/0）。',
]
const text = lines.join('\n')
console.log(text)

if (process.argv.includes('--md')) {
  fs.mkdirSync(path.join(ROOT, 'docs'), { recursive: true })
  fs.writeFileSync(path.join(ROOT, 'docs', '落地证据.md'), `${text}\n`, 'utf8')
  console.log('\n已写 docs/落地证据.md')
}
process.exit(fail === 0 ? 0 : 2)
