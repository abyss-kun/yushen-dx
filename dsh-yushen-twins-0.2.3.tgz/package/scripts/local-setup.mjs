// 本地引擎安装/检查：llama.cpp（CPU 版）+ Qwen2.5-7B-Instruct q4_k_m。
//
//   node scripts/local-setup.mjs --check     只查，不下载
//   node scripts/local-setup.mjs             缺什么下什么（可反复跑，断点续传）
//
// 装到 D:\deepseekTools\local-llm（可用 YUSHEN_LOCAL_DIR 改）；不碰任何已有配置。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { execFileSync } from 'node:child_process'
import { localLlmDir } from '../lib/paths.js'

const DIR = localLlmDir()
const BIN = path.join(DIR, 'bin')
const MODELS = path.join(DIR, 'models')
const LOG = path.join(DIR, 'install.log')

const LLAMA_TAG = 'b11889'
const LLAMA_FILE = `llama-${LLAMA_TAG}-bin-win-cpu-x64.zip`
const LLAMA_GH = `https://github.com/ggml-org/llama.cpp/releases/download/${LLAMA_TAG}/${LLAMA_FILE}`
// GitHub 直连在国内经常 0 字节；按顺序试镜像（206 才可信）
const LLAMA_URLS = [
  `https://gh-proxy.com/${LLAMA_GH}`,
  `https://ghproxy.net/${LLAMA_GH}`,
  LLAMA_GH,
]
const MODEL_BASE = 'https://modelscope.cn/models/Qwen/Qwen2.5-7B-Instruct-GGUF/resolve/master'
const MODEL_PARTS = [
  'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf',
  'qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf',
]
const EXPECT_MB = { [MODEL_PARTS[0]]: 3808, [MODEL_PARTS[1]]: 658 }

const checkOnly = process.argv.includes('--check')

function log(line) {
  const msg = `${new Date().toISOString()} ${line}`
  console.log(msg)
  try { fs.appendFileSync(LOG, `${msg}\n`) } catch { /* 记不下也继续 */ }
}

function sizeMB(file) {
  try { return Math.round(fs.statSync(file).size / 1048576) } catch { return 0 }
}

function have(file) { return fs.existsSync(file) }

function download(urls, dest) {
  const list = Array.isArray(urls) ? urls : [urls]
  let lastErr = null
  for (const url of list) {
    try {
      log(`下载 ${url}`)
      execFileSync('curl.exe', ['-L', '--fail', '--retry', '2', '--retry-delay', '3', '-C', '-', '-o', dest, url], { stdio: 'inherit' })
      if (sizeMB(dest) > 0) { log(`完成 ${path.basename(dest)}（${sizeMB(dest)} MB）`); return }
      lastErr = new Error('下载后是 0 字节')
    } catch (e) {
      lastErr = e
      log(`这个源不行：${url} → ${e?.message || e}`)
      try { fs.rmSync(dest, { force: true }) } catch { /* 换源重下 */ }
    }
  }
  throw lastErr || new Error('所有源都失败')
}

function ensureDirs() {
  for (const d of [BIN, MODELS]) fs.mkdirSync(d, { recursive: true })
}

function checkState() {
  const engine = path.join(BIN, 'llama-server.exe')
  const parts = MODEL_PARTS.map((n) => ({ name: n, file: path.join(MODELS, n), mb: sizeMB(path.join(MODELS, n)), want: EXPECT_MB[n] }))
  const missing = []
  if (!have(engine)) missing.push('llama-server.exe')
  for (const p of parts) if (!have(p.file) || p.mb < p.want * 0.9) missing.push(p.name)
  return { engine, parts, missing, ready: missing.length === 0 }
}

async function main() {
  ensureDirs()
  let st = checkState()
  log(`目录 ${DIR}；引擎=${have(st.engine) ? '有' : '缺'}；模型份数=${st.parts.filter((p) => have(p.file)).length}/2`)
  if (checkOnly) {
    console.log(JSON.stringify({ dir: DIR, ready: st.ready, engine: st.engine, parts: st.parts, missing: st.missing }, null, 2))
    return
  }
  if (!have(st.engine)) {
    const zip = path.join(DIR, 'llama-cpu-x64.zip')
    download(LLAMA_URLS, zip)
    log('解压引擎…')
    execFileSync('powershell.exe', ['-NoProfile', '-Command', `Expand-Archive -Path '${zip}' -DestinationPath '${BIN}' -Force`], { stdio: 'inherit' })
    // release 包里可能还套一层目录，把 exe 找出来放到 bin 根
    if (!have(st.engine)) {
      const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)])
      for (const f of walk(BIN)) {
        if (/llama-server\.exe$/i.test(f)) { fs.copyFileSync(f, st.engine); break }
      }
    }
    log(`引擎就位：${have(st.engine) ? '是' : '否'}`)
  }
  for (const part of st.parts) {
    if (have(part.file) && part.mb >= part.want * 0.9) { log(`已有 ${part.name}（${part.mb} MB）`); continue }
    download(`${MODEL_BASE}/${part.name}`, part.file)
  }
  st = checkState()
  log(`结束：ready=${st.ready}${st.ready ? '' : ` 缺 ${st.missing.join(', ')}`}`)
  console.log(JSON.stringify({ dir: DIR, ready: st.ready, engine: st.engine, parts: st.parts, missing: st.missing }, null, 2))
}

main().catch((e) => { log(`失败：${e?.message || e}`); process.exit(1) })
