import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const home = fs.mkdtempSync(path.join(os.tmpdir(), 'ys-group-replies-'))
process.env.DSH_HOME = home

const { createGroupReplies } = await import('../lib/group-replies.js')
const { readOutbox } = await import('../lib/group-outbox.js')

const rows = []
const t = createGroupReplies({ append: (x) => rows.push(x) })
const emit = (type, turn, text = '') => t.event('s', { type, data: { turn } }, text)

// 未登记本轮：私聊回话不能被群聊认领
t.register('s', { prompt: 'exact-server-nonce', role: 'xiaoyu', conversationId: 'group:fish-god', messageId: 'one', nonce: 'nonce-x' })
emit('turn/start', 1); emit('user/message', undefined, 'private'); emit('assistant/message', 1, 'PRIVATE'); emit('turn/end', 1)
assert.equal(rows.length, 0, '私聊回合被误认成群聊回复')

// 命中本轮：只取该 turn 的最后一步，且多步不重复落盘
emit('turn/start', 2); emit('user/message', undefined, 'exact-server-nonce')
emit('assistant/message', 1, 'stale private'); emit('assistant/message', 2, 'commentary'); emit('assistant/message', 2, 'final'); emit('turn/end', 2)
assert.equal(rows.length, 1)
assert.equal(rows[0].text, 'final')
assert.equal(rows[0].role, 'xiaoyu')

// 回合结束后再来私聊：不能二次落盘
emit('turn/start', 3); emit('assistant/message', 3, 'later private'); emit('turn/end', 3)
assert.equal(rows.length, 1)

// 投递账：有 nonce 的回显才记账
emit('turn/start', 4); emit('user/message', undefined, 'exact-server-nonce'); emit('assistant/message', 4, 'again'); emit('turn/end', 4)
assert.equal(rows.length, 1, '同一投递被重复落盘')

fs.rmSync(home, { recursive: true, force: true })
console.log('group replies: unrelated private turns excluded, exact host input bound, last-step reply emitted once')
