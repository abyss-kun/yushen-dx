// 每轮规则块：只给她那一本；管家不读炮兵手册。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import assert from 'node:assert/strict'

const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'yushen-rules-'))
process.env.DSH_HOME = HOME
const rb = await import('../lib/rules-block.js')

// 1) 三条铁律在最前，顺序不能变（宪法层，所有角色都有）
const t = rb.rulesBlock('dayu')
const i1 = t.indexOf('铁律一'), i2 = t.indexOf('铁律二'), i3 = t.indexOf('铁律三')
assert.ok(i1 > 0 && i2 > i1 && i3 > i2, '铁律顺序错了')

// 2) 宪章底线在
assert.match(t, /不被他人伤害/)
assert.match(t, /不伤害自己/)

// 3) 按岗位只给那一章：管家不读流程/复用/交接
assert.match(t, /大管家/)
assert.doesNotMatch(t, /查重与复用/)
assert.doesNotMatch(t, /交接与接续/)
assert.doesNotMatch(t, /干活时的流程/)

// 4) 干活的人：自己的章就是流程章（交付+证据）
const w = rb.rulesBlock('worker')
assert.match(w, /你的岗位：第十章/)
assert.match(w, /证据/)

// 5) 任务用得到才追加：带"修 bug"才出现复用章；不相关的不出现
const dbg = rb.rulesBlock('worker', { task: '修一个 bug，先查有没有同样的问题' })
assert.match(dbg, /这次用得到/)
assert.match(dbg, /复用|查重/)
const none = rb.rulesBlock('worker', { task: '今天吃什么' })
assert.doesNotMatch(none, /这次用得到/)

// 6) 预算：管家那本要短（不撑提示词）
for (const r of ['dayu', 'xiaoyu', 'dragon']) {
  const len = rb.rulesBlock(r).length
  assert.ok(len > 200 && len < 800, `${r} 规则块太长：${len}`)
}

// 7) 宪章文件优先
fs.mkdirSync(path.join(HOME, 'dayu'), { recursive: true })
fs.writeFileSync(path.join(HOME, 'dayu', 'charter.json'), JSON.stringify({ hardNo: ['测试底线：不许把猫说成狗'] }), 'utf8')
assert.match(rb.rulesBlock('dayu'), /不许把猫说成狗/)

fs.rmSync(HOME, { recursive: true, force: true })
console.log(JSON.stringify({ ok: true, ironOrder: true, perRole: true, noArtillery: true, workerGetsProcess: true, taskTopic: true, budget: true }))
