// A/B：本地 7B 翻译 vs 规则观察（原文做对照），看本地翻译够不够用。
//
//   node scripts/ab-translate.mjs --batch 12
//   node scripts/ab-translate.mjs --batch 12 --save   写到 docs/本地翻译-AB.md
//
// 判读标准（写给看报告的人）：
//   1. 漏没漏关键事实（点名、问句、重复追问、冲她的话）
//   2. 有没有编（原文没有的动机/评价）
//   3. 概括准不准（她在说什么）
// 三条都过得去，本地翻译就能用来省钱；有一条明显不行，就别用它替代云端。
import fs from 'node:fs'
import path from 'node:path'
import { readInbox } from '../lib/inbox.js'
import { observe, probeLocal } from '../lib/translator.js'
import { translateWithLocal } from './local-translate.mjs'

const argv = process.argv.slice(2)
const arg = (name, fallback = '') => {
  const i = argv.indexOf(`--${name}`)
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : fallback
}

const batch = Math.max(3, Math.min(30, Number(arg('batch', '12')) || 12))

async function main() {
  const local = probeLocal()
  if (!local.ready) {
    console.log(JSON.stringify({ ok: false, reason: `本地引擎没装好：${local.note}`, engine: local.engine, model: local.model }, null, 2))
    return
  }
  const rows = readInbox({ limit: batch }).rows.filter((r) => r.text && !r.isSelf)
  if (!rows.length) { console.log(JSON.stringify({ ok: false, reason: '收件箱没有可用消息' })); return }

  let translated = []
  let error = ''
  try { translated = await translateWithLocal(rows) } catch (e) { error = String(e?.message || e) }

  const rules = rows.map((r) => observe(r))
  const lines = []
  lines.push(`# 本地翻译 A/B（${new Date().toISOString()}）`)
  lines.push('')
  lines.push(`- 样本：收件箱最近 ${rows.length} 条（${rows[0]?.key || ''}）`)
  lines.push(`- 本地：${path.basename(local.model || '')}；引擎 ${path.basename(local.engine || '')}`)
  lines.push(`- 规则观察：\`observe()\`（零 token，只列事实标签）`)
  if (error) lines.push(`- **本地翻译失败**：${error}`)
  lines.push('')
  lines.push('| # | 原文 | 本地翻译（gist） | 本地标签 | 规则观察标签 |')
  lines.push('|---|---|---|---|---|')
  for (let i = 0; i < rows.length; i += 1) {
    const t = translated.find((x) => x.i === i) || {}
    const esc = (s) => String(s || '').replace(/\|/g, '\\|').slice(0, 90)
    lines.push(`| ${i} | ${esc(rows[i].text)} | ${esc(t.gist || (error ? '（失败）' : '（没翻）'))} | ${esc((t.marks || []).join('、'))} | ${esc((rules[i].marks || []).join('、'))} |`)
  }
  const report = lines.join('\n')
  console.log(report)
  if (argv.includes('--save')) {
    const file = path.join(process.cwd(), 'docs', '本地翻译-AB.md')
    fs.writeFileSync(file, `${report}\n`, 'utf8')
    console.log(`\n已写：${file}`)
  }
}

main().catch((e) => { console.log(JSON.stringify({ ok: false, error: String(e?.message || e) })); process.exit(1) })
