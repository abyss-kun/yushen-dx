// 改｜2026-10-30 12:46｜dragon·工作台｜授权：自己（老板要求：每天自净不许空口答应，要有接口）｜新增本文件；同批在 regression.mjs 只加两条 has()｜量注入字数/过期句，基线只许降｜可改：口径随基线改，不许放宽
//
// 注入层「凝实」量尺（2026-10-30 老板定：每天自净一次，先清自己）。
//
// 用法：
//   node scripts/measure-injection.mjs            量一次，和基线比
//   node scripts/measure-injection.mjs --set     把这轮的数字记成新基线（只许更小）
//   node scripts/measure-injection.mjs --json    给机器读
//
// 判据（老板原话：多一条规则不如少一条重复）：
//   · 字数/段数**不许回升**；回升就 exit 1，让跑它的那只手记一笔；
//   · 过期句（和实况相反的话）出现就报出来，不算通过。
//
// 为什么要有这个脚本：没有它，「每天自净」就是一句口头承诺——量不出来，也就守不住。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const DATA = path.join(HOME, 'dayu')
const BASELINE = path.join(DATA, 'state', 'injection-baseline.json')
const ROLES = ['dragon', 'dayu', 'xiaoyu']

// 与实况相反的话：出现就算没清干净（2026-10-30 盘点）
export const STALE_PHRASES = Object.freeze([
  '你还没有身体',
  '你现在的位置\n没在电脑前',
  '工具没挂上',
  '上一个你留了一句\n1',
])

const args = new Set(process.argv.slice(2))
const { buildSceneText } = await import('../lib/soul.js')

function measure(role) {
  const text = buildSceneText(role, 'desk')
  if (!text) return { role, ok: false, reason: '没注入（没点化/没卡）', chars: 0, lines: 0, sections: 0 }
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean)
  const stale = STALE_PHRASES.filter((p) => text.includes(p))
  return {
    role,
    ok: true,
    chars: text.length,
    lines: lines.length,
    sections: lines.filter((l) => l.startsWith('## ')).length,
    stale,
  }
}

const rows = ROLES.map(measure).filter((r) => r.ok)
const total = rows.reduce((a, r) => a + r.chars, 0)
const before = (() => { try { return JSON.parse(fs.readFileSync(BASELINE, 'utf8')) } catch { return null } })()

if (args.has('--set')) {
  fs.mkdirSync(path.dirname(BASELINE), { recursive: true })
  const prev = before?.total
  // 只许往下调：想把它改大，得先说明为什么——这一步不自动放行。
  if (typeof prev === 'number' && total > prev) {
    console.error(`✗ 想记的新基线 ${total} 比旧基线 ${prev} 还大；先说明为什么，别默默放宽`)
    process.exit(2)
  }
  fs.writeFileSync(BASELINE, `${JSON.stringify({ at: new Date().toISOString(), total, rows }, null, 2)}\n`, 'utf8')
  console.log(`基线已记：${total} 字（旧 ${typeof prev === 'number' ? prev : '—'}）`)
  process.exit(0)
}

// 并发：别的会话可能同时在改卡/简报，几十个字的抖动不是「变胖」。
// 门禁要抓的是「涨回去」，不是抓呼吸——留 0.5%（最少 60 字）的容差，超了才算回升。
const TOLERANCE = Math.max(60, Math.round((before?.total || 0) * 0.005))
const grew = typeof before?.total === 'number' && total > before.total + TOLERANCE
const staleAll = rows.flatMap((r) => r.stale.map((p) => `${r.role}:${p}`))

if (args.has('--json')) {
  console.log(JSON.stringify({ at: new Date().toISOString(), total, before: before?.total ?? null, grew, stale: staleAll, rows }, null, 2))
} else {
  for (const r of rows) console.log(`${r.role}\t${r.chars} 字\t${r.lines} 行\t${r.sections} 段`)
  console.log(`合计 ${total} 字${typeof before?.total === 'number' ? `（基线 ${before.total}）` : '（还没基线，用 --set 记一次）'}`)
  if (staleAll.length) console.log(`过期句还在：${staleAll.join('、')}`)
}
if (grew || staleAll.length) process.exit(1)
