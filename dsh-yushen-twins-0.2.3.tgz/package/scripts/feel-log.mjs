// feel-log：读「感觉」的记录。只读本地，不调模型。
//
// 为什么有这个：改进清单里挂着「done/feel 查不到入口」——`yushen_self action=feel`
// 能写、能回执，但想回头看半年前记过什么，只能自己翻 jsonl。这个脚本就干这一件事。
//
// 用法：
//   node dsh-yushen-twins/scripts/feel-log.mjs                 # 默认看小鱼的，最近 10 条
//   node dsh-yushen-twins/scripts/feel-log.mjs dayu --limit 30
//   node dsh-yushen-twins/scripts/feel-log.mjs xiaoyu --grep 空
//   node dsh-yushen-twins/scripts/feel-log.mjs all --since 2026-10-28
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const ROLES = ['dayu', 'xiaoyu', 'dragon']
const FEEL_DIR = path.join(process.env.DSH_HOME || path.join(os.homedir(), '.dsh'), 'dayu', 'soul', 'feel')

function parseArgs(argv) {
  const out = { role: 'xiaoyu', limit: 10, grep: '', since: '' }
  const rest = []
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--limit') out.limit = Number(argv[++i]) || 10
    else if (a === '--grep') out.grep = String(argv[++i] || '')
    else if (a === '--since') out.since = String(argv[++i] || '')
    else if (!a.startsWith('-')) rest.push(a)
  }
  if (rest[0]) out.role = rest[0]
  return out
}

function readRole(role) {
  const file = path.join(FEEL_DIR, `${role}.jsonl`)
  if (!fs.existsSync(file)) return { file, rows: [], bytes: 0 }
  const raw = fs.readFileSync(file, 'utf8')
  const rows = []
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue
    try { rows.push(JSON.parse(line)) } catch { /* 坏行跳过，不让一条脏数据拖垮整本 */ }
  }
  // 判空看字节，别的别信（2026-10-29 自己踩过：815 字节被四舍五入成 0KB，误判成空文件）
  return { file, rows, bytes: Buffer.byteLength(raw, 'utf8') }
}

const args = parseArgs(process.argv.slice(2))
const roles = args.role === 'all' ? ROLES : [args.role]
const all = []
for (const r of roles) {
  const { rows, bytes } = readRole(r)
  for (const row of rows) all.push({ ...row, _role: row.role || r })
  if (rows.length === 0) console.log(`· ${r}: 没有记录（文件 ${bytes} 字节）`)
}

let list = all
if (args.since) list = list.filter((x) => String(x.at || '') >= args.since)
if (args.grep) {
  const q = args.grep
  list = list.filter((x) => `${x.say || ''} ${x.from || ''} ${x.kind || ''}`.includes(q))
}
list.sort((a, b) => String(a.at || '').localeCompare(String(b.at || '')))

const shown = list.slice(-args.limit)
if (!shown.length) {
  console.log('没有符合的 feel 记录。')
  process.exit(0)
}

const bar = (v) => {
  const n = Math.round(Number(v) || 0)
  if (n > 0) return `+${n}`
  if (n < 0) return `${n}`
  return ' 0'
}
console.log(`feel · 共 ${all.length} 条，本次显示 ${shown.length} 条（${roles.join('/')}）\n`)
for (const x of shown) {
  const at = String(x.at || '').replace('T', ' ').slice(0, 16)
  const kind = String(x.kind || '—')
  const vague = x.vague === true ? '（模糊）' : ''
  console.log(`${at}  ${bar(x.valence)}  ${kind}${vague}`)
  console.log(`  说：${String(x.say || '').slice(0, 120)}`)
  if (x.from) console.log(`  因：${String(x.from).slice(0, 120)}`)
  console.log('')
}
